                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.0 #11528 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module serial
                                      6 	.optsdcc -mmcs51 --model-large
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _xQueueGenericCreate
                                     12 	.globl _xQueueReceiveFromISR
                                     13 	.globl _xQueueGenericSendFromISR
                                     14 	.globl _xQueueReceive
                                     15 	.globl _xQueueGenericSend
                                     16 	.globl _vPortYield
                                     17 	.globl _P7_7
                                     18 	.globl _P7_6
                                     19 	.globl _P7_5
                                     20 	.globl _P7_4
                                     21 	.globl _P7_3
                                     22 	.globl _P7_2
                                     23 	.globl _P7_1
                                     24 	.globl _P7_0
                                     25 	.globl _SPIF
                                     26 	.globl _WCOL
                                     27 	.globl _MODF
                                     28 	.globl _RXOVRN
                                     29 	.globl _NSSMD1
                                     30 	.globl _NSSMD0
                                     31 	.globl _TXBMT
                                     32 	.globl _SPIEN
                                     33 	.globl _P6_7
                                     34 	.globl _P6_6
                                     35 	.globl _P6_5
                                     36 	.globl _P6_4
                                     37 	.globl _P6_3
                                     38 	.globl _P6_2
                                     39 	.globl _P6_1
                                     40 	.globl _P6_0
                                     41 	.globl _AD2EN
                                     42 	.globl _AD2TM
                                     43 	.globl _AD2INT
                                     44 	.globl _AD2BUSY
                                     45 	.globl _AD2CM2
                                     46 	.globl _AD2CM1
                                     47 	.globl _AD2CM0
                                     48 	.globl _AD2WINT
                                     49 	.globl _AD0EN
                                     50 	.globl _AD0TM
                                     51 	.globl _AD0INT
                                     52 	.globl _AD0BUSY
                                     53 	.globl _AD0CM1
                                     54 	.globl _AD0CM0
                                     55 	.globl _AD0WINT
                                     56 	.globl _AD0LJST
                                     57 	.globl _P5_7
                                     58 	.globl _P5_6
                                     59 	.globl _P5_5
                                     60 	.globl _P5_4
                                     61 	.globl _P5_3
                                     62 	.globl _P5_2
                                     63 	.globl _P5_1
                                     64 	.globl _P5_0
                                     65 	.globl _CF
                                     66 	.globl _CR
                                     67 	.globl _CCF5
                                     68 	.globl _CCF4
                                     69 	.globl _CCF3
                                     70 	.globl _CCF2
                                     71 	.globl _CCF1
                                     72 	.globl _CCF0
                                     73 	.globl _CY
                                     74 	.globl _AC
                                     75 	.globl _F0
                                     76 	.globl _RS1
                                     77 	.globl _RS0
                                     78 	.globl _OV
                                     79 	.globl _F1
                                     80 	.globl _P
                                     81 	.globl _P4_7
                                     82 	.globl _P4_6
                                     83 	.globl _P4_5
                                     84 	.globl _P4_4
                                     85 	.globl _P4_3
                                     86 	.globl _P4_2
                                     87 	.globl _P4_1
                                     88 	.globl _P4_0
                                     89 	.globl _TF4
                                     90 	.globl _EXF4
                                     91 	.globl _EXEN4
                                     92 	.globl _TR4
                                     93 	.globl _CT4
                                     94 	.globl _CPRL4
                                     95 	.globl _TF3
                                     96 	.globl _EXF3
                                     97 	.globl _EXEN3
                                     98 	.globl _TR3
                                     99 	.globl _CT3
                                    100 	.globl _CPRL3
                                    101 	.globl _TF2
                                    102 	.globl _EXF2
                                    103 	.globl _EXEN2
                                    104 	.globl _TR2
                                    105 	.globl _CT2
                                    106 	.globl _CPRL2
                                    107 	.globl _BUSY
                                    108 	.globl _ENSMB
                                    109 	.globl _STA
                                    110 	.globl _STO
                                    111 	.globl _SI
                                    112 	.globl _AA
                                    113 	.globl _SMBFTE
                                    114 	.globl _SMBTOE
                                    115 	.globl _PT2
                                    116 	.globl _PS
                                    117 	.globl _PT1
                                    118 	.globl _PX1
                                    119 	.globl _PT0
                                    120 	.globl _PX0
                                    121 	.globl _EA
                                    122 	.globl _ET2
                                    123 	.globl _ES
                                    124 	.globl _ES0
                                    125 	.globl _ET1
                                    126 	.globl _EX1
                                    127 	.globl _ET0
                                    128 	.globl _EX0
                                    129 	.globl _S1MODE
                                    130 	.globl _MCE1
                                    131 	.globl _REN1
                                    132 	.globl _TB81
                                    133 	.globl _RB81
                                    134 	.globl _TI1
                                    135 	.globl _RI1
                                    136 	.globl _SM00
                                    137 	.globl _SM10
                                    138 	.globl _SM20
                                    139 	.globl _REN
                                    140 	.globl _REN0
                                    141 	.globl _TB80
                                    142 	.globl _RB80
                                    143 	.globl _TI
                                    144 	.globl _TI0
                                    145 	.globl _RI
                                    146 	.globl _RI0
                                    147 	.globl _FLHBUSY
                                    148 	.globl _CP1EN
                                    149 	.globl _CP1OUT
                                    150 	.globl _CP1RIF
                                    151 	.globl _CP1FIF
                                    152 	.globl _CP1HYP1
                                    153 	.globl _CP1HYP0
                                    154 	.globl _CP1HYN1
                                    155 	.globl _CP1HYN0
                                    156 	.globl _CP0EN
                                    157 	.globl _CP0OUT
                                    158 	.globl _CP0RIF
                                    159 	.globl _CP0FIF
                                    160 	.globl _CP0HYP1
                                    161 	.globl _CP0HYP0
                                    162 	.globl _CP0HYN1
                                    163 	.globl _CP0HYN0
                                    164 	.globl _TF1
                                    165 	.globl _TR1
                                    166 	.globl _TF0
                                    167 	.globl _TR0
                                    168 	.globl _IE1
                                    169 	.globl _IT1
                                    170 	.globl _IE0
                                    171 	.globl _IT0
                                    172 	.globl _P0_7
                                    173 	.globl _P0_6
                                    174 	.globl _P0_5
                                    175 	.globl _P0_4
                                    176 	.globl _P0_3
                                    177 	.globl _P0_2
                                    178 	.globl _P0_1
                                    179 	.globl _P0_0
                                    180 	.globl _P7
                                    181 	.globl _P6
                                    182 	.globl _ADC2CN
                                    183 	.globl _XBR2
                                    184 	.globl _XBR1
                                    185 	.globl _XBR0
                                    186 	.globl _P5
                                    187 	.globl _P4
                                    188 	.globl _FLACL
                                    189 	.globl _P1MDIN
                                    190 	.globl _P3MDOUT
                                    191 	.globl _P2MDOUT
                                    192 	.globl _P1MDOUT
                                    193 	.globl _P0MDOUT
                                    194 	.globl _CCH0LC
                                    195 	.globl _CCH0TN
                                    196 	.globl _CCH0CN
                                    197 	.globl _P7MDOUT
                                    198 	.globl _P6MDOUT
                                    199 	.globl _P5MDOUT
                                    200 	.globl _P4MDOUT
                                    201 	.globl _CCH0MA
                                    202 	.globl _CLKSEL
                                    203 	.globl _SFRPGCN
                                    204 	.globl _PLL0FLT
                                    205 	.globl _PLL0MUL
                                    206 	.globl _PLL0DIV
                                    207 	.globl _OSCXCN
                                    208 	.globl _OSCICL
                                    209 	.globl _OSCICN
                                    210 	.globl _PLL0CN
                                    211 	.globl _FLSTAT
                                    212 	.globl _MAC0RNDH
                                    213 	.globl _MAC0RNDL
                                    214 	.globl _MAC0CF
                                    215 	.globl _MAC0AH
                                    216 	.globl _MAC0AL
                                    217 	.globl _MAC0STA
                                    218 	.globl _MAC0OVR
                                    219 	.globl _MAC0ACC3
                                    220 	.globl _MAC0ACC2
                                    221 	.globl _MAC0ACC1
                                    222 	.globl _MAC0ACC0
                                    223 	.globl _MAC0BH
                                    224 	.globl _MAC0BL
                                    225 	.globl _TMR4H
                                    226 	.globl _TMR4L
                                    227 	.globl _RCAP4H
                                    228 	.globl _RCAP4L
                                    229 	.globl _TMR4CF
                                    230 	.globl _TMR4CN
                                    231 	.globl _ADC2LT
                                    232 	.globl _ADC2GT
                                    233 	.globl _ADC2
                                    234 	.globl _ADC2CF
                                    235 	.globl _AMX2SL
                                    236 	.globl _AMX2CF
                                    237 	.globl _CPT1MD
                                    238 	.globl _CPT1CN
                                    239 	.globl _DAC1CN
                                    240 	.globl _DAC1H
                                    241 	.globl _DAC1L
                                    242 	.globl _TMR3H
                                    243 	.globl _TMR3L
                                    244 	.globl _RCAP3H
                                    245 	.globl _RCAP3L
                                    246 	.globl _TMR3CF
                                    247 	.globl _TMR3CN
                                    248 	.globl _SBUF1
                                    249 	.globl _SCON1
                                    250 	.globl _CPT0MD
                                    251 	.globl _CPT0CN
                                    252 	.globl _PCA0CPH1
                                    253 	.globl _PCA0CPL1
                                    254 	.globl _PCA0CPH0
                                    255 	.globl _PCA0CPL0
                                    256 	.globl _PCA0H
                                    257 	.globl _PCA0L
                                    258 	.globl _SPI0CN
                                    259 	.globl _RSTSRC
                                    260 	.globl _PCA0CPH4
                                    261 	.globl _PCA0CPL4
                                    262 	.globl _PCA0CPH3
                                    263 	.globl _PCA0CPL3
                                    264 	.globl _PCA0CPH2
                                    265 	.globl _PCA0CPL2
                                    266 	.globl _ADC0CN
                                    267 	.globl _PCA0CPH5
                                    268 	.globl _PCA0CPL5
                                    269 	.globl _PCA0CPM5
                                    270 	.globl _PCA0CPM4
                                    271 	.globl _PCA0CPM3
                                    272 	.globl _PCA0CPM2
                                    273 	.globl _PCA0CPM1
                                    274 	.globl _PCA0CPM0
                                    275 	.globl _PCA0MD
                                    276 	.globl _PCA0CN
                                    277 	.globl _DAC0CN
                                    278 	.globl _DAC0H
                                    279 	.globl _DAC0L
                                    280 	.globl _REF0CN
                                    281 	.globl _SMB0CR
                                    282 	.globl _TH2
                                    283 	.globl _TMR2H
                                    284 	.globl _TL2
                                    285 	.globl _TMR2L
                                    286 	.globl _RCAP2H
                                    287 	.globl _RCAP2L
                                    288 	.globl _TMR2CF
                                    289 	.globl _TMR2CN
                                    290 	.globl _ADC0LTH
                                    291 	.globl _ADC0LTL
                                    292 	.globl _ADC0GTH
                                    293 	.globl _ADC0GTL
                                    294 	.globl _SMB0ADR
                                    295 	.globl _SMB0DAT
                                    296 	.globl _SMB0STA
                                    297 	.globl _SMB0CN
                                    298 	.globl _ADC0H
                                    299 	.globl _ADC0L
                                    300 	.globl _ADC0CF
                                    301 	.globl _AMX0SL
                                    302 	.globl _AMX0CF
                                    303 	.globl _SADEN0
                                    304 	.globl _FLSCL
                                    305 	.globl _SADDR0
                                    306 	.globl _EMI0CF
                                    307 	.globl __XPAGE
                                    308 	.globl _EMI0CN
                                    309 	.globl _EMI0TC
                                    310 	.globl _SPI0CKR
                                    311 	.globl _SPI0DAT
                                    312 	.globl _SPI0CFG
                                    313 	.globl _SBUF
                                    314 	.globl _SBUF0
                                    315 	.globl _SCON
                                    316 	.globl _SCON0
                                    317 	.globl _SSTA0
                                    318 	.globl _PSCTL
                                    319 	.globl _CKCON
                                    320 	.globl _TH1
                                    321 	.globl _TH0
                                    322 	.globl _TL1
                                    323 	.globl _TL0
                                    324 	.globl _TMOD
                                    325 	.globl _TCON
                                    326 	.globl _WDTCN
                                    327 	.globl _EIP2
                                    328 	.globl _EIP1
                                    329 	.globl _B
                                    330 	.globl _EIE2
                                    331 	.globl _EIE1
                                    332 	.globl _ACC
                                    333 	.globl _PSW
                                    334 	.globl _IP
                                    335 	.globl _PSBANK
                                    336 	.globl _P3
                                    337 	.globl _IE
                                    338 	.globl _P2
                                    339 	.globl _P1
                                    340 	.globl _PCON
                                    341 	.globl _SFRLAST
                                    342 	.globl _SFRNEXT
                                    343 	.globl _SFRPAGE
                                    344 	.globl _DPH
                                    345 	.globl _DPL
                                    346 	.globl _SP
                                    347 	.globl _P0
                                    348 	.globl _xSerialPortInitMinimal
                                    349 	.globl _vSerialISR
                                    350 	.globl _xSerialGetChar
                                    351 	.globl _xSerialPutChar
                                    352 	.globl _vSerialClose
                                    353 ;--------------------------------------------------------
                                    354 ; special function registers
                                    355 ;--------------------------------------------------------
                                    356 	.area RSEG    (ABS,DATA)
      000000                        357 	.org 0x0000
                           000080   358 G$P0$0_0$0 == 0x0080
                           000080   359 _P0	=	0x0080
                           000081   360 G$SP$0_0$0 == 0x0081
                           000081   361 _SP	=	0x0081
                           000082   362 G$DPL$0_0$0 == 0x0082
                           000082   363 _DPL	=	0x0082
                           000083   364 G$DPH$0_0$0 == 0x0083
                           000083   365 _DPH	=	0x0083
                           000084   366 G$SFRPAGE$0_0$0 == 0x0084
                           000084   367 _SFRPAGE	=	0x0084
                           000085   368 G$SFRNEXT$0_0$0 == 0x0085
                           000085   369 _SFRNEXT	=	0x0085
                           000086   370 G$SFRLAST$0_0$0 == 0x0086
                           000086   371 _SFRLAST	=	0x0086
                           000087   372 G$PCON$0_0$0 == 0x0087
                           000087   373 _PCON	=	0x0087
                           000090   374 G$P1$0_0$0 == 0x0090
                           000090   375 _P1	=	0x0090
                           0000A0   376 G$P2$0_0$0 == 0x00a0
                           0000A0   377 _P2	=	0x00a0
                           0000A8   378 G$IE$0_0$0 == 0x00a8
                           0000A8   379 _IE	=	0x00a8
                           0000B0   380 G$P3$0_0$0 == 0x00b0
                           0000B0   381 _P3	=	0x00b0
                           0000B1   382 G$PSBANK$0_0$0 == 0x00b1
                           0000B1   383 _PSBANK	=	0x00b1
                           0000B8   384 G$IP$0_0$0 == 0x00b8
                           0000B8   385 _IP	=	0x00b8
                           0000D0   386 G$PSW$0_0$0 == 0x00d0
                           0000D0   387 _PSW	=	0x00d0
                           0000E0   388 G$ACC$0_0$0 == 0x00e0
                           0000E0   389 _ACC	=	0x00e0
                           0000E6   390 G$EIE1$0_0$0 == 0x00e6
                           0000E6   391 _EIE1	=	0x00e6
                           0000E7   392 G$EIE2$0_0$0 == 0x00e7
                           0000E7   393 _EIE2	=	0x00e7
                           0000F0   394 G$B$0_0$0 == 0x00f0
                           0000F0   395 _B	=	0x00f0
                           0000F6   396 G$EIP1$0_0$0 == 0x00f6
                           0000F6   397 _EIP1	=	0x00f6
                           0000F7   398 G$EIP2$0_0$0 == 0x00f7
                           0000F7   399 _EIP2	=	0x00f7
                           0000FF   400 G$WDTCN$0_0$0 == 0x00ff
                           0000FF   401 _WDTCN	=	0x00ff
                           000088   402 G$TCON$0_0$0 == 0x0088
                           000088   403 _TCON	=	0x0088
                           000089   404 G$TMOD$0_0$0 == 0x0089
                           000089   405 _TMOD	=	0x0089
                           00008A   406 G$TL0$0_0$0 == 0x008a
                           00008A   407 _TL0	=	0x008a
                           00008B   408 G$TL1$0_0$0 == 0x008b
                           00008B   409 _TL1	=	0x008b
                           00008C   410 G$TH0$0_0$0 == 0x008c
                           00008C   411 _TH0	=	0x008c
                           00008D   412 G$TH1$0_0$0 == 0x008d
                           00008D   413 _TH1	=	0x008d
                           00008E   414 G$CKCON$0_0$0 == 0x008e
                           00008E   415 _CKCON	=	0x008e
                           00008F   416 G$PSCTL$0_0$0 == 0x008f
                           00008F   417 _PSCTL	=	0x008f
                           000091   418 G$SSTA0$0_0$0 == 0x0091
                           000091   419 _SSTA0	=	0x0091
                           000098   420 G$SCON0$0_0$0 == 0x0098
                           000098   421 _SCON0	=	0x0098
                           000098   422 G$SCON$0_0$0 == 0x0098
                           000098   423 _SCON	=	0x0098
                           000099   424 G$SBUF0$0_0$0 == 0x0099
                           000099   425 _SBUF0	=	0x0099
                           000099   426 G$SBUF$0_0$0 == 0x0099
                           000099   427 _SBUF	=	0x0099
                           00009A   428 G$SPI0CFG$0_0$0 == 0x009a
                           00009A   429 _SPI0CFG	=	0x009a
                           00009B   430 G$SPI0DAT$0_0$0 == 0x009b
                           00009B   431 _SPI0DAT	=	0x009b
                           00009D   432 G$SPI0CKR$0_0$0 == 0x009d
                           00009D   433 _SPI0CKR	=	0x009d
                           0000A1   434 G$EMI0TC$0_0$0 == 0x00a1
                           0000A1   435 _EMI0TC	=	0x00a1
                           0000A2   436 G$EMI0CN$0_0$0 == 0x00a2
                           0000A2   437 _EMI0CN	=	0x00a2
                           0000A2   438 G$_XPAGE$0_0$0 == 0x00a2
                           0000A2   439 __XPAGE	=	0x00a2
                           0000A3   440 G$EMI0CF$0_0$0 == 0x00a3
                           0000A3   441 _EMI0CF	=	0x00a3
                           0000A9   442 G$SADDR0$0_0$0 == 0x00a9
                           0000A9   443 _SADDR0	=	0x00a9
                           0000B7   444 G$FLSCL$0_0$0 == 0x00b7
                           0000B7   445 _FLSCL	=	0x00b7
                           0000B9   446 G$SADEN0$0_0$0 == 0x00b9
                           0000B9   447 _SADEN0	=	0x00b9
                           0000BA   448 G$AMX0CF$0_0$0 == 0x00ba
                           0000BA   449 _AMX0CF	=	0x00ba
                           0000BB   450 G$AMX0SL$0_0$0 == 0x00bb
                           0000BB   451 _AMX0SL	=	0x00bb
                           0000BC   452 G$ADC0CF$0_0$0 == 0x00bc
                           0000BC   453 _ADC0CF	=	0x00bc
                           0000BE   454 G$ADC0L$0_0$0 == 0x00be
                           0000BE   455 _ADC0L	=	0x00be
                           0000BF   456 G$ADC0H$0_0$0 == 0x00bf
                           0000BF   457 _ADC0H	=	0x00bf
                           0000C0   458 G$SMB0CN$0_0$0 == 0x00c0
                           0000C0   459 _SMB0CN	=	0x00c0
                           0000C1   460 G$SMB0STA$0_0$0 == 0x00c1
                           0000C1   461 _SMB0STA	=	0x00c1
                           0000C2   462 G$SMB0DAT$0_0$0 == 0x00c2
                           0000C2   463 _SMB0DAT	=	0x00c2
                           0000C3   464 G$SMB0ADR$0_0$0 == 0x00c3
                           0000C3   465 _SMB0ADR	=	0x00c3
                           0000C4   466 G$ADC0GTL$0_0$0 == 0x00c4
                           0000C4   467 _ADC0GTL	=	0x00c4
                           0000C5   468 G$ADC0GTH$0_0$0 == 0x00c5
                           0000C5   469 _ADC0GTH	=	0x00c5
                           0000C6   470 G$ADC0LTL$0_0$0 == 0x00c6
                           0000C6   471 _ADC0LTL	=	0x00c6
                           0000C7   472 G$ADC0LTH$0_0$0 == 0x00c7
                           0000C7   473 _ADC0LTH	=	0x00c7
                           0000C8   474 G$TMR2CN$0_0$0 == 0x00c8
                           0000C8   475 _TMR2CN	=	0x00c8
                           0000C9   476 G$TMR2CF$0_0$0 == 0x00c9
                           0000C9   477 _TMR2CF	=	0x00c9
                           0000CA   478 G$RCAP2L$0_0$0 == 0x00ca
                           0000CA   479 _RCAP2L	=	0x00ca
                           0000CB   480 G$RCAP2H$0_0$0 == 0x00cb
                           0000CB   481 _RCAP2H	=	0x00cb
                           0000CC   482 G$TMR2L$0_0$0 == 0x00cc
                           0000CC   483 _TMR2L	=	0x00cc
                           0000CC   484 G$TL2$0_0$0 == 0x00cc
                           0000CC   485 _TL2	=	0x00cc
                           0000CD   486 G$TMR2H$0_0$0 == 0x00cd
                           0000CD   487 _TMR2H	=	0x00cd
                           0000CD   488 G$TH2$0_0$0 == 0x00cd
                           0000CD   489 _TH2	=	0x00cd
                           0000CF   490 G$SMB0CR$0_0$0 == 0x00cf
                           0000CF   491 _SMB0CR	=	0x00cf
                           0000D1   492 G$REF0CN$0_0$0 == 0x00d1
                           0000D1   493 _REF0CN	=	0x00d1
                           0000D2   494 G$DAC0L$0_0$0 == 0x00d2
                           0000D2   495 _DAC0L	=	0x00d2
                           0000D3   496 G$DAC0H$0_0$0 == 0x00d3
                           0000D3   497 _DAC0H	=	0x00d3
                           0000D4   498 G$DAC0CN$0_0$0 == 0x00d4
                           0000D4   499 _DAC0CN	=	0x00d4
                           0000D8   500 G$PCA0CN$0_0$0 == 0x00d8
                           0000D8   501 _PCA0CN	=	0x00d8
                           0000D9   502 G$PCA0MD$0_0$0 == 0x00d9
                           0000D9   503 _PCA0MD	=	0x00d9
                           0000DA   504 G$PCA0CPM0$0_0$0 == 0x00da
                           0000DA   505 _PCA0CPM0	=	0x00da
                           0000DB   506 G$PCA0CPM1$0_0$0 == 0x00db
                           0000DB   507 _PCA0CPM1	=	0x00db
                           0000DC   508 G$PCA0CPM2$0_0$0 == 0x00dc
                           0000DC   509 _PCA0CPM2	=	0x00dc
                           0000DD   510 G$PCA0CPM3$0_0$0 == 0x00dd
                           0000DD   511 _PCA0CPM3	=	0x00dd
                           0000DE   512 G$PCA0CPM4$0_0$0 == 0x00de
                           0000DE   513 _PCA0CPM4	=	0x00de
                           0000DF   514 G$PCA0CPM5$0_0$0 == 0x00df
                           0000DF   515 _PCA0CPM5	=	0x00df
                           0000E1   516 G$PCA0CPL5$0_0$0 == 0x00e1
                           0000E1   517 _PCA0CPL5	=	0x00e1
                           0000E2   518 G$PCA0CPH5$0_0$0 == 0x00e2
                           0000E2   519 _PCA0CPH5	=	0x00e2
                           0000E8   520 G$ADC0CN$0_0$0 == 0x00e8
                           0000E8   521 _ADC0CN	=	0x00e8
                           0000E9   522 G$PCA0CPL2$0_0$0 == 0x00e9
                           0000E9   523 _PCA0CPL2	=	0x00e9
                           0000EA   524 G$PCA0CPH2$0_0$0 == 0x00ea
                           0000EA   525 _PCA0CPH2	=	0x00ea
                           0000EB   526 G$PCA0CPL3$0_0$0 == 0x00eb
                           0000EB   527 _PCA0CPL3	=	0x00eb
                           0000EC   528 G$PCA0CPH3$0_0$0 == 0x00ec
                           0000EC   529 _PCA0CPH3	=	0x00ec
                           0000ED   530 G$PCA0CPL4$0_0$0 == 0x00ed
                           0000ED   531 _PCA0CPL4	=	0x00ed
                           0000EE   532 G$PCA0CPH4$0_0$0 == 0x00ee
                           0000EE   533 _PCA0CPH4	=	0x00ee
                           0000EF   534 G$RSTSRC$0_0$0 == 0x00ef
                           0000EF   535 _RSTSRC	=	0x00ef
                           0000F8   536 G$SPI0CN$0_0$0 == 0x00f8
                           0000F8   537 _SPI0CN	=	0x00f8
                           0000F9   538 G$PCA0L$0_0$0 == 0x00f9
                           0000F9   539 _PCA0L	=	0x00f9
                           0000FA   540 G$PCA0H$0_0$0 == 0x00fa
                           0000FA   541 _PCA0H	=	0x00fa
                           0000FB   542 G$PCA0CPL0$0_0$0 == 0x00fb
                           0000FB   543 _PCA0CPL0	=	0x00fb
                           0000FC   544 G$PCA0CPH0$0_0$0 == 0x00fc
                           0000FC   545 _PCA0CPH0	=	0x00fc
                           0000FD   546 G$PCA0CPL1$0_0$0 == 0x00fd
                           0000FD   547 _PCA0CPL1	=	0x00fd
                           0000FE   548 G$PCA0CPH1$0_0$0 == 0x00fe
                           0000FE   549 _PCA0CPH1	=	0x00fe
                           000088   550 G$CPT0CN$0_0$0 == 0x0088
                           000088   551 _CPT0CN	=	0x0088
                           000089   552 G$CPT0MD$0_0$0 == 0x0089
                           000089   553 _CPT0MD	=	0x0089
                           000098   554 G$SCON1$0_0$0 == 0x0098
                           000098   555 _SCON1	=	0x0098
                           000099   556 G$SBUF1$0_0$0 == 0x0099
                           000099   557 _SBUF1	=	0x0099
                           0000C8   558 G$TMR3CN$0_0$0 == 0x00c8
                           0000C8   559 _TMR3CN	=	0x00c8
                           0000C9   560 G$TMR3CF$0_0$0 == 0x00c9
                           0000C9   561 _TMR3CF	=	0x00c9
                           0000CA   562 G$RCAP3L$0_0$0 == 0x00ca
                           0000CA   563 _RCAP3L	=	0x00ca
                           0000CB   564 G$RCAP3H$0_0$0 == 0x00cb
                           0000CB   565 _RCAP3H	=	0x00cb
                           0000CC   566 G$TMR3L$0_0$0 == 0x00cc
                           0000CC   567 _TMR3L	=	0x00cc
                           0000CD   568 G$TMR3H$0_0$0 == 0x00cd
                           0000CD   569 _TMR3H	=	0x00cd
                           0000D2   570 G$DAC1L$0_0$0 == 0x00d2
                           0000D2   571 _DAC1L	=	0x00d2
                           0000D3   572 G$DAC1H$0_0$0 == 0x00d3
                           0000D3   573 _DAC1H	=	0x00d3
                           0000D4   574 G$DAC1CN$0_0$0 == 0x00d4
                           0000D4   575 _DAC1CN	=	0x00d4
                           000088   576 G$CPT1CN$0_0$0 == 0x0088
                           000088   577 _CPT1CN	=	0x0088
                           000089   578 G$CPT1MD$0_0$0 == 0x0089
                           000089   579 _CPT1MD	=	0x0089
                           0000BA   580 G$AMX2CF$0_0$0 == 0x00ba
                           0000BA   581 _AMX2CF	=	0x00ba
                           0000BB   582 G$AMX2SL$0_0$0 == 0x00bb
                           0000BB   583 _AMX2SL	=	0x00bb
                           0000BC   584 G$ADC2CF$0_0$0 == 0x00bc
                           0000BC   585 _ADC2CF	=	0x00bc
                           0000BE   586 G$ADC2$0_0$0 == 0x00be
                           0000BE   587 _ADC2	=	0x00be
                           0000C4   588 G$ADC2GT$0_0$0 == 0x00c4
                           0000C4   589 _ADC2GT	=	0x00c4
                           0000C6   590 G$ADC2LT$0_0$0 == 0x00c6
                           0000C6   591 _ADC2LT	=	0x00c6
                           0000C8   592 G$TMR4CN$0_0$0 == 0x00c8
                           0000C8   593 _TMR4CN	=	0x00c8
                           0000C9   594 G$TMR4CF$0_0$0 == 0x00c9
                           0000C9   595 _TMR4CF	=	0x00c9
                           0000CA   596 G$RCAP4L$0_0$0 == 0x00ca
                           0000CA   597 _RCAP4L	=	0x00ca
                           0000CB   598 G$RCAP4H$0_0$0 == 0x00cb
                           0000CB   599 _RCAP4H	=	0x00cb
                           0000CC   600 G$TMR4L$0_0$0 == 0x00cc
                           0000CC   601 _TMR4L	=	0x00cc
                           0000CD   602 G$TMR4H$0_0$0 == 0x00cd
                           0000CD   603 _TMR4H	=	0x00cd
                           000091   604 G$MAC0BL$0_0$0 == 0x0091
                           000091   605 _MAC0BL	=	0x0091
                           000092   606 G$MAC0BH$0_0$0 == 0x0092
                           000092   607 _MAC0BH	=	0x0092
                           000093   608 G$MAC0ACC0$0_0$0 == 0x0093
                           000093   609 _MAC0ACC0	=	0x0093
                           000094   610 G$MAC0ACC1$0_0$0 == 0x0094
                           000094   611 _MAC0ACC1	=	0x0094
                           000095   612 G$MAC0ACC2$0_0$0 == 0x0095
                           000095   613 _MAC0ACC2	=	0x0095
                           000096   614 G$MAC0ACC3$0_0$0 == 0x0096
                           000096   615 _MAC0ACC3	=	0x0096
                           000097   616 G$MAC0OVR$0_0$0 == 0x0097
                           000097   617 _MAC0OVR	=	0x0097
                           0000C0   618 G$MAC0STA$0_0$0 == 0x00c0
                           0000C0   619 _MAC0STA	=	0x00c0
                           0000C1   620 G$MAC0AL$0_0$0 == 0x00c1
                           0000C1   621 _MAC0AL	=	0x00c1
                           0000C2   622 G$MAC0AH$0_0$0 == 0x00c2
                           0000C2   623 _MAC0AH	=	0x00c2
                           0000C3   624 G$MAC0CF$0_0$0 == 0x00c3
                           0000C3   625 _MAC0CF	=	0x00c3
                           0000CE   626 G$MAC0RNDL$0_0$0 == 0x00ce
                           0000CE   627 _MAC0RNDL	=	0x00ce
                           0000CF   628 G$MAC0RNDH$0_0$0 == 0x00cf
                           0000CF   629 _MAC0RNDH	=	0x00cf
                           000088   630 G$FLSTAT$0_0$0 == 0x0088
                           000088   631 _FLSTAT	=	0x0088
                           000089   632 G$PLL0CN$0_0$0 == 0x0089
                           000089   633 _PLL0CN	=	0x0089
                           00008A   634 G$OSCICN$0_0$0 == 0x008a
                           00008A   635 _OSCICN	=	0x008a
                           00008B   636 G$OSCICL$0_0$0 == 0x008b
                           00008B   637 _OSCICL	=	0x008b
                           00008C   638 G$OSCXCN$0_0$0 == 0x008c
                           00008C   639 _OSCXCN	=	0x008c
                           00008D   640 G$PLL0DIV$0_0$0 == 0x008d
                           00008D   641 _PLL0DIV	=	0x008d
                           00008E   642 G$PLL0MUL$0_0$0 == 0x008e
                           00008E   643 _PLL0MUL	=	0x008e
                           00008F   644 G$PLL0FLT$0_0$0 == 0x008f
                           00008F   645 _PLL0FLT	=	0x008f
                           000096   646 G$SFRPGCN$0_0$0 == 0x0096
                           000096   647 _SFRPGCN	=	0x0096
                           000097   648 G$CLKSEL$0_0$0 == 0x0097
                           000097   649 _CLKSEL	=	0x0097
                           00009A   650 G$CCH0MA$0_0$0 == 0x009a
                           00009A   651 _CCH0MA	=	0x009a
                           00009C   652 G$P4MDOUT$0_0$0 == 0x009c
                           00009C   653 _P4MDOUT	=	0x009c
                           00009D   654 G$P5MDOUT$0_0$0 == 0x009d
                           00009D   655 _P5MDOUT	=	0x009d
                           00009E   656 G$P6MDOUT$0_0$0 == 0x009e
                           00009E   657 _P6MDOUT	=	0x009e
                           00009F   658 G$P7MDOUT$0_0$0 == 0x009f
                           00009F   659 _P7MDOUT	=	0x009f
                           0000A1   660 G$CCH0CN$0_0$0 == 0x00a1
                           0000A1   661 _CCH0CN	=	0x00a1
                           0000A2   662 G$CCH0TN$0_0$0 == 0x00a2
                           0000A2   663 _CCH0TN	=	0x00a2
                           0000A3   664 G$CCH0LC$0_0$0 == 0x00a3
                           0000A3   665 _CCH0LC	=	0x00a3
                           0000A4   666 G$P0MDOUT$0_0$0 == 0x00a4
                           0000A4   667 _P0MDOUT	=	0x00a4
                           0000A5   668 G$P1MDOUT$0_0$0 == 0x00a5
                           0000A5   669 _P1MDOUT	=	0x00a5
                           0000A6   670 G$P2MDOUT$0_0$0 == 0x00a6
                           0000A6   671 _P2MDOUT	=	0x00a6
                           0000A7   672 G$P3MDOUT$0_0$0 == 0x00a7
                           0000A7   673 _P3MDOUT	=	0x00a7
                           0000AD   674 G$P1MDIN$0_0$0 == 0x00ad
                           0000AD   675 _P1MDIN	=	0x00ad
                           0000B7   676 G$FLACL$0_0$0 == 0x00b7
                           0000B7   677 _FLACL	=	0x00b7
                           0000C8   678 G$P4$0_0$0 == 0x00c8
                           0000C8   679 _P4	=	0x00c8
                           0000D8   680 G$P5$0_0$0 == 0x00d8
                           0000D8   681 _P5	=	0x00d8
                           0000E1   682 G$XBR0$0_0$0 == 0x00e1
                           0000E1   683 _XBR0	=	0x00e1
                           0000E2   684 G$XBR1$0_0$0 == 0x00e2
                           0000E2   685 _XBR1	=	0x00e2
                           0000E3   686 G$XBR2$0_0$0 == 0x00e3
                           0000E3   687 _XBR2	=	0x00e3
                           0000E8   688 G$ADC2CN$0_0$0 == 0x00e8
                           0000E8   689 _ADC2CN	=	0x00e8
                           0000E8   690 G$P6$0_0$0 == 0x00e8
                           0000E8   691 _P6	=	0x00e8
                           0000F8   692 G$P7$0_0$0 == 0x00f8
                           0000F8   693 _P7	=	0x00f8
                                    694 ;--------------------------------------------------------
                                    695 ; special function bits
                                    696 ;--------------------------------------------------------
                                    697 	.area RSEG    (ABS,DATA)
      000000                        698 	.org 0x0000
                           000080   699 G$P0_0$0_0$0 == 0x0080
                           000080   700 _P0_0	=	0x0080
                           000081   701 G$P0_1$0_0$0 == 0x0081
                           000081   702 _P0_1	=	0x0081
                           000082   703 G$P0_2$0_0$0 == 0x0082
                           000082   704 _P0_2	=	0x0082
                           000083   705 G$P0_3$0_0$0 == 0x0083
                           000083   706 _P0_3	=	0x0083
                           000084   707 G$P0_4$0_0$0 == 0x0084
                           000084   708 _P0_4	=	0x0084
                           000085   709 G$P0_5$0_0$0 == 0x0085
                           000085   710 _P0_5	=	0x0085
                           000086   711 G$P0_6$0_0$0 == 0x0086
                           000086   712 _P0_6	=	0x0086
                           000087   713 G$P0_7$0_0$0 == 0x0087
                           000087   714 _P0_7	=	0x0087
                           000088   715 G$IT0$0_0$0 == 0x0088
                           000088   716 _IT0	=	0x0088
                           000089   717 G$IE0$0_0$0 == 0x0089
                           000089   718 _IE0	=	0x0089
                           00008A   719 G$IT1$0_0$0 == 0x008a
                           00008A   720 _IT1	=	0x008a
                           00008B   721 G$IE1$0_0$0 == 0x008b
                           00008B   722 _IE1	=	0x008b
                           00008C   723 G$TR0$0_0$0 == 0x008c
                           00008C   724 _TR0	=	0x008c
                           00008D   725 G$TF0$0_0$0 == 0x008d
                           00008D   726 _TF0	=	0x008d
                           00008E   727 G$TR1$0_0$0 == 0x008e
                           00008E   728 _TR1	=	0x008e
                           00008F   729 G$TF1$0_0$0 == 0x008f
                           00008F   730 _TF1	=	0x008f
                           000088   731 G$CP0HYN0$0_0$0 == 0x0088
                           000088   732 _CP0HYN0	=	0x0088
                           000089   733 G$CP0HYN1$0_0$0 == 0x0089
                           000089   734 _CP0HYN1	=	0x0089
                           00008A   735 G$CP0HYP0$0_0$0 == 0x008a
                           00008A   736 _CP0HYP0	=	0x008a
                           00008B   737 G$CP0HYP1$0_0$0 == 0x008b
                           00008B   738 _CP0HYP1	=	0x008b
                           00008C   739 G$CP0FIF$0_0$0 == 0x008c
                           00008C   740 _CP0FIF	=	0x008c
                           00008D   741 G$CP0RIF$0_0$0 == 0x008d
                           00008D   742 _CP0RIF	=	0x008d
                           00008E   743 G$CP0OUT$0_0$0 == 0x008e
                           00008E   744 _CP0OUT	=	0x008e
                           00008F   745 G$CP0EN$0_0$0 == 0x008f
                           00008F   746 _CP0EN	=	0x008f
                           000088   747 G$CP1HYN0$0_0$0 == 0x0088
                           000088   748 _CP1HYN0	=	0x0088
                           000089   749 G$CP1HYN1$0_0$0 == 0x0089
                           000089   750 _CP1HYN1	=	0x0089
                           00008A   751 G$CP1HYP0$0_0$0 == 0x008a
                           00008A   752 _CP1HYP0	=	0x008a
                           00008B   753 G$CP1HYP1$0_0$0 == 0x008b
                           00008B   754 _CP1HYP1	=	0x008b
                           00008C   755 G$CP1FIF$0_0$0 == 0x008c
                           00008C   756 _CP1FIF	=	0x008c
                           00008D   757 G$CP1RIF$0_0$0 == 0x008d
                           00008D   758 _CP1RIF	=	0x008d
                           00008E   759 G$CP1OUT$0_0$0 == 0x008e
                           00008E   760 _CP1OUT	=	0x008e
                           00008F   761 G$CP1EN$0_0$0 == 0x008f
                           00008F   762 _CP1EN	=	0x008f
                           000088   763 G$FLHBUSY$0_0$0 == 0x0088
                           000088   764 _FLHBUSY	=	0x0088
                           000098   765 G$RI0$0_0$0 == 0x0098
                           000098   766 _RI0	=	0x0098
                           000098   767 G$RI$0_0$0 == 0x0098
                           000098   768 _RI	=	0x0098
                           000099   769 G$TI0$0_0$0 == 0x0099
                           000099   770 _TI0	=	0x0099
                           000099   771 G$TI$0_0$0 == 0x0099
                           000099   772 _TI	=	0x0099
                           00009A   773 G$RB80$0_0$0 == 0x009a
                           00009A   774 _RB80	=	0x009a
                           00009B   775 G$TB80$0_0$0 == 0x009b
                           00009B   776 _TB80	=	0x009b
                           00009C   777 G$REN0$0_0$0 == 0x009c
                           00009C   778 _REN0	=	0x009c
                           00009C   779 G$REN$0_0$0 == 0x009c
                           00009C   780 _REN	=	0x009c
                           00009D   781 G$SM20$0_0$0 == 0x009d
                           00009D   782 _SM20	=	0x009d
                           00009E   783 G$SM10$0_0$0 == 0x009e
                           00009E   784 _SM10	=	0x009e
                           00009F   785 G$SM00$0_0$0 == 0x009f
                           00009F   786 _SM00	=	0x009f
                           000098   787 G$RI1$0_0$0 == 0x0098
                           000098   788 _RI1	=	0x0098
                           000099   789 G$TI1$0_0$0 == 0x0099
                           000099   790 _TI1	=	0x0099
                           00009A   791 G$RB81$0_0$0 == 0x009a
                           00009A   792 _RB81	=	0x009a
                           00009B   793 G$TB81$0_0$0 == 0x009b
                           00009B   794 _TB81	=	0x009b
                           00009C   795 G$REN1$0_0$0 == 0x009c
                           00009C   796 _REN1	=	0x009c
                           00009D   797 G$MCE1$0_0$0 == 0x009d
                           00009D   798 _MCE1	=	0x009d
                           00009F   799 G$S1MODE$0_0$0 == 0x009f
                           00009F   800 _S1MODE	=	0x009f
                           0000A8   801 G$EX0$0_0$0 == 0x00a8
                           0000A8   802 _EX0	=	0x00a8
                           0000A9   803 G$ET0$0_0$0 == 0x00a9
                           0000A9   804 _ET0	=	0x00a9
                           0000AA   805 G$EX1$0_0$0 == 0x00aa
                           0000AA   806 _EX1	=	0x00aa
                           0000AB   807 G$ET1$0_0$0 == 0x00ab
                           0000AB   808 _ET1	=	0x00ab
                           0000AC   809 G$ES0$0_0$0 == 0x00ac
                           0000AC   810 _ES0	=	0x00ac
                           0000AC   811 G$ES$0_0$0 == 0x00ac
                           0000AC   812 _ES	=	0x00ac
                           0000AD   813 G$ET2$0_0$0 == 0x00ad
                           0000AD   814 _ET2	=	0x00ad
                           0000AF   815 G$EA$0_0$0 == 0x00af
                           0000AF   816 _EA	=	0x00af
                           0000B8   817 G$PX0$0_0$0 == 0x00b8
                           0000B8   818 _PX0	=	0x00b8
                           0000B9   819 G$PT0$0_0$0 == 0x00b9
                           0000B9   820 _PT0	=	0x00b9
                           0000BA   821 G$PX1$0_0$0 == 0x00ba
                           0000BA   822 _PX1	=	0x00ba
                           0000BB   823 G$PT1$0_0$0 == 0x00bb
                           0000BB   824 _PT1	=	0x00bb
                           0000BC   825 G$PS$0_0$0 == 0x00bc
                           0000BC   826 _PS	=	0x00bc
                           0000BD   827 G$PT2$0_0$0 == 0x00bd
                           0000BD   828 _PT2	=	0x00bd
                           0000C0   829 G$SMBTOE$0_0$0 == 0x00c0
                           0000C0   830 _SMBTOE	=	0x00c0
                           0000C1   831 G$SMBFTE$0_0$0 == 0x00c1
                           0000C1   832 _SMBFTE	=	0x00c1
                           0000C2   833 G$AA$0_0$0 == 0x00c2
                           0000C2   834 _AA	=	0x00c2
                           0000C3   835 G$SI$0_0$0 == 0x00c3
                           0000C3   836 _SI	=	0x00c3
                           0000C4   837 G$STO$0_0$0 == 0x00c4
                           0000C4   838 _STO	=	0x00c4
                           0000C5   839 G$STA$0_0$0 == 0x00c5
                           0000C5   840 _STA	=	0x00c5
                           0000C6   841 G$ENSMB$0_0$0 == 0x00c6
                           0000C6   842 _ENSMB	=	0x00c6
                           0000C7   843 G$BUSY$0_0$0 == 0x00c7
                           0000C7   844 _BUSY	=	0x00c7
                           0000C8   845 G$CPRL2$0_0$0 == 0x00c8
                           0000C8   846 _CPRL2	=	0x00c8
                           0000C9   847 G$CT2$0_0$0 == 0x00c9
                           0000C9   848 _CT2	=	0x00c9
                           0000CA   849 G$TR2$0_0$0 == 0x00ca
                           0000CA   850 _TR2	=	0x00ca
                           0000CB   851 G$EXEN2$0_0$0 == 0x00cb
                           0000CB   852 _EXEN2	=	0x00cb
                           0000CE   853 G$EXF2$0_0$0 == 0x00ce
                           0000CE   854 _EXF2	=	0x00ce
                           0000CF   855 G$TF2$0_0$0 == 0x00cf
                           0000CF   856 _TF2	=	0x00cf
                           0000C8   857 G$CPRL3$0_0$0 == 0x00c8
                           0000C8   858 _CPRL3	=	0x00c8
                           0000C9   859 G$CT3$0_0$0 == 0x00c9
                           0000C9   860 _CT3	=	0x00c9
                           0000CA   861 G$TR3$0_0$0 == 0x00ca
                           0000CA   862 _TR3	=	0x00ca
                           0000CB   863 G$EXEN3$0_0$0 == 0x00cb
                           0000CB   864 _EXEN3	=	0x00cb
                           0000CE   865 G$EXF3$0_0$0 == 0x00ce
                           0000CE   866 _EXF3	=	0x00ce
                           0000CF   867 G$TF3$0_0$0 == 0x00cf
                           0000CF   868 _TF3	=	0x00cf
                           0000C8   869 G$CPRL4$0_0$0 == 0x00c8
                           0000C8   870 _CPRL4	=	0x00c8
                           0000C9   871 G$CT4$0_0$0 == 0x00c9
                           0000C9   872 _CT4	=	0x00c9
                           0000CA   873 G$TR4$0_0$0 == 0x00ca
                           0000CA   874 _TR4	=	0x00ca
                           0000CB   875 G$EXEN4$0_0$0 == 0x00cb
                           0000CB   876 _EXEN4	=	0x00cb
                           0000CE   877 G$EXF4$0_0$0 == 0x00ce
                           0000CE   878 _EXF4	=	0x00ce
                           0000CF   879 G$TF4$0_0$0 == 0x00cf
                           0000CF   880 _TF4	=	0x00cf
                           0000C8   881 G$P4_0$0_0$0 == 0x00c8
                           0000C8   882 _P4_0	=	0x00c8
                           0000C9   883 G$P4_1$0_0$0 == 0x00c9
                           0000C9   884 _P4_1	=	0x00c9
                           0000CA   885 G$P4_2$0_0$0 == 0x00ca
                           0000CA   886 _P4_2	=	0x00ca
                           0000CB   887 G$P4_3$0_0$0 == 0x00cb
                           0000CB   888 _P4_3	=	0x00cb
                           0000CC   889 G$P4_4$0_0$0 == 0x00cc
                           0000CC   890 _P4_4	=	0x00cc
                           0000CD   891 G$P4_5$0_0$0 == 0x00cd
                           0000CD   892 _P4_5	=	0x00cd
                           0000CE   893 G$P4_6$0_0$0 == 0x00ce
                           0000CE   894 _P4_6	=	0x00ce
                           0000CF   895 G$P4_7$0_0$0 == 0x00cf
                           0000CF   896 _P4_7	=	0x00cf
                           0000D0   897 G$P$0_0$0 == 0x00d0
                           0000D0   898 _P	=	0x00d0
                           0000D1   899 G$F1$0_0$0 == 0x00d1
                           0000D1   900 _F1	=	0x00d1
                           0000D2   901 G$OV$0_0$0 == 0x00d2
                           0000D2   902 _OV	=	0x00d2
                           0000D3   903 G$RS0$0_0$0 == 0x00d3
                           0000D3   904 _RS0	=	0x00d3
                           0000D4   905 G$RS1$0_0$0 == 0x00d4
                           0000D4   906 _RS1	=	0x00d4
                           0000D5   907 G$F0$0_0$0 == 0x00d5
                           0000D5   908 _F0	=	0x00d5
                           0000D6   909 G$AC$0_0$0 == 0x00d6
                           0000D6   910 _AC	=	0x00d6
                           0000D7   911 G$CY$0_0$0 == 0x00d7
                           0000D7   912 _CY	=	0x00d7
                           0000D8   913 G$CCF0$0_0$0 == 0x00d8
                           0000D8   914 _CCF0	=	0x00d8
                           0000D9   915 G$CCF1$0_0$0 == 0x00d9
                           0000D9   916 _CCF1	=	0x00d9
                           0000DA   917 G$CCF2$0_0$0 == 0x00da
                           0000DA   918 _CCF2	=	0x00da
                           0000DB   919 G$CCF3$0_0$0 == 0x00db
                           0000DB   920 _CCF3	=	0x00db
                           0000DC   921 G$CCF4$0_0$0 == 0x00dc
                           0000DC   922 _CCF4	=	0x00dc
                           0000DD   923 G$CCF5$0_0$0 == 0x00dd
                           0000DD   924 _CCF5	=	0x00dd
                           0000DE   925 G$CR$0_0$0 == 0x00de
                           0000DE   926 _CR	=	0x00de
                           0000DF   927 G$CF$0_0$0 == 0x00df
                           0000DF   928 _CF	=	0x00df
                           0000D8   929 G$P5_0$0_0$0 == 0x00d8
                           0000D8   930 _P5_0	=	0x00d8
                           0000D9   931 G$P5_1$0_0$0 == 0x00d9
                           0000D9   932 _P5_1	=	0x00d9
                           0000DA   933 G$P5_2$0_0$0 == 0x00da
                           0000DA   934 _P5_2	=	0x00da
                           0000DB   935 G$P5_3$0_0$0 == 0x00db
                           0000DB   936 _P5_3	=	0x00db
                           0000DC   937 G$P5_4$0_0$0 == 0x00dc
                           0000DC   938 _P5_4	=	0x00dc
                           0000DD   939 G$P5_5$0_0$0 == 0x00dd
                           0000DD   940 _P5_5	=	0x00dd
                           0000DE   941 G$P5_6$0_0$0 == 0x00de
                           0000DE   942 _P5_6	=	0x00de
                           0000DF   943 G$P5_7$0_0$0 == 0x00df
                           0000DF   944 _P5_7	=	0x00df
                           0000E8   945 G$AD0LJST$0_0$0 == 0x00e8
                           0000E8   946 _AD0LJST	=	0x00e8
                           0000E9   947 G$AD0WINT$0_0$0 == 0x00e9
                           0000E9   948 _AD0WINT	=	0x00e9
                           0000EA   949 G$AD0CM0$0_0$0 == 0x00ea
                           0000EA   950 _AD0CM0	=	0x00ea
                           0000EB   951 G$AD0CM1$0_0$0 == 0x00eb
                           0000EB   952 _AD0CM1	=	0x00eb
                           0000EC   953 G$AD0BUSY$0_0$0 == 0x00ec
                           0000EC   954 _AD0BUSY	=	0x00ec
                           0000ED   955 G$AD0INT$0_0$0 == 0x00ed
                           0000ED   956 _AD0INT	=	0x00ed
                           0000EE   957 G$AD0TM$0_0$0 == 0x00ee
                           0000EE   958 _AD0TM	=	0x00ee
                           0000EF   959 G$AD0EN$0_0$0 == 0x00ef
                           0000EF   960 _AD0EN	=	0x00ef
                           0000E8   961 G$AD2WINT$0_0$0 == 0x00e8
                           0000E8   962 _AD2WINT	=	0x00e8
                           0000E9   963 G$AD2CM0$0_0$0 == 0x00e9
                           0000E9   964 _AD2CM0	=	0x00e9
                           0000EA   965 G$AD2CM1$0_0$0 == 0x00ea
                           0000EA   966 _AD2CM1	=	0x00ea
                           0000EB   967 G$AD2CM2$0_0$0 == 0x00eb
                           0000EB   968 _AD2CM2	=	0x00eb
                           0000EC   969 G$AD2BUSY$0_0$0 == 0x00ec
                           0000EC   970 _AD2BUSY	=	0x00ec
                           0000ED   971 G$AD2INT$0_0$0 == 0x00ed
                           0000ED   972 _AD2INT	=	0x00ed
                           0000EE   973 G$AD2TM$0_0$0 == 0x00ee
                           0000EE   974 _AD2TM	=	0x00ee
                           0000EF   975 G$AD2EN$0_0$0 == 0x00ef
                           0000EF   976 _AD2EN	=	0x00ef
                           0000E8   977 G$P6_0$0_0$0 == 0x00e8
                           0000E8   978 _P6_0	=	0x00e8
                           0000E9   979 G$P6_1$0_0$0 == 0x00e9
                           0000E9   980 _P6_1	=	0x00e9
                           0000EA   981 G$P6_2$0_0$0 == 0x00ea
                           0000EA   982 _P6_2	=	0x00ea
                           0000EB   983 G$P6_3$0_0$0 == 0x00eb
                           0000EB   984 _P6_3	=	0x00eb
                           0000EC   985 G$P6_4$0_0$0 == 0x00ec
                           0000EC   986 _P6_4	=	0x00ec
                           0000ED   987 G$P6_5$0_0$0 == 0x00ed
                           0000ED   988 _P6_5	=	0x00ed
                           0000EE   989 G$P6_6$0_0$0 == 0x00ee
                           0000EE   990 _P6_6	=	0x00ee
                           0000EF   991 G$P6_7$0_0$0 == 0x00ef
                           0000EF   992 _P6_7	=	0x00ef
                           0000F8   993 G$SPIEN$0_0$0 == 0x00f8
                           0000F8   994 _SPIEN	=	0x00f8
                           0000F9   995 G$TXBMT$0_0$0 == 0x00f9
                           0000F9   996 _TXBMT	=	0x00f9
                           0000FA   997 G$NSSMD0$0_0$0 == 0x00fa
                           0000FA   998 _NSSMD0	=	0x00fa
                           0000FB   999 G$NSSMD1$0_0$0 == 0x00fb
                           0000FB  1000 _NSSMD1	=	0x00fb
                           0000FC  1001 G$RXOVRN$0_0$0 == 0x00fc
                           0000FC  1002 _RXOVRN	=	0x00fc
                           0000FD  1003 G$MODF$0_0$0 == 0x00fd
                           0000FD  1004 _MODF	=	0x00fd
                           0000FE  1005 G$WCOL$0_0$0 == 0x00fe
                           0000FE  1006 _WCOL	=	0x00fe
                           0000FF  1007 G$SPIF$0_0$0 == 0x00ff
                           0000FF  1008 _SPIF	=	0x00ff
                           0000F8  1009 G$P7_0$0_0$0 == 0x00f8
                           0000F8  1010 _P7_0	=	0x00f8
                           0000F9  1011 G$P7_1$0_0$0 == 0x00f9
                           0000F9  1012 _P7_1	=	0x00f9
                           0000FA  1013 G$P7_2$0_0$0 == 0x00fa
                           0000FA  1014 _P7_2	=	0x00fa
                           0000FB  1015 G$P7_3$0_0$0 == 0x00fb
                           0000FB  1016 _P7_3	=	0x00fb
                           0000FC  1017 G$P7_4$0_0$0 == 0x00fc
                           0000FC  1018 _P7_4	=	0x00fc
                           0000FD  1019 G$P7_5$0_0$0 == 0x00fd
                           0000FD  1020 _P7_5	=	0x00fd
                           0000FE  1021 G$P7_6$0_0$0 == 0x00fe
                           0000FE  1022 _P7_6	=	0x00fe
                           0000FF  1023 G$P7_7$0_0$0 == 0x00ff
                           0000FF  1024 _P7_7	=	0x00ff
                                   1025 ;--------------------------------------------------------
                                   1026 ; overlayable register banks
                                   1027 ;--------------------------------------------------------
                                   1028 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                       1029 	.ds 8
                                   1030 ;--------------------------------------------------------
                                   1031 ; overlayable bit register bank
                                   1032 ;--------------------------------------------------------
                                   1033 	.area BIT_BANK	(REL,OVR,DATA)
      000020                       1034 bits:
      000020                       1035 	.ds 1
                           008000  1036 	b0 = bits[0]
                           008100  1037 	b1 = bits[1]
                           008200  1038 	b2 = bits[2]
                           008300  1039 	b3 = bits[3]
                           008400  1040 	b4 = bits[4]
                           008500  1041 	b5 = bits[5]
                           008600  1042 	b6 = bits[6]
                           008700  1043 	b7 = bits[7]
                                   1044 ;--------------------------------------------------------
                                   1045 ; internal ram data
                                   1046 ;--------------------------------------------------------
                                   1047 	.area DSEG    (DATA)
                           000000  1048 Fserial$uxTxEmpty$0_0$0==.
      000008                       1049 _uxTxEmpty:
      000008                       1050 	.ds 1
                                   1051 ;--------------------------------------------------------
                                   1052 ; overlayable items in internal ram 
                                   1053 ;--------------------------------------------------------
                                   1054 ;--------------------------------------------------------
                                   1055 ; indirectly addressable internal ram data
                                   1056 ;--------------------------------------------------------
                                   1057 	.area ISEG    (DATA)
                                   1058 ;--------------------------------------------------------
                                   1059 ; absolute internal ram data
                                   1060 ;--------------------------------------------------------
                                   1061 	.area IABS    (ABS,DATA)
                                   1062 	.area IABS    (ABS,DATA)
                                   1063 ;--------------------------------------------------------
                                   1064 ; bit data
                                   1065 ;--------------------------------------------------------
                                   1066 	.area BSEG    (BIT)
                                   1067 ;--------------------------------------------------------
                                   1068 ; paged external ram data
                                   1069 ;--------------------------------------------------------
                                   1070 	.area PSEG    (PAG,XDATA)
                                   1071 ;--------------------------------------------------------
                                   1072 ; external ram data
                                   1073 ;--------------------------------------------------------
                                   1074 	.area XSEG    (XDATA)
                           000000  1075 Fserial$xRxedChars$0_0$0==.
      000002                       1076 _xRxedChars:
      000002                       1077 	.ds 3
                           000003  1078 Fserial$xCharsForTx$0_0$0==.
      000005                       1079 _xCharsForTx:
      000005                       1080 	.ds 3
                                   1081 ;--------------------------------------------------------
                                   1082 ; absolute external ram data
                                   1083 ;--------------------------------------------------------
                                   1084 	.area XABS    (ABS,XDATA)
                                   1085 ;--------------------------------------------------------
                                   1086 ; external initialized ram data
                                   1087 ;--------------------------------------------------------
                                   1088 	.area XISEG   (XDATA)
                                   1089 	.area HOME    (CODE)
                                   1090 	.area GSINIT0 (CODE)
                                   1091 	.area GSINIT1 (CODE)
                                   1092 	.area GSINIT2 (CODE)
                                   1093 	.area GSINIT3 (CODE)
                                   1094 	.area GSINIT4 (CODE)
                                   1095 	.area GSINIT5 (CODE)
                                   1096 	.area GSINIT  (CODE)
                                   1097 	.area GSFINAL (CODE)
                                   1098 	.area CSEG    (CODE)
                                   1099 ;--------------------------------------------------------
                                   1100 ; global & static initialisations
                                   1101 ;--------------------------------------------------------
                                   1102 	.area HOME    (CODE)
                                   1103 	.area GSINIT  (CODE)
                                   1104 	.area GSFINAL (CODE)
                                   1105 	.area GSINIT  (CODE)
                                   1106 ;--------------------------------------------------------
                                   1107 ; Home
                                   1108 ;--------------------------------------------------------
                                   1109 	.area HOME    (CODE)
                                   1110 	.area HOME    (CODE)
                                   1111 ;--------------------------------------------------------
                                   1112 ; code
                                   1113 ;--------------------------------------------------------
                                   1114 	.area CSEG    (CODE)
                                   1115 ;------------------------------------------------------------
                                   1116 ;Allocation info for local variables in function 'xSerialPortInitMinimal'
                                   1117 ;------------------------------------------------------------
                                   1118 ;uxQueueLength             Allocated to stack - _bp -3
                                   1119 ;ulWantedBaud              Allocated to stack - _bp +1
                                   1120 ;ulReloadValue             Allocated to registers r7 
                                   1121 ;fBaudConst                Allocated to registers 
                                   1122 ;ucOriginalSFRPage         Allocated to stack - _bp +5
                                   1123 ;------------------------------------------------------------
                           000000  1124 	G$xSerialPortInitMinimal$0$0 ==.
                           000000  1125 	C$serial.c$53$0_0$155 ==.
                                   1126 ;	serial/serial.c:53: xComPortHandle xSerialPortInitMinimal( unsigned long ulWantedBaud, unsigned portBASE_TYPE uxQueueLength )
                                   1127 ;	-----------------------------------------
                                   1128 ;	 function xSerialPortInitMinimal
                                   1129 ;	-----------------------------------------
      0009C8                       1130 _xSerialPortInitMinimal:
                           000007  1131 	ar7 = 0x07
                           000006  1132 	ar6 = 0x06
                           000005  1133 	ar5 = 0x05
                           000004  1134 	ar4 = 0x04
                           000003  1135 	ar3 = 0x03
                           000002  1136 	ar2 = 0x02
                           000001  1137 	ar1 = 0x01
                           000000  1138 	ar0 = 0x00
      0009C8 C0 0D            [24] 1139 	push	_bp
      0009CA 85 81 0D         [24] 1140 	mov	_bp,sp
      0009CD C0 82            [24] 1141 	push	dpl
      0009CF C0 83            [24] 1142 	push	dph
      0009D1 C0 F0            [24] 1143 	push	b
      0009D3 C0 E0            [24] 1144 	push	acc
      0009D5 05 81            [12] 1145 	inc	sp
                           00000F  1146 	C$serial.c$59$1_0$155 ==.
                                   1147 ;	serial/serial.c:59: portENTER_CRITICAL();
      0009D7 C0 E0            [24] 1148 	push ACC 
      0009D9 C0 A8            [24] 1149 	push IE 
                                   1150 ;	assignBit
      0009DB C2 AF            [12] 1151 	clr	_EA
                           000015  1152 	C$serial.c$61$2_0$156 ==.
                                   1153 ;	serial/serial.c:61: ucOriginalSFRPage = SFRPAGE;
      0009DD E5 0D            [12] 1154 	mov	a,_bp
      0009DF 24 05            [12] 1155 	add	a,#0x05
      0009E1 F8               [12] 1156 	mov	r0,a
      0009E2 A6 84            [24] 1157 	mov	@r0,_SFRPAGE
                           00001C  1158 	C$serial.c$62$2_0$156 ==.
                                   1159 ;	serial/serial.c:62: SFRPAGE = 0;
      0009E4 75 84 00         [24] 1160 	mov	_SFRPAGE,#0x00
                           00001F  1161 	C$serial.c$64$2_0$156 ==.
                                   1162 ;	serial/serial.c:64: uxTxEmpty = pdTRUE;
      0009E7 75 08 01         [24] 1163 	mov	_uxTxEmpty,#0x01
                           000022  1164 	C$serial.c$67$2_0$156 ==.
                                   1165 ;	serial/serial.c:67: xRxedChars = xQueueCreate( uxQueueLength, ( unsigned portBASE_TYPE ) sizeof( char ) );
      0009EA 74 00            [12] 1166 	mov	a,#0x00
      0009EC C0 E0            [24] 1167 	push	acc
      0009EE 04               [12] 1168 	inc	a
      0009EF C0 E0            [24] 1169 	push	acc
      0009F1 E5 0D            [12] 1170 	mov	a,_bp
      0009F3 24 FD            [12] 1171 	add	a,#0xfd
      0009F5 F8               [12] 1172 	mov	r0,a
      0009F6 86 82            [24] 1173 	mov	dpl,@r0
      0009F8 12 45 FB         [24] 1174 	lcall	_xQueueGenericCreate
      0009FB AA 82            [24] 1175 	mov	r2,dpl
      0009FD AB 83            [24] 1176 	mov	r3,dph
      0009FF AF F0            [24] 1177 	mov	r7,b
      000A01 15 81            [12] 1178 	dec	sp
      000A03 15 81            [12] 1179 	dec	sp
      000A05 90 00 02         [24] 1180 	mov	dptr,#_xRxedChars
      000A08 EA               [12] 1181 	mov	a,r2
      000A09 F0               [24] 1182 	movx	@dptr,a
      000A0A EB               [12] 1183 	mov	a,r3
      000A0B A3               [24] 1184 	inc	dptr
      000A0C F0               [24] 1185 	movx	@dptr,a
      000A0D EF               [12] 1186 	mov	a,r7
      000A0E A3               [24] 1187 	inc	dptr
      000A0F F0               [24] 1188 	movx	@dptr,a
                           000048  1189 	C$serial.c$68$2_0$156 ==.
                                   1190 ;	serial/serial.c:68: xCharsForTx = xQueueCreate( uxQueueLength, ( unsigned portBASE_TYPE ) sizeof( char ) );
      000A10 74 00            [12] 1191 	mov	a,#0x00
      000A12 C0 E0            [24] 1192 	push	acc
      000A14 04               [12] 1193 	inc	a
      000A15 C0 E0            [24] 1194 	push	acc
      000A17 E5 0D            [12] 1195 	mov	a,_bp
      000A19 24 FD            [12] 1196 	add	a,#0xfd
      000A1B F8               [12] 1197 	mov	r0,a
      000A1C 86 82            [24] 1198 	mov	dpl,@r0
      000A1E 12 45 FB         [24] 1199 	lcall	_xQueueGenericCreate
      000A21 AD 82            [24] 1200 	mov	r5,dpl
      000A23 AE 83            [24] 1201 	mov	r6,dph
      000A25 AF F0            [24] 1202 	mov	r7,b
      000A27 15 81            [12] 1203 	dec	sp
      000A29 15 81            [12] 1204 	dec	sp
      000A2B 90 00 05         [24] 1205 	mov	dptr,#_xCharsForTx
      000A2E ED               [12] 1206 	mov	a,r5
      000A2F F0               [24] 1207 	movx	@dptr,a
      000A30 EE               [12] 1208 	mov	a,r6
      000A31 A3               [24] 1209 	inc	dptr
      000A32 F0               [24] 1210 	movx	@dptr,a
      000A33 EF               [12] 1211 	mov	a,r7
      000A34 A3               [24] 1212 	inc	dptr
      000A35 F0               [24] 1213 	movx	@dptr,a
                           00006E  1214 	C$serial.c$71$2_0$156 ==.
                                   1215 ;	serial/serial.c:71: ulReloadValue = ( unsigned long ) ( ( ( portFLOAT ) 256 - ( fBaudConst / ( portFLOAT ) ( 32 * ulWantedBaud ) ) ) + ( portFLOAT ) 0.5 );
      000A36 A8 0D            [24] 1216 	mov	r0,_bp
      000A38 08               [12] 1217 	inc	r0
      000A39 08               [12] 1218 	inc	r0
      000A3A 08               [12] 1219 	inc	r0
      000A3B 86 06            [24] 1220 	mov	ar6,@r0
      000A3D 08               [12] 1221 	inc	r0
      000A3E E6               [12] 1222 	mov	a,@r0
      000A3F C4               [12] 1223 	swap	a
      000A40 23               [12] 1224 	rl	a
      000A41 54 E0            [12] 1225 	anl	a,#0xe0
      000A43 CE               [12] 1226 	xch	a,r6
      000A44 C4               [12] 1227 	swap	a
      000A45 23               [12] 1228 	rl	a
      000A46 CE               [12] 1229 	xch	a,r6
      000A47 6E               [12] 1230 	xrl	a,r6
      000A48 CE               [12] 1231 	xch	a,r6
      000A49 54 E0            [12] 1232 	anl	a,#0xe0
      000A4B CE               [12] 1233 	xch	a,r6
      000A4C 6E               [12] 1234 	xrl	a,r6
      000A4D FF               [12] 1235 	mov	r7,a
      000A4E 18               [12] 1236 	dec	r0
      000A4F 18               [12] 1237 	dec	r0
      000A50 E6               [12] 1238 	mov	a,@r0
      000A51 C4               [12] 1239 	swap	a
      000A52 23               [12] 1240 	rl	a
      000A53 54 1F            [12] 1241 	anl	a,#0x1f
      000A55 4E               [12] 1242 	orl	a,r6
      000A56 FE               [12] 1243 	mov	r6,a
      000A57 18               [12] 1244 	dec	r0
      000A58 86 04            [24] 1245 	mov	ar4,@r0
      000A5A 08               [12] 1246 	inc	r0
      000A5B E6               [12] 1247 	mov	a,@r0
      000A5C C4               [12] 1248 	swap	a
      000A5D 23               [12] 1249 	rl	a
      000A5E 54 E0            [12] 1250 	anl	a,#0xe0
      000A60 CC               [12] 1251 	xch	a,r4
      000A61 C4               [12] 1252 	swap	a
      000A62 23               [12] 1253 	rl	a
      000A63 CC               [12] 1254 	xch	a,r4
      000A64 6C               [12] 1255 	xrl	a,r4
      000A65 CC               [12] 1256 	xch	a,r4
      000A66 54 E0            [12] 1257 	anl	a,#0xe0
      000A68 CC               [12] 1258 	xch	a,r4
      000A69 6C               [12] 1259 	xrl	a,r4
      000A6A FD               [12] 1260 	mov	r5,a
      000A6B 8C 82            [24] 1261 	mov	dpl,r4
      000A6D 8D 83            [24] 1262 	mov	dph,r5
      000A6F 8E F0            [24] 1263 	mov	b,r6
      000A71 EF               [12] 1264 	mov	a,r7
      000A72 12 6A A6         [24] 1265 	lcall	___ulong2fs
      000A75 AC 82            [24] 1266 	mov	r4,dpl
      000A77 AD 83            [24] 1267 	mov	r5,dph
      000A79 AE F0            [24] 1268 	mov	r6,b
      000A7B FF               [12] 1269 	mov	r7,a
      000A7C C0 04            [24] 1270 	push	ar4
      000A7E C0 05            [24] 1271 	push	ar5
      000A80 C0 06            [24] 1272 	push	ar6
      000A82 C0 07            [24] 1273 	push	ar7
      000A84 75 82 90         [24] 1274 	mov	dpl,#0x90
      000A87 75 83 EB         [24] 1275 	mov	dph,#0xeb
      000A8A 75 F0 3A         [24] 1276 	mov	b,#0x3a
      000A8D 74 4D            [12] 1277 	mov	a,#0x4d
      000A8F 12 6F 6D         [24] 1278 	lcall	___fsdiv
      000A92 AC 82            [24] 1279 	mov	r4,dpl
      000A94 AD 83            [24] 1280 	mov	r5,dph
      000A96 AE F0            [24] 1281 	mov	r6,b
      000A98 FF               [12] 1282 	mov	r7,a
      000A99 E5 81            [12] 1283 	mov	a,sp
      000A9B 24 FC            [12] 1284 	add	a,#0xfc
      000A9D F5 81            [12] 1285 	mov	sp,a
      000A9F C0 04            [24] 1286 	push	ar4
      000AA1 C0 05            [24] 1287 	push	ar5
      000AA3 C0 06            [24] 1288 	push	ar6
      000AA5 C0 07            [24] 1289 	push	ar7
      000AA7 75 82 00         [24] 1290 	mov	dpl,#0x00
      000AAA 75 83 40         [24] 1291 	mov	dph,#0x40
      000AAD 75 F0 80         [24] 1292 	mov	b,#0x80
      000AB0 74 43            [12] 1293 	mov	a,#0x43
      000AB2 12 6A 9B         [24] 1294 	lcall	___fssub
      000AB5 AC 82            [24] 1295 	mov	r4,dpl
      000AB7 AD 83            [24] 1296 	mov	r5,dph
      000AB9 AE F0            [24] 1297 	mov	r6,b
      000ABB FF               [12] 1298 	mov	r7,a
      000ABC E5 81            [12] 1299 	mov	a,sp
      000ABE 24 FC            [12] 1300 	add	a,#0xfc
      000AC0 F5 81            [12] 1301 	mov	sp,a
      000AC2 8C 82            [24] 1302 	mov	dpl,r4
      000AC4 8D 83            [24] 1303 	mov	dph,r5
      000AC6 8E F0            [24] 1304 	mov	b,r6
      000AC8 EF               [12] 1305 	mov	a,r7
      000AC9 12 6A B9         [24] 1306 	lcall	___fs2ulong
      000ACC AF 82            [24] 1307 	mov	r7,dpl
                           000106  1308 	C$serial.c$74$2_0$156 ==.
                                   1309 ;	serial/serial.c:74: TMOD &= 0x08;
      000ACE 53 89 08         [24] 1310 	anl	_TMOD,#0x08
                           000109  1311 	C$serial.c$75$2_0$156 ==.
                                   1312 ;	serial/serial.c:75: TMOD |= ser8BIT_WITH_RELOAD;
      000AD1 43 89 20         [24] 1313 	orl	_TMOD,#0x20
                           00010C  1314 	C$serial.c$76$2_0$156 ==.
                                   1315 ;	serial/serial.c:76: SSTA0 |= serSMOD;
      000AD4 43 91 10         [24] 1316 	orl	_SSTA0,#0x10
                           00010F  1317 	C$serial.c$79$2_0$156 ==.
                                   1318 ;	serial/serial.c:79: TL1 = ( unsigned char ) ulReloadValue;
      000AD7 8F 8B            [24] 1319 	mov	_TL1,r7
                           000111  1320 	C$serial.c$80$2_0$156 ==.
                                   1321 ;	serial/serial.c:80: TH1 = ( unsigned char ) ulReloadValue;
      000AD9 8F 8D            [24] 1322 	mov	_TH1,r7
                           000113  1323 	C$serial.c$83$2_0$156 ==.
                                   1324 ;	serial/serial.c:83: SCON = ser8_BIT_MODE | serRX_ENABLE;
      000ADB 75 98 50         [24] 1325 	mov	_SCON,#0x50
                           000116  1326 	C$serial.c$86$2_0$156 ==.
                                   1327 ;	serial/serial.c:86: ES = 1;
                                   1328 ;	assignBit
      000ADE D2 AC            [12] 1329 	setb	_ES
                           000118  1330 	C$serial.c$89$2_0$156 ==.
                                   1331 ;	serial/serial.c:89: TR1 = 1;
                                   1332 ;	assignBit
      000AE0 D2 8E            [12] 1333 	setb	_TR1
                           00011A  1334 	C$serial.c$91$2_0$156 ==.
                                   1335 ;	serial/serial.c:91: SFRPAGE = ucOriginalSFRPage;
      000AE2 E5 0D            [12] 1336 	mov	a,_bp
      000AE4 24 05            [12] 1337 	add	a,#0x05
      000AE6 F8               [12] 1338 	mov	r0,a
      000AE7 86 84            [24] 1339 	mov	_SFRPAGE,@r0
                           000121  1340 	C$serial.c$93$1_0$155 ==.
                                   1341 ;	serial/serial.c:93: portEXIT_CRITICAL();
      000AE9 D0 E0            [24] 1342 	pop ACC 
      000AEB 53 E0 80         [24] 1343 	anl	_ACC,#0x80
      000AEE E5 E0            [12] 1344 	mov	a,_ACC
      000AF0 42 A8            [12] 1345 	orl	_IE,a
      000AF2 D0 E0            [24] 1346 	pop ACC 
                           00012C  1347 	C$serial.c$98$1_0$155 ==.
                                   1348 ;	serial/serial.c:98: return NULL;
      000AF4 75 82 00         [24] 1349 	mov	dpl,#0x00
      000AF7 75 83 00         [24] 1350 	mov	dph,#0x00
      000AFA 75 F0 00         [24] 1351 	mov	b,#0x00
      000AFD                       1352 00101$:
                           000135  1353 	C$serial.c$99$1_0$155 ==.
                                   1354 ;	serial/serial.c:99: }
      000AFD 85 0D 81         [24] 1355 	mov	sp,_bp
      000B00 D0 0D            [24] 1356 	pop	_bp
                           00013A  1357 	C$serial.c$99$1_0$155 ==.
                           00013A  1358 	XG$xSerialPortInitMinimal$0$0 ==.
      000B02 22               [24] 1359 	ret
                                   1360 ;------------------------------------------------------------
                                   1361 ;Allocation info for local variables in function 'vSerialISR'
                                   1362 ;------------------------------------------------------------
                                   1363 ;cChar                     Allocated to stack - _bp +5
                                   1364 ;xHigherPriorityTaskWoken  Allocated to stack - _bp +4
                                   1365 ;sloc0                     Allocated to stack - _bp +1
                                   1366 ;------------------------------------------------------------
                           00013B  1367 	G$vSerialISR$0$0 ==.
                           00013B  1368 	C$serial.c$102$1_0$158 ==.
                                   1369 ;	serial/serial.c:102: void vSerialISR( void ) __interrupt 4
                                   1370 ;	-----------------------------------------
                                   1371 ;	 function vSerialISR
                                   1372 ;	-----------------------------------------
      000B03                       1373 _vSerialISR:
      000B03 C0 20            [24] 1374 	push	bits
      000B05 C0 E0            [24] 1375 	push	acc
      000B07 C0 F0            [24] 1376 	push	b
      000B09 C0 82            [24] 1377 	push	dpl
      000B0B C0 83            [24] 1378 	push	dph
      000B0D C0 07            [24] 1379 	push	(0+7)
      000B0F C0 06            [24] 1380 	push	(0+6)
      000B11 C0 05            [24] 1381 	push	(0+5)
      000B13 C0 04            [24] 1382 	push	(0+4)
      000B15 C0 03            [24] 1383 	push	(0+3)
      000B17 C0 02            [24] 1384 	push	(0+2)
      000B19 C0 01            [24] 1385 	push	(0+1)
      000B1B C0 00            [24] 1386 	push	(0+0)
      000B1D C0 D0            [24] 1387 	push	psw
      000B1F 75 D0 00         [24] 1388 	mov	psw,#0x00
      000B22 C0 0D            [24] 1389 	push	_bp
      000B24 85 81 0D         [24] 1390 	mov	_bp,sp
      000B27 E5 81            [12] 1391 	mov	a,sp
      000B29 24 05            [12] 1392 	add	a,#0x05
      000B2B F5 81            [12] 1393 	mov	sp,a
                           000165  1394 	C$serial.c$105$2_0$158 ==.
                                   1395 ;	serial/serial.c:105: portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
      000B2D E5 0D            [12] 1396 	mov	a,_bp
      000B2F 24 04            [12] 1397 	add	a,#0x04
      000B31 F8               [12] 1398 	mov	r0,a
      000B32 76 00            [12] 1399 	mov	@r0,#0x00
                           00016C  1400 	C$serial.c$110$1_0$158 ==.
                                   1401 ;	serial/serial.c:110: portENTER_CRITICAL();
      000B34 C0 E0            [24] 1402 	push ACC 
      000B36 C0 A8            [24] 1403 	push IE 
                                   1404 ;	assignBit
      000B38 C2 AF            [12] 1405 	clr	_EA
                           000172  1406 	C$serial.c$112$2_0$159 ==.
                                   1407 ;	serial/serial.c:112: if( RI ) 
      000B3A 20 98 03         [24] 1408 	jb	_RI,00128$
      000B3D 02 0B 94         [24] 1409 	ljmp	00102$
      000B40                       1410 00128$:
                           000178  1411 	C$serial.c$117$3_0$160 ==.
                                   1412 ;	serial/serial.c:117: cChar = SBUF;
      000B40 E5 0D            [12] 1413 	mov	a,_bp
      000B42 24 05            [12] 1414 	add	a,#0x05
      000B44 F8               [12] 1415 	mov	r0,a
      000B45 A6 99            [24] 1416 	mov	@r0,_SBUF
                           00017F  1417 	C$serial.c$118$3_0$160 ==.
                                   1418 ;	serial/serial.c:118: RI = 0;
                                   1419 ;	assignBit
      000B47 C2 98            [12] 1420 	clr	_RI
                           000181  1421 	C$serial.c$120$3_0$160 ==.
                                   1422 ;	serial/serial.c:120: xQueueSendFromISR( xRxedChars, &cChar, &xHigherPriorityTaskWoken );
      000B49 E5 0D            [12] 1423 	mov	a,_bp
      000B4B 24 04            [12] 1424 	add	a,#0x04
      000B4D FF               [12] 1425 	mov	r7,a
      000B4E 7E 00            [12] 1426 	mov	r6,#0x00
      000B50 7D 40            [12] 1427 	mov	r5,#0x40
      000B52 E5 0D            [12] 1428 	mov	a,_bp
      000B54 24 05            [12] 1429 	add	a,#0x05
      000B56 FC               [12] 1430 	mov	r4,a
      000B57 A8 0D            [24] 1431 	mov	r0,_bp
      000B59 08               [12] 1432 	inc	r0
      000B5A A6 04            [24] 1433 	mov	@r0,ar4
      000B5C 08               [12] 1434 	inc	r0
      000B5D 76 00            [12] 1435 	mov	@r0,#0x00
      000B5F 08               [12] 1436 	inc	r0
      000B60 76 40            [12] 1437 	mov	@r0,#0x40
      000B62 90 00 02         [24] 1438 	mov	dptr,#_xRxedChars
      000B65 E0               [24] 1439 	movx	a,@dptr
      000B66 FA               [12] 1440 	mov	r2,a
      000B67 A3               [24] 1441 	inc	dptr
      000B68 E0               [24] 1442 	movx	a,@dptr
      000B69 FB               [12] 1443 	mov	r3,a
      000B6A A3               [24] 1444 	inc	dptr
      000B6B E0               [24] 1445 	movx	a,@dptr
      000B6C FC               [12] 1446 	mov	r4,a
      000B6D 74 00            [12] 1447 	mov	a,#0x00
      000B6F C0 E0            [24] 1448 	push	acc
      000B71 C0 07            [24] 1449 	push	ar7
      000B73 C0 06            [24] 1450 	push	ar6
      000B75 C0 05            [24] 1451 	push	ar5
      000B77 A8 0D            [24] 1452 	mov	r0,_bp
      000B79 08               [12] 1453 	inc	r0
      000B7A E6               [12] 1454 	mov	a,@r0
      000B7B C0 E0            [24] 1455 	push	acc
      000B7D 08               [12] 1456 	inc	r0
      000B7E E6               [12] 1457 	mov	a,@r0
      000B7F C0 E0            [24] 1458 	push	acc
      000B81 08               [12] 1459 	inc	r0
      000B82 E6               [12] 1460 	mov	a,@r0
      000B83 C0 E0            [24] 1461 	push	acc
      000B85 8A 82            [24] 1462 	mov	dpl,r2
      000B87 8B 83            [24] 1463 	mov	dph,r3
      000B89 8C F0            [24] 1464 	mov	b,r4
      000B8B 12 4A 3D         [24] 1465 	lcall	_xQueueGenericSendFromISR
      000B8E E5 81            [12] 1466 	mov	a,sp
      000B90 24 F9            [12] 1467 	add	a,#0xf9
      000B92 F5 81            [12] 1468 	mov	sp,a
      000B94                       1469 00102$:
                           0001CC  1470 	C$serial.c$123$2_0$159 ==.
                                   1471 ;	serial/serial.c:123: if( TI ) 
      000B94 20 99 03         [24] 1472 	jb	_TI,00129$
      000B97 02 0B FA         [24] 1473 	ljmp	00107$
      000B9A                       1474 00129$:
                           0001D2  1475 	C$serial.c$125$3_0$161 ==.
                                   1476 ;	serial/serial.c:125: if( xQueueReceiveFromISR( xCharsForTx, &cChar, &xHigherPriorityTaskWoken ) == ( portBASE_TYPE ) pdTRUE )
      000B9A E5 0D            [12] 1477 	mov	a,_bp
      000B9C 24 04            [12] 1478 	add	a,#0x04
      000B9E FF               [12] 1479 	mov	r7,a
      000B9F 7E 00            [12] 1480 	mov	r6,#0x00
      000BA1 7D 40            [12] 1481 	mov	r5,#0x40
      000BA3 E5 0D            [12] 1482 	mov	a,_bp
      000BA5 24 05            [12] 1483 	add	a,#0x05
      000BA7 FC               [12] 1484 	mov	r4,a
      000BA8 A8 0D            [24] 1485 	mov	r0,_bp
      000BAA 08               [12] 1486 	inc	r0
      000BAB A6 04            [24] 1487 	mov	@r0,ar4
      000BAD 08               [12] 1488 	inc	r0
      000BAE 76 00            [12] 1489 	mov	@r0,#0x00
      000BB0 08               [12] 1490 	inc	r0
      000BB1 76 40            [12] 1491 	mov	@r0,#0x40
      000BB3 90 00 05         [24] 1492 	mov	dptr,#_xCharsForTx
      000BB6 E0               [24] 1493 	movx	a,@dptr
      000BB7 FA               [12] 1494 	mov	r2,a
      000BB8 A3               [24] 1495 	inc	dptr
      000BB9 E0               [24] 1496 	movx	a,@dptr
      000BBA FB               [12] 1497 	mov	r3,a
      000BBB A3               [24] 1498 	inc	dptr
      000BBC E0               [24] 1499 	movx	a,@dptr
      000BBD FC               [12] 1500 	mov	r4,a
      000BBE C0 07            [24] 1501 	push	ar7
      000BC0 C0 06            [24] 1502 	push	ar6
      000BC2 C0 05            [24] 1503 	push	ar5
      000BC4 A8 0D            [24] 1504 	mov	r0,_bp
      000BC6 08               [12] 1505 	inc	r0
      000BC7 E6               [12] 1506 	mov	a,@r0
      000BC8 C0 E0            [24] 1507 	push	acc
      000BCA 08               [12] 1508 	inc	r0
      000BCB E6               [12] 1509 	mov	a,@r0
      000BCC C0 E0            [24] 1510 	push	acc
      000BCE 08               [12] 1511 	inc	r0
      000BCF E6               [12] 1512 	mov	a,@r0
      000BD0 C0 E0            [24] 1513 	push	acc
      000BD2 8A 82            [24] 1514 	mov	dpl,r2
      000BD4 8B 83            [24] 1515 	mov	dph,r3
      000BD6 8C F0            [24] 1516 	mov	b,r4
      000BD8 12 55 23         [24] 1517 	lcall	_xQueueReceiveFromISR
      000BDB AF 82            [24] 1518 	mov	r7,dpl
      000BDD E5 81            [12] 1519 	mov	a,sp
      000BDF 24 FA            [12] 1520 	add	a,#0xfa
      000BE1 F5 81            [12] 1521 	mov	sp,a
      000BE3 BF 01 02         [24] 1522 	cjne	r7,#0x01,00130$
      000BE6 80 03            [24] 1523 	sjmp	00131$
      000BE8                       1524 00130$:
      000BE8 02 0B F5         [24] 1525 	ljmp	00104$
      000BEB                       1526 00131$:
                           000223  1527 	C$serial.c$128$4_0$162 ==.
                                   1528 ;	serial/serial.c:128: SBUF = cChar;
      000BEB E5 0D            [12] 1529 	mov	a,_bp
      000BED 24 05            [12] 1530 	add	a,#0x05
      000BEF F8               [12] 1531 	mov	r0,a
      000BF0 86 99            [24] 1532 	mov	_SBUF,@r0
      000BF2 02 0B F8         [24] 1533 	ljmp	00105$
      000BF5                       1534 00104$:
                           00022D  1535 	C$serial.c$133$4_0$163 ==.
                                   1536 ;	serial/serial.c:133: uxTxEmpty = pdTRUE;
      000BF5 75 08 01         [24] 1537 	mov	_uxTxEmpty,#0x01
      000BF8                       1538 00105$:
                           000230  1539 	C$serial.c$136$3_0$161 ==.
                                   1540 ;	serial/serial.c:136: TI = 0;
                                   1541 ;	assignBit
      000BF8 C2 99            [12] 1542 	clr	_TI
      000BFA                       1543 00107$:
                           000232  1544 	C$serial.c$139$2_0$159 ==.
                                   1545 ;	serial/serial.c:139: if( xHigherPriorityTaskWoken )
      000BFA E5 0D            [12] 1546 	mov	a,_bp
      000BFC 24 04            [12] 1547 	add	a,#0x04
      000BFE F8               [12] 1548 	mov	r0,a
      000BFF E6               [12] 1549 	mov	a,@r0
      000C00 70 03            [24] 1550 	jnz	00132$
      000C02 02 0C 08         [24] 1551 	ljmp	00109$
      000C05                       1552 00132$:
                           00023D  1553 	C$serial.c$141$3_0$164 ==.
                                   1554 ;	serial/serial.c:141: portYIELD();
      000C05 12 68 9D         [24] 1555 	lcall	_vPortYield
      000C08                       1556 00109$:
                           000240  1557 	C$serial.c$144$1_0$158 ==.
                                   1558 ;	serial/serial.c:144: portEXIT_CRITICAL();
      000C08 D0 E0            [24] 1559 	pop ACC 
      000C0A 53 E0 80         [24] 1560 	anl	_ACC,#0x80
      000C0D E5 E0            [12] 1561 	mov	a,_ACC
      000C0F 42 A8            [12] 1562 	orl	_IE,a
      000C11 D0 E0            [24] 1563 	pop ACC 
      000C13                       1564 00110$:
                           00024B  1565 	C$serial.c$145$1_0$158 ==.
                                   1566 ;	serial/serial.c:145: }
      000C13 85 0D 81         [24] 1567 	mov	sp,_bp
      000C16 D0 0D            [24] 1568 	pop	_bp
      000C18 D0 D0            [24] 1569 	pop	psw
      000C1A D0 00            [24] 1570 	pop	(0+0)
      000C1C D0 01            [24] 1571 	pop	(0+1)
      000C1E D0 02            [24] 1572 	pop	(0+2)
      000C20 D0 03            [24] 1573 	pop	(0+3)
      000C22 D0 04            [24] 1574 	pop	(0+4)
      000C24 D0 05            [24] 1575 	pop	(0+5)
      000C26 D0 06            [24] 1576 	pop	(0+6)
      000C28 D0 07            [24] 1577 	pop	(0+7)
      000C2A D0 83            [24] 1578 	pop	dph
      000C2C D0 82            [24] 1579 	pop	dpl
      000C2E D0 F0            [24] 1580 	pop	b
      000C30 D0 E0            [24] 1581 	pop	acc
      000C32 D0 20            [24] 1582 	pop	bits
                           00026C  1583 	C$serial.c$145$1_0$158 ==.
                           00026C  1584 	XG$vSerialISR$0$0 ==.
      000C34 32               [24] 1585 	reti
                                   1586 ;------------------------------------------------------------
                                   1587 ;Allocation info for local variables in function 'xSerialGetChar'
                                   1588 ;------------------------------------------------------------
                                   1589 ;pcRxedChar                Allocated to stack - _bp -5
                                   1590 ;xBlockTime                Allocated to stack - _bp -7
                                   1591 ;pxPort                    Allocated to registers 
                                   1592 ;------------------------------------------------------------
                           00026D  1593 	G$xSerialGetChar$0$0 ==.
                           00026D  1594 	C$serial.c$148$1_0$166 ==.
                                   1595 ;	serial/serial.c:148: signed portBASE_TYPE xSerialGetChar( xComPortHandle pxPort, signed char *pcRxedChar, TickType_t xBlockTime )
                                   1596 ;	-----------------------------------------
                                   1597 ;	 function xSerialGetChar
                                   1598 ;	-----------------------------------------
      000C35                       1599 _xSerialGetChar:
      000C35 C0 0D            [24] 1600 	push	_bp
      000C37 85 81 0D         [24] 1601 	mov	_bp,sp
                           000272  1602 	C$serial.c$155$1_0$166 ==.
                                   1603 ;	serial/serial.c:155: if( xQueueReceive( xRxedChars, pcRxedChar, xBlockTime ) )
      000C3A E5 0D            [12] 1604 	mov	a,_bp
      000C3C 24 FB            [12] 1605 	add	a,#0xfb
      000C3E F8               [12] 1606 	mov	r0,a
      000C3F 86 05            [24] 1607 	mov	ar5,@r0
      000C41 08               [12] 1608 	inc	r0
      000C42 86 06            [24] 1609 	mov	ar6,@r0
      000C44 08               [12] 1610 	inc	r0
      000C45 86 07            [24] 1611 	mov	ar7,@r0
      000C47 90 00 02         [24] 1612 	mov	dptr,#_xRxedChars
      000C4A E0               [24] 1613 	movx	a,@dptr
      000C4B FA               [12] 1614 	mov	r2,a
      000C4C A3               [24] 1615 	inc	dptr
      000C4D E0               [24] 1616 	movx	a,@dptr
      000C4E FB               [12] 1617 	mov	r3,a
      000C4F A3               [24] 1618 	inc	dptr
      000C50 E0               [24] 1619 	movx	a,@dptr
      000C51 FC               [12] 1620 	mov	r4,a
      000C52 E5 0D            [12] 1621 	mov	a,_bp
      000C54 24 F9            [12] 1622 	add	a,#0xf9
      000C56 F8               [12] 1623 	mov	r0,a
      000C57 E6               [12] 1624 	mov	a,@r0
      000C58 C0 E0            [24] 1625 	push	acc
      000C5A 08               [12] 1626 	inc	r0
      000C5B E6               [12] 1627 	mov	a,@r0
      000C5C C0 E0            [24] 1628 	push	acc
      000C5E C0 05            [24] 1629 	push	ar5
      000C60 C0 06            [24] 1630 	push	ar6
      000C62 C0 07            [24] 1631 	push	ar7
      000C64 8A 82            [24] 1632 	mov	dpl,r2
      000C66 8B 83            [24] 1633 	mov	dph,r3
      000C68 8C F0            [24] 1634 	mov	b,r4
      000C6A 12 4C A7         [24] 1635 	lcall	_xQueueReceive
      000C6D AF 82            [24] 1636 	mov	r7,dpl
      000C6F E5 81            [12] 1637 	mov	a,sp
      000C71 24 FB            [12] 1638 	add	a,#0xfb
      000C73 F5 81            [12] 1639 	mov	sp,a
      000C75 EF               [12] 1640 	mov	a,r7
      000C76 70 03            [24] 1641 	jnz	00110$
      000C78 02 0C 81         [24] 1642 	ljmp	00102$
      000C7B                       1643 00110$:
                           0002B3  1644 	C$serial.c$157$2_0$167 ==.
                                   1645 ;	serial/serial.c:157: return ( portBASE_TYPE ) pdTRUE;
      000C7B 75 82 01         [24] 1646 	mov	dpl,#0x01
      000C7E 02 0C 84         [24] 1647 	ljmp	00104$
      000C81                       1648 00102$:
                           0002B9  1649 	C$serial.c$161$2_0$168 ==.
                                   1650 ;	serial/serial.c:161: return ( portBASE_TYPE ) pdFALSE;
      000C81 75 82 00         [24] 1651 	mov	dpl,#0x00
      000C84                       1652 00104$:
                           0002BC  1653 	C$serial.c$163$1_0$166 ==.
                                   1654 ;	serial/serial.c:163: }
      000C84 D0 0D            [24] 1655 	pop	_bp
                           0002BE  1656 	C$serial.c$163$1_0$166 ==.
                           0002BE  1657 	XG$xSerialGetChar$0$0 ==.
      000C86 22               [24] 1658 	ret
                                   1659 ;------------------------------------------------------------
                                   1660 ;Allocation info for local variables in function 'xSerialPutChar'
                                   1661 ;------------------------------------------------------------
                                   1662 ;cOutChar                  Allocated to stack - _bp -3
                                   1663 ;xBlockTime                Allocated to stack - _bp -5
                                   1664 ;pxPort                    Allocated to registers 
                                   1665 ;xReturn                   Allocated to registers r7 
                                   1666 ;sloc0                     Allocated to stack - _bp +5
                                   1667 ;------------------------------------------------------------
                           0002BF  1668 	G$xSerialPutChar$0$0 ==.
                           0002BF  1669 	C$serial.c$166$1_0$170 ==.
                                   1670 ;	serial/serial.c:166: signed portBASE_TYPE xSerialPutChar( xComPortHandle pxPort, signed char cOutChar, TickType_t xBlockTime )
                                   1671 ;	-----------------------------------------
                                   1672 ;	 function xSerialPutChar
                                   1673 ;	-----------------------------------------
      000C87                       1674 _xSerialPutChar:
      000C87 C0 0D            [24] 1675 	push	_bp
      000C89 85 81 0D         [24] 1676 	mov	_bp,sp
                           0002C4  1677 	C$serial.c$173$1_0$170 ==.
                                   1678 ;	serial/serial.c:173: portENTER_CRITICAL();
      000C8C C0 E0            [24] 1679 	push ACC 
      000C8E C0 A8            [24] 1680 	push IE 
                                   1681 ;	assignBit
      000C90 C2 AF            [12] 1682 	clr	_EA
                           0002CA  1683 	C$serial.c$175$2_0$171 ==.
                                   1684 ;	serial/serial.c:175: if( uxTxEmpty == pdTRUE )
      000C92 74 01            [12] 1685 	mov	a,#0x01
      000C94 B5 08 02         [24] 1686 	cjne	a,_uxTxEmpty,00116$
      000C97 80 03            [24] 1687 	sjmp	00117$
      000C99                       1688 00116$:
      000C99 02 0C AB         [24] 1689 	ljmp	00104$
      000C9C                       1690 00117$:
                           0002D4  1691 	C$serial.c$177$3_0$172 ==.
                                   1692 ;	serial/serial.c:177: SBUF = cOutChar;
      000C9C E5 0D            [12] 1693 	mov	a,_bp
      000C9E 24 FD            [12] 1694 	add	a,#0xfd
      000CA0 F8               [12] 1695 	mov	r0,a
      000CA1 86 99            [24] 1696 	mov	_SBUF,@r0
                           0002DB  1697 	C$serial.c$178$3_0$172 ==.
                                   1698 ;	serial/serial.c:178: uxTxEmpty = pdFALSE;
      000CA3 75 08 00         [24] 1699 	mov	_uxTxEmpty,#0x00
                           0002DE  1700 	C$serial.c$179$3_0$172 ==.
                                   1701 ;	serial/serial.c:179: xReturn = ( portBASE_TYPE ) pdTRUE;
      000CA6 7F 01            [12] 1702 	mov	r7,#0x01
      000CA8 02 0C F2         [24] 1703 	ljmp	00105$
      000CAB                       1704 00104$:
                           0002E3  1705 	C$serial.c$183$3_0$173 ==.
                                   1706 ;	serial/serial.c:183: xReturn = xQueueSend( xCharsForTx, &cOutChar, xBlockTime );
      000CAB E5 0D            [12] 1707 	mov	a,_bp
      000CAD 24 FD            [12] 1708 	add	a,#0xfd
      000CAF FE               [12] 1709 	mov	r6,a
      000CB0 8E 07            [24] 1710 	mov	ar7,r6
      000CB2 7D 00            [12] 1711 	mov	r5,#0x00
      000CB4 7C 40            [12] 1712 	mov	r4,#0x40
      000CB6 90 00 05         [24] 1713 	mov	dptr,#_xCharsForTx
      000CB9 E0               [24] 1714 	movx	a,@dptr
      000CBA FA               [12] 1715 	mov	r2,a
      000CBB A3               [24] 1716 	inc	dptr
      000CBC E0               [24] 1717 	movx	a,@dptr
      000CBD FB               [12] 1718 	mov	r3,a
      000CBE A3               [24] 1719 	inc	dptr
      000CBF E0               [24] 1720 	movx	a,@dptr
      000CC0 FE               [12] 1721 	mov	r6,a
      000CC1 74 00            [12] 1722 	mov	a,#0x00
      000CC3 C0 E0            [24] 1723 	push	acc
      000CC5 E5 0D            [12] 1724 	mov	a,_bp
      000CC7 24 FB            [12] 1725 	add	a,#0xfb
      000CC9 F8               [12] 1726 	mov	r0,a
      000CCA E6               [12] 1727 	mov	a,@r0
      000CCB C0 E0            [24] 1728 	push	acc
      000CCD 08               [12] 1729 	inc	r0
      000CCE E6               [12] 1730 	mov	a,@r0
      000CCF C0 E0            [24] 1731 	push	acc
      000CD1 C0 07            [24] 1732 	push	ar7
      000CD3 C0 05            [24] 1733 	push	ar5
      000CD5 C0 04            [24] 1734 	push	ar4
      000CD7 8A 82            [24] 1735 	mov	dpl,r2
      000CD9 8B 83            [24] 1736 	mov	dph,r3
      000CDB 8E F0            [24] 1737 	mov	b,r6
      000CDD 12 47 3E         [24] 1738 	lcall	_xQueueGenericSend
      000CE0 AE 82            [24] 1739 	mov	r6,dpl
      000CE2 E5 81            [12] 1740 	mov	a,sp
      000CE4 24 FA            [12] 1741 	add	a,#0xfa
      000CE6 F5 81            [12] 1742 	mov	sp,a
      000CE8 8E 07            [24] 1743 	mov	ar7,r6
                           000322  1744 	C$serial.c$185$3_0$173 ==.
                                   1745 ;	serial/serial.c:185: if( xReturn == ( portBASE_TYPE ) pdFALSE )
      000CEA EE               [12] 1746 	mov	a,r6
      000CEB 60 03            [24] 1747 	jz	00118$
      000CED 02 0C F2         [24] 1748 	ljmp	00105$
      000CF0                       1749 00118$:
                           000328  1750 	C$serial.c$187$4_0$174 ==.
                                   1751 ;	serial/serial.c:187: xReturn = ( portBASE_TYPE ) pdTRUE;
      000CF0 7F 01            [12] 1752 	mov	r7,#0x01
      000CF2                       1753 00105$:
                           00032A  1754 	C$serial.c$191$1_0$170 ==.
                                   1755 ;	serial/serial.c:191: portEXIT_CRITICAL();
      000CF2 D0 E0            [24] 1756 	pop ACC 
      000CF4 53 E0 80         [24] 1757 	anl	_ACC,#0x80
      000CF7 E5 E0            [12] 1758 	mov	a,_ACC
      000CF9 42 A8            [12] 1759 	orl	_IE,a
      000CFB D0 E0            [24] 1760 	pop ACC 
                           000335  1761 	C$serial.c$193$1_0$170 ==.
                                   1762 ;	serial/serial.c:193: return xReturn;
      000CFD 8F 82            [24] 1763 	mov	dpl,r7
      000CFF                       1764 00106$:
                           000337  1765 	C$serial.c$194$1_0$170 ==.
                                   1766 ;	serial/serial.c:194: }
      000CFF D0 0D            [24] 1767 	pop	_bp
                           000339  1768 	C$serial.c$194$1_0$170 ==.
                           000339  1769 	XG$xSerialPutChar$0$0 ==.
      000D01 22               [24] 1770 	ret
                                   1771 ;------------------------------------------------------------
                                   1772 ;Allocation info for local variables in function 'vSerialClose'
                                   1773 ;------------------------------------------------------------
                                   1774 ;xPort                     Allocated to registers 
                                   1775 ;------------------------------------------------------------
                           00033A  1776 	G$vSerialClose$0$0 ==.
                           00033A  1777 	C$serial.c$197$1_0$176 ==.
                                   1778 ;	serial/serial.c:197: void vSerialClose( xComPortHandle xPort )
                                   1779 ;	-----------------------------------------
                                   1780 ;	 function vSerialClose
                                   1781 ;	-----------------------------------------
      000D02                       1782 _vSerialClose:
                           00033A  1783 	C$serial.c$200$1_0$176 ==.
                                   1784 ;	serial/serial.c:200: ( void ) xPort;
      000D02                       1785 00101$:
                           00033A  1786 	C$serial.c$201$1_0$176 ==.
                                   1787 ;	serial/serial.c:201: }
                           00033A  1788 	C$serial.c$201$1_0$176 ==.
                           00033A  1789 	XG$vSerialClose$0$0 ==.
      000D02 22               [24] 1790 	ret
                                   1791 	.area CSEG    (CODE)
                                   1792 	.area CONST   (CODE)
                                   1793 	.area XINIT   (CODE)
                                   1794 	.area CABS    (ABS,CODE)
