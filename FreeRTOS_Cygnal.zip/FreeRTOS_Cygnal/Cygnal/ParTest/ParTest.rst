                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.0 #11528 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module ParTest
                                      6 	.optsdcc -mmcs51 --model-large
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _xTaskResumeAll
                                     12 	.globl _vTaskSuspendAll
                                     13 	.globl _P7_7
                                     14 	.globl _P7_6
                                     15 	.globl _P7_5
                                     16 	.globl _P7_4
                                     17 	.globl _P7_3
                                     18 	.globl _P7_2
                                     19 	.globl _P7_1
                                     20 	.globl _P7_0
                                     21 	.globl _SPIF
                                     22 	.globl _WCOL
                                     23 	.globl _MODF
                                     24 	.globl _RXOVRN
                                     25 	.globl _NSSMD1
                                     26 	.globl _NSSMD0
                                     27 	.globl _TXBMT
                                     28 	.globl _SPIEN
                                     29 	.globl _P6_7
                                     30 	.globl _P6_6
                                     31 	.globl _P6_5
                                     32 	.globl _P6_4
                                     33 	.globl _P6_3
                                     34 	.globl _P6_2
                                     35 	.globl _P6_1
                                     36 	.globl _P6_0
                                     37 	.globl _AD2EN
                                     38 	.globl _AD2TM
                                     39 	.globl _AD2INT
                                     40 	.globl _AD2BUSY
                                     41 	.globl _AD2CM2
                                     42 	.globl _AD2CM1
                                     43 	.globl _AD2CM0
                                     44 	.globl _AD2WINT
                                     45 	.globl _AD0EN
                                     46 	.globl _AD0TM
                                     47 	.globl _AD0INT
                                     48 	.globl _AD0BUSY
                                     49 	.globl _AD0CM1
                                     50 	.globl _AD0CM0
                                     51 	.globl _AD0WINT
                                     52 	.globl _AD0LJST
                                     53 	.globl _P5_7
                                     54 	.globl _P5_6
                                     55 	.globl _P5_5
                                     56 	.globl _P5_4
                                     57 	.globl _P5_3
                                     58 	.globl _P5_2
                                     59 	.globl _P5_1
                                     60 	.globl _P5_0
                                     61 	.globl _CF
                                     62 	.globl _CR
                                     63 	.globl _CCF5
                                     64 	.globl _CCF4
                                     65 	.globl _CCF3
                                     66 	.globl _CCF2
                                     67 	.globl _CCF1
                                     68 	.globl _CCF0
                                     69 	.globl _CY
                                     70 	.globl _AC
                                     71 	.globl _F0
                                     72 	.globl _RS1
                                     73 	.globl _RS0
                                     74 	.globl _OV
                                     75 	.globl _F1
                                     76 	.globl _P
                                     77 	.globl _P4_7
                                     78 	.globl _P4_6
                                     79 	.globl _P4_5
                                     80 	.globl _P4_4
                                     81 	.globl _P4_3
                                     82 	.globl _P4_2
                                     83 	.globl _P4_1
                                     84 	.globl _P4_0
                                     85 	.globl _TF4
                                     86 	.globl _EXF4
                                     87 	.globl _EXEN4
                                     88 	.globl _TR4
                                     89 	.globl _CT4
                                     90 	.globl _CPRL4
                                     91 	.globl _TF3
                                     92 	.globl _EXF3
                                     93 	.globl _EXEN3
                                     94 	.globl _TR3
                                     95 	.globl _CT3
                                     96 	.globl _CPRL3
                                     97 	.globl _TF2
                                     98 	.globl _EXF2
                                     99 	.globl _EXEN2
                                    100 	.globl _TR2
                                    101 	.globl _CT2
                                    102 	.globl _CPRL2
                                    103 	.globl _BUSY
                                    104 	.globl _ENSMB
                                    105 	.globl _STA
                                    106 	.globl _STO
                                    107 	.globl _SI
                                    108 	.globl _AA
                                    109 	.globl _SMBFTE
                                    110 	.globl _SMBTOE
                                    111 	.globl _PT2
                                    112 	.globl _PS
                                    113 	.globl _PT1
                                    114 	.globl _PX1
                                    115 	.globl _PT0
                                    116 	.globl _PX0
                                    117 	.globl _EA
                                    118 	.globl _ET2
                                    119 	.globl _ES
                                    120 	.globl _ES0
                                    121 	.globl _ET1
                                    122 	.globl _EX1
                                    123 	.globl _ET0
                                    124 	.globl _EX0
                                    125 	.globl _S1MODE
                                    126 	.globl _MCE1
                                    127 	.globl _REN1
                                    128 	.globl _TB81
                                    129 	.globl _RB81
                                    130 	.globl _TI1
                                    131 	.globl _RI1
                                    132 	.globl _SM00
                                    133 	.globl _SM10
                                    134 	.globl _SM20
                                    135 	.globl _REN
                                    136 	.globl _REN0
                                    137 	.globl _TB80
                                    138 	.globl _RB80
                                    139 	.globl _TI
                                    140 	.globl _TI0
                                    141 	.globl _RI
                                    142 	.globl _RI0
                                    143 	.globl _FLHBUSY
                                    144 	.globl _CP1EN
                                    145 	.globl _CP1OUT
                                    146 	.globl _CP1RIF
                                    147 	.globl _CP1FIF
                                    148 	.globl _CP1HYP1
                                    149 	.globl _CP1HYP0
                                    150 	.globl _CP1HYN1
                                    151 	.globl _CP1HYN0
                                    152 	.globl _CP0EN
                                    153 	.globl _CP0OUT
                                    154 	.globl _CP0RIF
                                    155 	.globl _CP0FIF
                                    156 	.globl _CP0HYP1
                                    157 	.globl _CP0HYP0
                                    158 	.globl _CP0HYN1
                                    159 	.globl _CP0HYN0
                                    160 	.globl _TF1
                                    161 	.globl _TR1
                                    162 	.globl _TF0
                                    163 	.globl _TR0
                                    164 	.globl _IE1
                                    165 	.globl _IT1
                                    166 	.globl _IE0
                                    167 	.globl _IT0
                                    168 	.globl _P0_7
                                    169 	.globl _P0_6
                                    170 	.globl _P0_5
                                    171 	.globl _P0_4
                                    172 	.globl _P0_3
                                    173 	.globl _P0_2
                                    174 	.globl _P0_1
                                    175 	.globl _P0_0
                                    176 	.globl _P7
                                    177 	.globl _P6
                                    178 	.globl _ADC2CN
                                    179 	.globl _XBR2
                                    180 	.globl _XBR1
                                    181 	.globl _XBR0
                                    182 	.globl _P5
                                    183 	.globl _P4
                                    184 	.globl _FLACL
                                    185 	.globl _P1MDIN
                                    186 	.globl _P3MDOUT
                                    187 	.globl _P2MDOUT
                                    188 	.globl _P1MDOUT
                                    189 	.globl _P0MDOUT
                                    190 	.globl _CCH0LC
                                    191 	.globl _CCH0TN
                                    192 	.globl _CCH0CN
                                    193 	.globl _P7MDOUT
                                    194 	.globl _P6MDOUT
                                    195 	.globl _P5MDOUT
                                    196 	.globl _P4MDOUT
                                    197 	.globl _CCH0MA
                                    198 	.globl _CLKSEL
                                    199 	.globl _SFRPGCN
                                    200 	.globl _PLL0FLT
                                    201 	.globl _PLL0MUL
                                    202 	.globl _PLL0DIV
                                    203 	.globl _OSCXCN
                                    204 	.globl _OSCICL
                                    205 	.globl _OSCICN
                                    206 	.globl _PLL0CN
                                    207 	.globl _FLSTAT
                                    208 	.globl _MAC0RNDH
                                    209 	.globl _MAC0RNDL
                                    210 	.globl _MAC0CF
                                    211 	.globl _MAC0AH
                                    212 	.globl _MAC0AL
                                    213 	.globl _MAC0STA
                                    214 	.globl _MAC0OVR
                                    215 	.globl _MAC0ACC3
                                    216 	.globl _MAC0ACC2
                                    217 	.globl _MAC0ACC1
                                    218 	.globl _MAC0ACC0
                                    219 	.globl _MAC0BH
                                    220 	.globl _MAC0BL
                                    221 	.globl _TMR4H
                                    222 	.globl _TMR4L
                                    223 	.globl _RCAP4H
                                    224 	.globl _RCAP4L
                                    225 	.globl _TMR4CF
                                    226 	.globl _TMR4CN
                                    227 	.globl _ADC2LT
                                    228 	.globl _ADC2GT
                                    229 	.globl _ADC2
                                    230 	.globl _ADC2CF
                                    231 	.globl _AMX2SL
                                    232 	.globl _AMX2CF
                                    233 	.globl _CPT1MD
                                    234 	.globl _CPT1CN
                                    235 	.globl _DAC1CN
                                    236 	.globl _DAC1H
                                    237 	.globl _DAC1L
                                    238 	.globl _TMR3H
                                    239 	.globl _TMR3L
                                    240 	.globl _RCAP3H
                                    241 	.globl _RCAP3L
                                    242 	.globl _TMR3CF
                                    243 	.globl _TMR3CN
                                    244 	.globl _SBUF1
                                    245 	.globl _SCON1
                                    246 	.globl _CPT0MD
                                    247 	.globl _CPT0CN
                                    248 	.globl _PCA0CPH1
                                    249 	.globl _PCA0CPL1
                                    250 	.globl _PCA0CPH0
                                    251 	.globl _PCA0CPL0
                                    252 	.globl _PCA0H
                                    253 	.globl _PCA0L
                                    254 	.globl _SPI0CN
                                    255 	.globl _RSTSRC
                                    256 	.globl _PCA0CPH4
                                    257 	.globl _PCA0CPL4
                                    258 	.globl _PCA0CPH3
                                    259 	.globl _PCA0CPL3
                                    260 	.globl _PCA0CPH2
                                    261 	.globl _PCA0CPL2
                                    262 	.globl _ADC0CN
                                    263 	.globl _PCA0CPH5
                                    264 	.globl _PCA0CPL5
                                    265 	.globl _PCA0CPM5
                                    266 	.globl _PCA0CPM4
                                    267 	.globl _PCA0CPM3
                                    268 	.globl _PCA0CPM2
                                    269 	.globl _PCA0CPM1
                                    270 	.globl _PCA0CPM0
                                    271 	.globl _PCA0MD
                                    272 	.globl _PCA0CN
                                    273 	.globl _DAC0CN
                                    274 	.globl _DAC0H
                                    275 	.globl _DAC0L
                                    276 	.globl _REF0CN
                                    277 	.globl _SMB0CR
                                    278 	.globl _TH2
                                    279 	.globl _TMR2H
                                    280 	.globl _TL2
                                    281 	.globl _TMR2L
                                    282 	.globl _RCAP2H
                                    283 	.globl _RCAP2L
                                    284 	.globl _TMR2CF
                                    285 	.globl _TMR2CN
                                    286 	.globl _ADC0LTH
                                    287 	.globl _ADC0LTL
                                    288 	.globl _ADC0GTH
                                    289 	.globl _ADC0GTL
                                    290 	.globl _SMB0ADR
                                    291 	.globl _SMB0DAT
                                    292 	.globl _SMB0STA
                                    293 	.globl _SMB0CN
                                    294 	.globl _ADC0H
                                    295 	.globl _ADC0L
                                    296 	.globl _ADC0CF
                                    297 	.globl _AMX0SL
                                    298 	.globl _AMX0CF
                                    299 	.globl _SADEN0
                                    300 	.globl _FLSCL
                                    301 	.globl _SADDR0
                                    302 	.globl _EMI0CF
                                    303 	.globl __XPAGE
                                    304 	.globl _EMI0CN
                                    305 	.globl _EMI0TC
                                    306 	.globl _SPI0CKR
                                    307 	.globl _SPI0DAT
                                    308 	.globl _SPI0CFG
                                    309 	.globl _SBUF
                                    310 	.globl _SBUF0
                                    311 	.globl _SCON
                                    312 	.globl _SCON0
                                    313 	.globl _SSTA0
                                    314 	.globl _PSCTL
                                    315 	.globl _CKCON
                                    316 	.globl _TH1
                                    317 	.globl _TH0
                                    318 	.globl _TL1
                                    319 	.globl _TL0
                                    320 	.globl _TMOD
                                    321 	.globl _TCON
                                    322 	.globl _WDTCN
                                    323 	.globl _EIP2
                                    324 	.globl _EIP1
                                    325 	.globl _B
                                    326 	.globl _EIE2
                                    327 	.globl _EIE1
                                    328 	.globl _ACC
                                    329 	.globl _PSW
                                    330 	.globl _IP
                                    331 	.globl _PSBANK
                                    332 	.globl _P3
                                    333 	.globl _IE
                                    334 	.globl _P2
                                    335 	.globl _P1
                                    336 	.globl _PCON
                                    337 	.globl _SFRLAST
                                    338 	.globl _SFRNEXT
                                    339 	.globl _SFRPAGE
                                    340 	.globl _DPH
                                    341 	.globl _DPL
                                    342 	.globl _SP
                                    343 	.globl _P0
                                    344 	.globl _ucBit
                                    345 	.globl _vParTestInitialise
                                    346 	.globl _vParTestSetLED
                                    347 	.globl _vParTestToggleLED
                                    348 ;--------------------------------------------------------
                                    349 ; special function registers
                                    350 ;--------------------------------------------------------
                                    351 	.area RSEG    (ABS,DATA)
      000000                        352 	.org 0x0000
                           000080   353 G$P0$0_0$0 == 0x0080
                           000080   354 _P0	=	0x0080
                           000081   355 G$SP$0_0$0 == 0x0081
                           000081   356 _SP	=	0x0081
                           000082   357 G$DPL$0_0$0 == 0x0082
                           000082   358 _DPL	=	0x0082
                           000083   359 G$DPH$0_0$0 == 0x0083
                           000083   360 _DPH	=	0x0083
                           000084   361 G$SFRPAGE$0_0$0 == 0x0084
                           000084   362 _SFRPAGE	=	0x0084
                           000085   363 G$SFRNEXT$0_0$0 == 0x0085
                           000085   364 _SFRNEXT	=	0x0085
                           000086   365 G$SFRLAST$0_0$0 == 0x0086
                           000086   366 _SFRLAST	=	0x0086
                           000087   367 G$PCON$0_0$0 == 0x0087
                           000087   368 _PCON	=	0x0087
                           000090   369 G$P1$0_0$0 == 0x0090
                           000090   370 _P1	=	0x0090
                           0000A0   371 G$P2$0_0$0 == 0x00a0
                           0000A0   372 _P2	=	0x00a0
                           0000A8   373 G$IE$0_0$0 == 0x00a8
                           0000A8   374 _IE	=	0x00a8
                           0000B0   375 G$P3$0_0$0 == 0x00b0
                           0000B0   376 _P3	=	0x00b0
                           0000B1   377 G$PSBANK$0_0$0 == 0x00b1
                           0000B1   378 _PSBANK	=	0x00b1
                           0000B8   379 G$IP$0_0$0 == 0x00b8
                           0000B8   380 _IP	=	0x00b8
                           0000D0   381 G$PSW$0_0$0 == 0x00d0
                           0000D0   382 _PSW	=	0x00d0
                           0000E0   383 G$ACC$0_0$0 == 0x00e0
                           0000E0   384 _ACC	=	0x00e0
                           0000E6   385 G$EIE1$0_0$0 == 0x00e6
                           0000E6   386 _EIE1	=	0x00e6
                           0000E7   387 G$EIE2$0_0$0 == 0x00e7
                           0000E7   388 _EIE2	=	0x00e7
                           0000F0   389 G$B$0_0$0 == 0x00f0
                           0000F0   390 _B	=	0x00f0
                           0000F6   391 G$EIP1$0_0$0 == 0x00f6
                           0000F6   392 _EIP1	=	0x00f6
                           0000F7   393 G$EIP2$0_0$0 == 0x00f7
                           0000F7   394 _EIP2	=	0x00f7
                           0000FF   395 G$WDTCN$0_0$0 == 0x00ff
                           0000FF   396 _WDTCN	=	0x00ff
                           000088   397 G$TCON$0_0$0 == 0x0088
                           000088   398 _TCON	=	0x0088
                           000089   399 G$TMOD$0_0$0 == 0x0089
                           000089   400 _TMOD	=	0x0089
                           00008A   401 G$TL0$0_0$0 == 0x008a
                           00008A   402 _TL0	=	0x008a
                           00008B   403 G$TL1$0_0$0 == 0x008b
                           00008B   404 _TL1	=	0x008b
                           00008C   405 G$TH0$0_0$0 == 0x008c
                           00008C   406 _TH0	=	0x008c
                           00008D   407 G$TH1$0_0$0 == 0x008d
                           00008D   408 _TH1	=	0x008d
                           00008E   409 G$CKCON$0_0$0 == 0x008e
                           00008E   410 _CKCON	=	0x008e
                           00008F   411 G$PSCTL$0_0$0 == 0x008f
                           00008F   412 _PSCTL	=	0x008f
                           000091   413 G$SSTA0$0_0$0 == 0x0091
                           000091   414 _SSTA0	=	0x0091
                           000098   415 G$SCON0$0_0$0 == 0x0098
                           000098   416 _SCON0	=	0x0098
                           000098   417 G$SCON$0_0$0 == 0x0098
                           000098   418 _SCON	=	0x0098
                           000099   419 G$SBUF0$0_0$0 == 0x0099
                           000099   420 _SBUF0	=	0x0099
                           000099   421 G$SBUF$0_0$0 == 0x0099
                           000099   422 _SBUF	=	0x0099
                           00009A   423 G$SPI0CFG$0_0$0 == 0x009a
                           00009A   424 _SPI0CFG	=	0x009a
                           00009B   425 G$SPI0DAT$0_0$0 == 0x009b
                           00009B   426 _SPI0DAT	=	0x009b
                           00009D   427 G$SPI0CKR$0_0$0 == 0x009d
                           00009D   428 _SPI0CKR	=	0x009d
                           0000A1   429 G$EMI0TC$0_0$0 == 0x00a1
                           0000A1   430 _EMI0TC	=	0x00a1
                           0000A2   431 G$EMI0CN$0_0$0 == 0x00a2
                           0000A2   432 _EMI0CN	=	0x00a2
                           0000A2   433 G$_XPAGE$0_0$0 == 0x00a2
                           0000A2   434 __XPAGE	=	0x00a2
                           0000A3   435 G$EMI0CF$0_0$0 == 0x00a3
                           0000A3   436 _EMI0CF	=	0x00a3
                           0000A9   437 G$SADDR0$0_0$0 == 0x00a9
                           0000A9   438 _SADDR0	=	0x00a9
                           0000B7   439 G$FLSCL$0_0$0 == 0x00b7
                           0000B7   440 _FLSCL	=	0x00b7
                           0000B9   441 G$SADEN0$0_0$0 == 0x00b9
                           0000B9   442 _SADEN0	=	0x00b9
                           0000BA   443 G$AMX0CF$0_0$0 == 0x00ba
                           0000BA   444 _AMX0CF	=	0x00ba
                           0000BB   445 G$AMX0SL$0_0$0 == 0x00bb
                           0000BB   446 _AMX0SL	=	0x00bb
                           0000BC   447 G$ADC0CF$0_0$0 == 0x00bc
                           0000BC   448 _ADC0CF	=	0x00bc
                           0000BE   449 G$ADC0L$0_0$0 == 0x00be
                           0000BE   450 _ADC0L	=	0x00be
                           0000BF   451 G$ADC0H$0_0$0 == 0x00bf
                           0000BF   452 _ADC0H	=	0x00bf
                           0000C0   453 G$SMB0CN$0_0$0 == 0x00c0
                           0000C0   454 _SMB0CN	=	0x00c0
                           0000C1   455 G$SMB0STA$0_0$0 == 0x00c1
                           0000C1   456 _SMB0STA	=	0x00c1
                           0000C2   457 G$SMB0DAT$0_0$0 == 0x00c2
                           0000C2   458 _SMB0DAT	=	0x00c2
                           0000C3   459 G$SMB0ADR$0_0$0 == 0x00c3
                           0000C3   460 _SMB0ADR	=	0x00c3
                           0000C4   461 G$ADC0GTL$0_0$0 == 0x00c4
                           0000C4   462 _ADC0GTL	=	0x00c4
                           0000C5   463 G$ADC0GTH$0_0$0 == 0x00c5
                           0000C5   464 _ADC0GTH	=	0x00c5
                           0000C6   465 G$ADC0LTL$0_0$0 == 0x00c6
                           0000C6   466 _ADC0LTL	=	0x00c6
                           0000C7   467 G$ADC0LTH$0_0$0 == 0x00c7
                           0000C7   468 _ADC0LTH	=	0x00c7
                           0000C8   469 G$TMR2CN$0_0$0 == 0x00c8
                           0000C8   470 _TMR2CN	=	0x00c8
                           0000C9   471 G$TMR2CF$0_0$0 == 0x00c9
                           0000C9   472 _TMR2CF	=	0x00c9
                           0000CA   473 G$RCAP2L$0_0$0 == 0x00ca
                           0000CA   474 _RCAP2L	=	0x00ca
                           0000CB   475 G$RCAP2H$0_0$0 == 0x00cb
                           0000CB   476 _RCAP2H	=	0x00cb
                           0000CC   477 G$TMR2L$0_0$0 == 0x00cc
                           0000CC   478 _TMR2L	=	0x00cc
                           0000CC   479 G$TL2$0_0$0 == 0x00cc
                           0000CC   480 _TL2	=	0x00cc
                           0000CD   481 G$TMR2H$0_0$0 == 0x00cd
                           0000CD   482 _TMR2H	=	0x00cd
                           0000CD   483 G$TH2$0_0$0 == 0x00cd
                           0000CD   484 _TH2	=	0x00cd
                           0000CF   485 G$SMB0CR$0_0$0 == 0x00cf
                           0000CF   486 _SMB0CR	=	0x00cf
                           0000D1   487 G$REF0CN$0_0$0 == 0x00d1
                           0000D1   488 _REF0CN	=	0x00d1
                           0000D2   489 G$DAC0L$0_0$0 == 0x00d2
                           0000D2   490 _DAC0L	=	0x00d2
                           0000D3   491 G$DAC0H$0_0$0 == 0x00d3
                           0000D3   492 _DAC0H	=	0x00d3
                           0000D4   493 G$DAC0CN$0_0$0 == 0x00d4
                           0000D4   494 _DAC0CN	=	0x00d4
                           0000D8   495 G$PCA0CN$0_0$0 == 0x00d8
                           0000D8   496 _PCA0CN	=	0x00d8
                           0000D9   497 G$PCA0MD$0_0$0 == 0x00d9
                           0000D9   498 _PCA0MD	=	0x00d9
                           0000DA   499 G$PCA0CPM0$0_0$0 == 0x00da
                           0000DA   500 _PCA0CPM0	=	0x00da
                           0000DB   501 G$PCA0CPM1$0_0$0 == 0x00db
                           0000DB   502 _PCA0CPM1	=	0x00db
                           0000DC   503 G$PCA0CPM2$0_0$0 == 0x00dc
                           0000DC   504 _PCA0CPM2	=	0x00dc
                           0000DD   505 G$PCA0CPM3$0_0$0 == 0x00dd
                           0000DD   506 _PCA0CPM3	=	0x00dd
                           0000DE   507 G$PCA0CPM4$0_0$0 == 0x00de
                           0000DE   508 _PCA0CPM4	=	0x00de
                           0000DF   509 G$PCA0CPM5$0_0$0 == 0x00df
                           0000DF   510 _PCA0CPM5	=	0x00df
                           0000E1   511 G$PCA0CPL5$0_0$0 == 0x00e1
                           0000E1   512 _PCA0CPL5	=	0x00e1
                           0000E2   513 G$PCA0CPH5$0_0$0 == 0x00e2
                           0000E2   514 _PCA0CPH5	=	0x00e2
                           0000E8   515 G$ADC0CN$0_0$0 == 0x00e8
                           0000E8   516 _ADC0CN	=	0x00e8
                           0000E9   517 G$PCA0CPL2$0_0$0 == 0x00e9
                           0000E9   518 _PCA0CPL2	=	0x00e9
                           0000EA   519 G$PCA0CPH2$0_0$0 == 0x00ea
                           0000EA   520 _PCA0CPH2	=	0x00ea
                           0000EB   521 G$PCA0CPL3$0_0$0 == 0x00eb
                           0000EB   522 _PCA0CPL3	=	0x00eb
                           0000EC   523 G$PCA0CPH3$0_0$0 == 0x00ec
                           0000EC   524 _PCA0CPH3	=	0x00ec
                           0000ED   525 G$PCA0CPL4$0_0$0 == 0x00ed
                           0000ED   526 _PCA0CPL4	=	0x00ed
                           0000EE   527 G$PCA0CPH4$0_0$0 == 0x00ee
                           0000EE   528 _PCA0CPH4	=	0x00ee
                           0000EF   529 G$RSTSRC$0_0$0 == 0x00ef
                           0000EF   530 _RSTSRC	=	0x00ef
                           0000F8   531 G$SPI0CN$0_0$0 == 0x00f8
                           0000F8   532 _SPI0CN	=	0x00f8
                           0000F9   533 G$PCA0L$0_0$0 == 0x00f9
                           0000F9   534 _PCA0L	=	0x00f9
                           0000FA   535 G$PCA0H$0_0$0 == 0x00fa
                           0000FA   536 _PCA0H	=	0x00fa
                           0000FB   537 G$PCA0CPL0$0_0$0 == 0x00fb
                           0000FB   538 _PCA0CPL0	=	0x00fb
                           0000FC   539 G$PCA0CPH0$0_0$0 == 0x00fc
                           0000FC   540 _PCA0CPH0	=	0x00fc
                           0000FD   541 G$PCA0CPL1$0_0$0 == 0x00fd
                           0000FD   542 _PCA0CPL1	=	0x00fd
                           0000FE   543 G$PCA0CPH1$0_0$0 == 0x00fe
                           0000FE   544 _PCA0CPH1	=	0x00fe
                           000088   545 G$CPT0CN$0_0$0 == 0x0088
                           000088   546 _CPT0CN	=	0x0088
                           000089   547 G$CPT0MD$0_0$0 == 0x0089
                           000089   548 _CPT0MD	=	0x0089
                           000098   549 G$SCON1$0_0$0 == 0x0098
                           000098   550 _SCON1	=	0x0098
                           000099   551 G$SBUF1$0_0$0 == 0x0099
                           000099   552 _SBUF1	=	0x0099
                           0000C8   553 G$TMR3CN$0_0$0 == 0x00c8
                           0000C8   554 _TMR3CN	=	0x00c8
                           0000C9   555 G$TMR3CF$0_0$0 == 0x00c9
                           0000C9   556 _TMR3CF	=	0x00c9
                           0000CA   557 G$RCAP3L$0_0$0 == 0x00ca
                           0000CA   558 _RCAP3L	=	0x00ca
                           0000CB   559 G$RCAP3H$0_0$0 == 0x00cb
                           0000CB   560 _RCAP3H	=	0x00cb
                           0000CC   561 G$TMR3L$0_0$0 == 0x00cc
                           0000CC   562 _TMR3L	=	0x00cc
                           0000CD   563 G$TMR3H$0_0$0 == 0x00cd
                           0000CD   564 _TMR3H	=	0x00cd
                           0000D2   565 G$DAC1L$0_0$0 == 0x00d2
                           0000D2   566 _DAC1L	=	0x00d2
                           0000D3   567 G$DAC1H$0_0$0 == 0x00d3
                           0000D3   568 _DAC1H	=	0x00d3
                           0000D4   569 G$DAC1CN$0_0$0 == 0x00d4
                           0000D4   570 _DAC1CN	=	0x00d4
                           000088   571 G$CPT1CN$0_0$0 == 0x0088
                           000088   572 _CPT1CN	=	0x0088
                           000089   573 G$CPT1MD$0_0$0 == 0x0089
                           000089   574 _CPT1MD	=	0x0089
                           0000BA   575 G$AMX2CF$0_0$0 == 0x00ba
                           0000BA   576 _AMX2CF	=	0x00ba
                           0000BB   577 G$AMX2SL$0_0$0 == 0x00bb
                           0000BB   578 _AMX2SL	=	0x00bb
                           0000BC   579 G$ADC2CF$0_0$0 == 0x00bc
                           0000BC   580 _ADC2CF	=	0x00bc
                           0000BE   581 G$ADC2$0_0$0 == 0x00be
                           0000BE   582 _ADC2	=	0x00be
                           0000C4   583 G$ADC2GT$0_0$0 == 0x00c4
                           0000C4   584 _ADC2GT	=	0x00c4
                           0000C6   585 G$ADC2LT$0_0$0 == 0x00c6
                           0000C6   586 _ADC2LT	=	0x00c6
                           0000C8   587 G$TMR4CN$0_0$0 == 0x00c8
                           0000C8   588 _TMR4CN	=	0x00c8
                           0000C9   589 G$TMR4CF$0_0$0 == 0x00c9
                           0000C9   590 _TMR4CF	=	0x00c9
                           0000CA   591 G$RCAP4L$0_0$0 == 0x00ca
                           0000CA   592 _RCAP4L	=	0x00ca
                           0000CB   593 G$RCAP4H$0_0$0 == 0x00cb
                           0000CB   594 _RCAP4H	=	0x00cb
                           0000CC   595 G$TMR4L$0_0$0 == 0x00cc
                           0000CC   596 _TMR4L	=	0x00cc
                           0000CD   597 G$TMR4H$0_0$0 == 0x00cd
                           0000CD   598 _TMR4H	=	0x00cd
                           000091   599 G$MAC0BL$0_0$0 == 0x0091
                           000091   600 _MAC0BL	=	0x0091
                           000092   601 G$MAC0BH$0_0$0 == 0x0092
                           000092   602 _MAC0BH	=	0x0092
                           000093   603 G$MAC0ACC0$0_0$0 == 0x0093
                           000093   604 _MAC0ACC0	=	0x0093
                           000094   605 G$MAC0ACC1$0_0$0 == 0x0094
                           000094   606 _MAC0ACC1	=	0x0094
                           000095   607 G$MAC0ACC2$0_0$0 == 0x0095
                           000095   608 _MAC0ACC2	=	0x0095
                           000096   609 G$MAC0ACC3$0_0$0 == 0x0096
                           000096   610 _MAC0ACC3	=	0x0096
                           000097   611 G$MAC0OVR$0_0$0 == 0x0097
                           000097   612 _MAC0OVR	=	0x0097
                           0000C0   613 G$MAC0STA$0_0$0 == 0x00c0
                           0000C0   614 _MAC0STA	=	0x00c0
                           0000C1   615 G$MAC0AL$0_0$0 == 0x00c1
                           0000C1   616 _MAC0AL	=	0x00c1
                           0000C2   617 G$MAC0AH$0_0$0 == 0x00c2
                           0000C2   618 _MAC0AH	=	0x00c2
                           0000C3   619 G$MAC0CF$0_0$0 == 0x00c3
                           0000C3   620 _MAC0CF	=	0x00c3
                           0000CE   621 G$MAC0RNDL$0_0$0 == 0x00ce
                           0000CE   622 _MAC0RNDL	=	0x00ce
                           0000CF   623 G$MAC0RNDH$0_0$0 == 0x00cf
                           0000CF   624 _MAC0RNDH	=	0x00cf
                           000088   625 G$FLSTAT$0_0$0 == 0x0088
                           000088   626 _FLSTAT	=	0x0088
                           000089   627 G$PLL0CN$0_0$0 == 0x0089
                           000089   628 _PLL0CN	=	0x0089
                           00008A   629 G$OSCICN$0_0$0 == 0x008a
                           00008A   630 _OSCICN	=	0x008a
                           00008B   631 G$OSCICL$0_0$0 == 0x008b
                           00008B   632 _OSCICL	=	0x008b
                           00008C   633 G$OSCXCN$0_0$0 == 0x008c
                           00008C   634 _OSCXCN	=	0x008c
                           00008D   635 G$PLL0DIV$0_0$0 == 0x008d
                           00008D   636 _PLL0DIV	=	0x008d
                           00008E   637 G$PLL0MUL$0_0$0 == 0x008e
                           00008E   638 _PLL0MUL	=	0x008e
                           00008F   639 G$PLL0FLT$0_0$0 == 0x008f
                           00008F   640 _PLL0FLT	=	0x008f
                           000096   641 G$SFRPGCN$0_0$0 == 0x0096
                           000096   642 _SFRPGCN	=	0x0096
                           000097   643 G$CLKSEL$0_0$0 == 0x0097
                           000097   644 _CLKSEL	=	0x0097
                           00009A   645 G$CCH0MA$0_0$0 == 0x009a
                           00009A   646 _CCH0MA	=	0x009a
                           00009C   647 G$P4MDOUT$0_0$0 == 0x009c
                           00009C   648 _P4MDOUT	=	0x009c
                           00009D   649 G$P5MDOUT$0_0$0 == 0x009d
                           00009D   650 _P5MDOUT	=	0x009d
                           00009E   651 G$P6MDOUT$0_0$0 == 0x009e
                           00009E   652 _P6MDOUT	=	0x009e
                           00009F   653 G$P7MDOUT$0_0$0 == 0x009f
                           00009F   654 _P7MDOUT	=	0x009f
                           0000A1   655 G$CCH0CN$0_0$0 == 0x00a1
                           0000A1   656 _CCH0CN	=	0x00a1
                           0000A2   657 G$CCH0TN$0_0$0 == 0x00a2
                           0000A2   658 _CCH0TN	=	0x00a2
                           0000A3   659 G$CCH0LC$0_0$0 == 0x00a3
                           0000A3   660 _CCH0LC	=	0x00a3
                           0000A4   661 G$P0MDOUT$0_0$0 == 0x00a4
                           0000A4   662 _P0MDOUT	=	0x00a4
                           0000A5   663 G$P1MDOUT$0_0$0 == 0x00a5
                           0000A5   664 _P1MDOUT	=	0x00a5
                           0000A6   665 G$P2MDOUT$0_0$0 == 0x00a6
                           0000A6   666 _P2MDOUT	=	0x00a6
                           0000A7   667 G$P3MDOUT$0_0$0 == 0x00a7
                           0000A7   668 _P3MDOUT	=	0x00a7
                           0000AD   669 G$P1MDIN$0_0$0 == 0x00ad
                           0000AD   670 _P1MDIN	=	0x00ad
                           0000B7   671 G$FLACL$0_0$0 == 0x00b7
                           0000B7   672 _FLACL	=	0x00b7
                           0000C8   673 G$P4$0_0$0 == 0x00c8
                           0000C8   674 _P4	=	0x00c8
                           0000D8   675 G$P5$0_0$0 == 0x00d8
                           0000D8   676 _P5	=	0x00d8
                           0000E1   677 G$XBR0$0_0$0 == 0x00e1
                           0000E1   678 _XBR0	=	0x00e1
                           0000E2   679 G$XBR1$0_0$0 == 0x00e2
                           0000E2   680 _XBR1	=	0x00e2
                           0000E3   681 G$XBR2$0_0$0 == 0x00e3
                           0000E3   682 _XBR2	=	0x00e3
                           0000E8   683 G$ADC2CN$0_0$0 == 0x00e8
                           0000E8   684 _ADC2CN	=	0x00e8
                           0000E8   685 G$P6$0_0$0 == 0x00e8
                           0000E8   686 _P6	=	0x00e8
                           0000F8   687 G$P7$0_0$0 == 0x00f8
                           0000F8   688 _P7	=	0x00f8
                                    689 ;--------------------------------------------------------
                                    690 ; special function bits
                                    691 ;--------------------------------------------------------
                                    692 	.area RSEG    (ABS,DATA)
      000000                        693 	.org 0x0000
                           000080   694 G$P0_0$0_0$0 == 0x0080
                           000080   695 _P0_0	=	0x0080
                           000081   696 G$P0_1$0_0$0 == 0x0081
                           000081   697 _P0_1	=	0x0081
                           000082   698 G$P0_2$0_0$0 == 0x0082
                           000082   699 _P0_2	=	0x0082
                           000083   700 G$P0_3$0_0$0 == 0x0083
                           000083   701 _P0_3	=	0x0083
                           000084   702 G$P0_4$0_0$0 == 0x0084
                           000084   703 _P0_4	=	0x0084
                           000085   704 G$P0_5$0_0$0 == 0x0085
                           000085   705 _P0_5	=	0x0085
                           000086   706 G$P0_6$0_0$0 == 0x0086
                           000086   707 _P0_6	=	0x0086
                           000087   708 G$P0_7$0_0$0 == 0x0087
                           000087   709 _P0_7	=	0x0087
                           000088   710 G$IT0$0_0$0 == 0x0088
                           000088   711 _IT0	=	0x0088
                           000089   712 G$IE0$0_0$0 == 0x0089
                           000089   713 _IE0	=	0x0089
                           00008A   714 G$IT1$0_0$0 == 0x008a
                           00008A   715 _IT1	=	0x008a
                           00008B   716 G$IE1$0_0$0 == 0x008b
                           00008B   717 _IE1	=	0x008b
                           00008C   718 G$TR0$0_0$0 == 0x008c
                           00008C   719 _TR0	=	0x008c
                           00008D   720 G$TF0$0_0$0 == 0x008d
                           00008D   721 _TF0	=	0x008d
                           00008E   722 G$TR1$0_0$0 == 0x008e
                           00008E   723 _TR1	=	0x008e
                           00008F   724 G$TF1$0_0$0 == 0x008f
                           00008F   725 _TF1	=	0x008f
                           000088   726 G$CP0HYN0$0_0$0 == 0x0088
                           000088   727 _CP0HYN0	=	0x0088
                           000089   728 G$CP0HYN1$0_0$0 == 0x0089
                           000089   729 _CP0HYN1	=	0x0089
                           00008A   730 G$CP0HYP0$0_0$0 == 0x008a
                           00008A   731 _CP0HYP0	=	0x008a
                           00008B   732 G$CP0HYP1$0_0$0 == 0x008b
                           00008B   733 _CP0HYP1	=	0x008b
                           00008C   734 G$CP0FIF$0_0$0 == 0x008c
                           00008C   735 _CP0FIF	=	0x008c
                           00008D   736 G$CP0RIF$0_0$0 == 0x008d
                           00008D   737 _CP0RIF	=	0x008d
                           00008E   738 G$CP0OUT$0_0$0 == 0x008e
                           00008E   739 _CP0OUT	=	0x008e
                           00008F   740 G$CP0EN$0_0$0 == 0x008f
                           00008F   741 _CP0EN	=	0x008f
                           000088   742 G$CP1HYN0$0_0$0 == 0x0088
                           000088   743 _CP1HYN0	=	0x0088
                           000089   744 G$CP1HYN1$0_0$0 == 0x0089
                           000089   745 _CP1HYN1	=	0x0089
                           00008A   746 G$CP1HYP0$0_0$0 == 0x008a
                           00008A   747 _CP1HYP0	=	0x008a
                           00008B   748 G$CP1HYP1$0_0$0 == 0x008b
                           00008B   749 _CP1HYP1	=	0x008b
                           00008C   750 G$CP1FIF$0_0$0 == 0x008c
                           00008C   751 _CP1FIF	=	0x008c
                           00008D   752 G$CP1RIF$0_0$0 == 0x008d
                           00008D   753 _CP1RIF	=	0x008d
                           00008E   754 G$CP1OUT$0_0$0 == 0x008e
                           00008E   755 _CP1OUT	=	0x008e
                           00008F   756 G$CP1EN$0_0$0 == 0x008f
                           00008F   757 _CP1EN	=	0x008f
                           000088   758 G$FLHBUSY$0_0$0 == 0x0088
                           000088   759 _FLHBUSY	=	0x0088
                           000098   760 G$RI0$0_0$0 == 0x0098
                           000098   761 _RI0	=	0x0098
                           000098   762 G$RI$0_0$0 == 0x0098
                           000098   763 _RI	=	0x0098
                           000099   764 G$TI0$0_0$0 == 0x0099
                           000099   765 _TI0	=	0x0099
                           000099   766 G$TI$0_0$0 == 0x0099
                           000099   767 _TI	=	0x0099
                           00009A   768 G$RB80$0_0$0 == 0x009a
                           00009A   769 _RB80	=	0x009a
                           00009B   770 G$TB80$0_0$0 == 0x009b
                           00009B   771 _TB80	=	0x009b
                           00009C   772 G$REN0$0_0$0 == 0x009c
                           00009C   773 _REN0	=	0x009c
                           00009C   774 G$REN$0_0$0 == 0x009c
                           00009C   775 _REN	=	0x009c
                           00009D   776 G$SM20$0_0$0 == 0x009d
                           00009D   777 _SM20	=	0x009d
                           00009E   778 G$SM10$0_0$0 == 0x009e
                           00009E   779 _SM10	=	0x009e
                           00009F   780 G$SM00$0_0$0 == 0x009f
                           00009F   781 _SM00	=	0x009f
                           000098   782 G$RI1$0_0$0 == 0x0098
                           000098   783 _RI1	=	0x0098
                           000099   784 G$TI1$0_0$0 == 0x0099
                           000099   785 _TI1	=	0x0099
                           00009A   786 G$RB81$0_0$0 == 0x009a
                           00009A   787 _RB81	=	0x009a
                           00009B   788 G$TB81$0_0$0 == 0x009b
                           00009B   789 _TB81	=	0x009b
                           00009C   790 G$REN1$0_0$0 == 0x009c
                           00009C   791 _REN1	=	0x009c
                           00009D   792 G$MCE1$0_0$0 == 0x009d
                           00009D   793 _MCE1	=	0x009d
                           00009F   794 G$S1MODE$0_0$0 == 0x009f
                           00009F   795 _S1MODE	=	0x009f
                           0000A8   796 G$EX0$0_0$0 == 0x00a8
                           0000A8   797 _EX0	=	0x00a8
                           0000A9   798 G$ET0$0_0$0 == 0x00a9
                           0000A9   799 _ET0	=	0x00a9
                           0000AA   800 G$EX1$0_0$0 == 0x00aa
                           0000AA   801 _EX1	=	0x00aa
                           0000AB   802 G$ET1$0_0$0 == 0x00ab
                           0000AB   803 _ET1	=	0x00ab
                           0000AC   804 G$ES0$0_0$0 == 0x00ac
                           0000AC   805 _ES0	=	0x00ac
                           0000AC   806 G$ES$0_0$0 == 0x00ac
                           0000AC   807 _ES	=	0x00ac
                           0000AD   808 G$ET2$0_0$0 == 0x00ad
                           0000AD   809 _ET2	=	0x00ad
                           0000AF   810 G$EA$0_0$0 == 0x00af
                           0000AF   811 _EA	=	0x00af
                           0000B8   812 G$PX0$0_0$0 == 0x00b8
                           0000B8   813 _PX0	=	0x00b8
                           0000B9   814 G$PT0$0_0$0 == 0x00b9
                           0000B9   815 _PT0	=	0x00b9
                           0000BA   816 G$PX1$0_0$0 == 0x00ba
                           0000BA   817 _PX1	=	0x00ba
                           0000BB   818 G$PT1$0_0$0 == 0x00bb
                           0000BB   819 _PT1	=	0x00bb
                           0000BC   820 G$PS$0_0$0 == 0x00bc
                           0000BC   821 _PS	=	0x00bc
                           0000BD   822 G$PT2$0_0$0 == 0x00bd
                           0000BD   823 _PT2	=	0x00bd
                           0000C0   824 G$SMBTOE$0_0$0 == 0x00c0
                           0000C0   825 _SMBTOE	=	0x00c0
                           0000C1   826 G$SMBFTE$0_0$0 == 0x00c1
                           0000C1   827 _SMBFTE	=	0x00c1
                           0000C2   828 G$AA$0_0$0 == 0x00c2
                           0000C2   829 _AA	=	0x00c2
                           0000C3   830 G$SI$0_0$0 == 0x00c3
                           0000C3   831 _SI	=	0x00c3
                           0000C4   832 G$STO$0_0$0 == 0x00c4
                           0000C4   833 _STO	=	0x00c4
                           0000C5   834 G$STA$0_0$0 == 0x00c5
                           0000C5   835 _STA	=	0x00c5
                           0000C6   836 G$ENSMB$0_0$0 == 0x00c6
                           0000C6   837 _ENSMB	=	0x00c6
                           0000C7   838 G$BUSY$0_0$0 == 0x00c7
                           0000C7   839 _BUSY	=	0x00c7
                           0000C8   840 G$CPRL2$0_0$0 == 0x00c8
                           0000C8   841 _CPRL2	=	0x00c8
                           0000C9   842 G$CT2$0_0$0 == 0x00c9
                           0000C9   843 _CT2	=	0x00c9
                           0000CA   844 G$TR2$0_0$0 == 0x00ca
                           0000CA   845 _TR2	=	0x00ca
                           0000CB   846 G$EXEN2$0_0$0 == 0x00cb
                           0000CB   847 _EXEN2	=	0x00cb
                           0000CE   848 G$EXF2$0_0$0 == 0x00ce
                           0000CE   849 _EXF2	=	0x00ce
                           0000CF   850 G$TF2$0_0$0 == 0x00cf
                           0000CF   851 _TF2	=	0x00cf
                           0000C8   852 G$CPRL3$0_0$0 == 0x00c8
                           0000C8   853 _CPRL3	=	0x00c8
                           0000C9   854 G$CT3$0_0$0 == 0x00c9
                           0000C9   855 _CT3	=	0x00c9
                           0000CA   856 G$TR3$0_0$0 == 0x00ca
                           0000CA   857 _TR3	=	0x00ca
                           0000CB   858 G$EXEN3$0_0$0 == 0x00cb
                           0000CB   859 _EXEN3	=	0x00cb
                           0000CE   860 G$EXF3$0_0$0 == 0x00ce
                           0000CE   861 _EXF3	=	0x00ce
                           0000CF   862 G$TF3$0_0$0 == 0x00cf
                           0000CF   863 _TF3	=	0x00cf
                           0000C8   864 G$CPRL4$0_0$0 == 0x00c8
                           0000C8   865 _CPRL4	=	0x00c8
                           0000C9   866 G$CT4$0_0$0 == 0x00c9
                           0000C9   867 _CT4	=	0x00c9
                           0000CA   868 G$TR4$0_0$0 == 0x00ca
                           0000CA   869 _TR4	=	0x00ca
                           0000CB   870 G$EXEN4$0_0$0 == 0x00cb
                           0000CB   871 _EXEN4	=	0x00cb
                           0000CE   872 G$EXF4$0_0$0 == 0x00ce
                           0000CE   873 _EXF4	=	0x00ce
                           0000CF   874 G$TF4$0_0$0 == 0x00cf
                           0000CF   875 _TF4	=	0x00cf
                           0000C8   876 G$P4_0$0_0$0 == 0x00c8
                           0000C8   877 _P4_0	=	0x00c8
                           0000C9   878 G$P4_1$0_0$0 == 0x00c9
                           0000C9   879 _P4_1	=	0x00c9
                           0000CA   880 G$P4_2$0_0$0 == 0x00ca
                           0000CA   881 _P4_2	=	0x00ca
                           0000CB   882 G$P4_3$0_0$0 == 0x00cb
                           0000CB   883 _P4_3	=	0x00cb
                           0000CC   884 G$P4_4$0_0$0 == 0x00cc
                           0000CC   885 _P4_4	=	0x00cc
                           0000CD   886 G$P4_5$0_0$0 == 0x00cd
                           0000CD   887 _P4_5	=	0x00cd
                           0000CE   888 G$P4_6$0_0$0 == 0x00ce
                           0000CE   889 _P4_6	=	0x00ce
                           0000CF   890 G$P4_7$0_0$0 == 0x00cf
                           0000CF   891 _P4_7	=	0x00cf
                           0000D0   892 G$P$0_0$0 == 0x00d0
                           0000D0   893 _P	=	0x00d0
                           0000D1   894 G$F1$0_0$0 == 0x00d1
                           0000D1   895 _F1	=	0x00d1
                           0000D2   896 G$OV$0_0$0 == 0x00d2
                           0000D2   897 _OV	=	0x00d2
                           0000D3   898 G$RS0$0_0$0 == 0x00d3
                           0000D3   899 _RS0	=	0x00d3
                           0000D4   900 G$RS1$0_0$0 == 0x00d4
                           0000D4   901 _RS1	=	0x00d4
                           0000D5   902 G$F0$0_0$0 == 0x00d5
                           0000D5   903 _F0	=	0x00d5
                           0000D6   904 G$AC$0_0$0 == 0x00d6
                           0000D6   905 _AC	=	0x00d6
                           0000D7   906 G$CY$0_0$0 == 0x00d7
                           0000D7   907 _CY	=	0x00d7
                           0000D8   908 G$CCF0$0_0$0 == 0x00d8
                           0000D8   909 _CCF0	=	0x00d8
                           0000D9   910 G$CCF1$0_0$0 == 0x00d9
                           0000D9   911 _CCF1	=	0x00d9
                           0000DA   912 G$CCF2$0_0$0 == 0x00da
                           0000DA   913 _CCF2	=	0x00da
                           0000DB   914 G$CCF3$0_0$0 == 0x00db
                           0000DB   915 _CCF3	=	0x00db
                           0000DC   916 G$CCF4$0_0$0 == 0x00dc
                           0000DC   917 _CCF4	=	0x00dc
                           0000DD   918 G$CCF5$0_0$0 == 0x00dd
                           0000DD   919 _CCF5	=	0x00dd
                           0000DE   920 G$CR$0_0$0 == 0x00de
                           0000DE   921 _CR	=	0x00de
                           0000DF   922 G$CF$0_0$0 == 0x00df
                           0000DF   923 _CF	=	0x00df
                           0000D8   924 G$P5_0$0_0$0 == 0x00d8
                           0000D8   925 _P5_0	=	0x00d8
                           0000D9   926 G$P5_1$0_0$0 == 0x00d9
                           0000D9   927 _P5_1	=	0x00d9
                           0000DA   928 G$P5_2$0_0$0 == 0x00da
                           0000DA   929 _P5_2	=	0x00da
                           0000DB   930 G$P5_3$0_0$0 == 0x00db
                           0000DB   931 _P5_3	=	0x00db
                           0000DC   932 G$P5_4$0_0$0 == 0x00dc
                           0000DC   933 _P5_4	=	0x00dc
                           0000DD   934 G$P5_5$0_0$0 == 0x00dd
                           0000DD   935 _P5_5	=	0x00dd
                           0000DE   936 G$P5_6$0_0$0 == 0x00de
                           0000DE   937 _P5_6	=	0x00de
                           0000DF   938 G$P5_7$0_0$0 == 0x00df
                           0000DF   939 _P5_7	=	0x00df
                           0000E8   940 G$AD0LJST$0_0$0 == 0x00e8
                           0000E8   941 _AD0LJST	=	0x00e8
                           0000E9   942 G$AD0WINT$0_0$0 == 0x00e9
                           0000E9   943 _AD0WINT	=	0x00e9
                           0000EA   944 G$AD0CM0$0_0$0 == 0x00ea
                           0000EA   945 _AD0CM0	=	0x00ea
                           0000EB   946 G$AD0CM1$0_0$0 == 0x00eb
                           0000EB   947 _AD0CM1	=	0x00eb
                           0000EC   948 G$AD0BUSY$0_0$0 == 0x00ec
                           0000EC   949 _AD0BUSY	=	0x00ec
                           0000ED   950 G$AD0INT$0_0$0 == 0x00ed
                           0000ED   951 _AD0INT	=	0x00ed
                           0000EE   952 G$AD0TM$0_0$0 == 0x00ee
                           0000EE   953 _AD0TM	=	0x00ee
                           0000EF   954 G$AD0EN$0_0$0 == 0x00ef
                           0000EF   955 _AD0EN	=	0x00ef
                           0000E8   956 G$AD2WINT$0_0$0 == 0x00e8
                           0000E8   957 _AD2WINT	=	0x00e8
                           0000E9   958 G$AD2CM0$0_0$0 == 0x00e9
                           0000E9   959 _AD2CM0	=	0x00e9
                           0000EA   960 G$AD2CM1$0_0$0 == 0x00ea
                           0000EA   961 _AD2CM1	=	0x00ea
                           0000EB   962 G$AD2CM2$0_0$0 == 0x00eb
                           0000EB   963 _AD2CM2	=	0x00eb
                           0000EC   964 G$AD2BUSY$0_0$0 == 0x00ec
                           0000EC   965 _AD2BUSY	=	0x00ec
                           0000ED   966 G$AD2INT$0_0$0 == 0x00ed
                           0000ED   967 _AD2INT	=	0x00ed
                           0000EE   968 G$AD2TM$0_0$0 == 0x00ee
                           0000EE   969 _AD2TM	=	0x00ee
                           0000EF   970 G$AD2EN$0_0$0 == 0x00ef
                           0000EF   971 _AD2EN	=	0x00ef
                           0000E8   972 G$P6_0$0_0$0 == 0x00e8
                           0000E8   973 _P6_0	=	0x00e8
                           0000E9   974 G$P6_1$0_0$0 == 0x00e9
                           0000E9   975 _P6_1	=	0x00e9
                           0000EA   976 G$P6_2$0_0$0 == 0x00ea
                           0000EA   977 _P6_2	=	0x00ea
                           0000EB   978 G$P6_3$0_0$0 == 0x00eb
                           0000EB   979 _P6_3	=	0x00eb
                           0000EC   980 G$P6_4$0_0$0 == 0x00ec
                           0000EC   981 _P6_4	=	0x00ec
                           0000ED   982 G$P6_5$0_0$0 == 0x00ed
                           0000ED   983 _P6_5	=	0x00ed
                           0000EE   984 G$P6_6$0_0$0 == 0x00ee
                           0000EE   985 _P6_6	=	0x00ee
                           0000EF   986 G$P6_7$0_0$0 == 0x00ef
                           0000EF   987 _P6_7	=	0x00ef
                           0000F8   988 G$SPIEN$0_0$0 == 0x00f8
                           0000F8   989 _SPIEN	=	0x00f8
                           0000F9   990 G$TXBMT$0_0$0 == 0x00f9
                           0000F9   991 _TXBMT	=	0x00f9
                           0000FA   992 G$NSSMD0$0_0$0 == 0x00fa
                           0000FA   993 _NSSMD0	=	0x00fa
                           0000FB   994 G$NSSMD1$0_0$0 == 0x00fb
                           0000FB   995 _NSSMD1	=	0x00fb
                           0000FC   996 G$RXOVRN$0_0$0 == 0x00fc
                           0000FC   997 _RXOVRN	=	0x00fc
                           0000FD   998 G$MODF$0_0$0 == 0x00fd
                           0000FD   999 _MODF	=	0x00fd
                           0000FE  1000 G$WCOL$0_0$0 == 0x00fe
                           0000FE  1001 _WCOL	=	0x00fe
                           0000FF  1002 G$SPIF$0_0$0 == 0x00ff
                           0000FF  1003 _SPIF	=	0x00ff
                           0000F8  1004 G$P7_0$0_0$0 == 0x00f8
                           0000F8  1005 _P7_0	=	0x00f8
                           0000F9  1006 G$P7_1$0_0$0 == 0x00f9
                           0000F9  1007 _P7_1	=	0x00f9
                           0000FA  1008 G$P7_2$0_0$0 == 0x00fa
                           0000FA  1009 _P7_2	=	0x00fa
                           0000FB  1010 G$P7_3$0_0$0 == 0x00fb
                           0000FB  1011 _P7_3	=	0x00fb
                           0000FC  1012 G$P7_4$0_0$0 == 0x00fc
                           0000FC  1013 _P7_4	=	0x00fc
                           0000FD  1014 G$P7_5$0_0$0 == 0x00fd
                           0000FD  1015 _P7_5	=	0x00fd
                           0000FE  1016 G$P7_6$0_0$0 == 0x00fe
                           0000FE  1017 _P7_6	=	0x00fe
                           0000FF  1018 G$P7_7$0_0$0 == 0x00ff
                           0000FF  1019 _P7_7	=	0x00ff
                                   1020 ;--------------------------------------------------------
                                   1021 ; overlayable register banks
                                   1022 ;--------------------------------------------------------
                                   1023 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                       1024 	.ds 8
                                   1025 ;--------------------------------------------------------
                                   1026 ; internal ram data
                                   1027 ;--------------------------------------------------------
                                   1028 	.area DSEG    (DATA)
                                   1029 ;--------------------------------------------------------
                                   1030 ; overlayable items in internal ram 
                                   1031 ;--------------------------------------------------------
                                   1032 ;--------------------------------------------------------
                                   1033 ; indirectly addressable internal ram data
                                   1034 ;--------------------------------------------------------
                                   1035 	.area ISEG    (DATA)
                                   1036 ;--------------------------------------------------------
                                   1037 ; absolute internal ram data
                                   1038 ;--------------------------------------------------------
                                   1039 	.area IABS    (ABS,DATA)
                                   1040 	.area IABS    (ABS,DATA)
                                   1041 ;--------------------------------------------------------
                                   1042 ; bit data
                                   1043 ;--------------------------------------------------------
                                   1044 	.area BSEG    (BIT)
                                   1045 ;--------------------------------------------------------
                                   1046 ; paged external ram data
                                   1047 ;--------------------------------------------------------
                                   1048 	.area PSEG    (PAG,XDATA)
                                   1049 ;--------------------------------------------------------
                                   1050 ; external ram data
                                   1051 ;--------------------------------------------------------
                                   1052 	.area XSEG    (XDATA)
                           000000  1053 G$ucBit$0_0$0==.
      000001                       1054 _ucBit::
      000001                       1055 	.ds 1
                                   1056 ;--------------------------------------------------------
                                   1057 ; absolute external ram data
                                   1058 ;--------------------------------------------------------
                                   1059 	.area XABS    (ABS,XDATA)
                                   1060 ;--------------------------------------------------------
                                   1061 ; external initialized ram data
                                   1062 ;--------------------------------------------------------
                                   1063 	.area XISEG   (XDATA)
                                   1064 	.area HOME    (CODE)
                                   1065 	.area GSINIT0 (CODE)
                                   1066 	.area GSINIT1 (CODE)
                                   1067 	.area GSINIT2 (CODE)
                                   1068 	.area GSINIT3 (CODE)
                                   1069 	.area GSINIT4 (CODE)
                                   1070 	.area GSINIT5 (CODE)
                                   1071 	.area GSINIT  (CODE)
                                   1072 	.area GSFINAL (CODE)
                                   1073 	.area CSEG    (CODE)
                                   1074 ;--------------------------------------------------------
                                   1075 ; global & static initialisations
                                   1076 ;--------------------------------------------------------
                                   1077 	.area HOME    (CODE)
                                   1078 	.area GSINIT  (CODE)
                                   1079 	.area GSFINAL (CODE)
                                   1080 	.area GSINIT  (CODE)
                                   1081 ;--------------------------------------------------------
                                   1082 ; Home
                                   1083 ;--------------------------------------------------------
                                   1084 	.area HOME    (CODE)
                                   1085 	.area HOME    (CODE)
                                   1086 ;--------------------------------------------------------
                                   1087 ; code
                                   1088 ;--------------------------------------------------------
                                   1089 	.area CSEG    (CODE)
                                   1090 ;------------------------------------------------------------
                                   1091 ;Allocation info for local variables in function 'vParTestInitialise'
                                   1092 ;------------------------------------------------------------
                                   1093 ;ucOriginalSFRPage         Allocated to registers r7 
                                   1094 ;------------------------------------------------------------
                           000000  1095 	G$vParTestInitialise$0$0 ==.
                           000000  1096 	C$ParTest.c$50$0_0$86 ==.
                                   1097 ;	ParTest/ParTest.c:50: void vParTestInitialise( void )
                                   1098 ;	-----------------------------------------
                                   1099 ;	 function vParTestInitialise
                                   1100 ;	-----------------------------------------
      00084B                       1101 _vParTestInitialise:
                           000007  1102 	ar7 = 0x07
                           000006  1103 	ar6 = 0x06
                           000005  1104 	ar5 = 0x05
                           000004  1105 	ar4 = 0x04
                           000003  1106 	ar3 = 0x03
                           000002  1107 	ar2 = 0x02
                           000001  1108 	ar1 = 0x01
                           000000  1109 	ar0 = 0x00
                           000000  1110 	C$ParTest.c$56$1_0$86 ==.
                                   1111 ;	ParTest/ParTest.c:56: ucOriginalSFRPage = SFRPAGE;
      00084B AF 84            [24] 1112 	mov	r7,_SFRPAGE
                           000002  1113 	C$ParTest.c$59$1_0$86 ==.
                                   1114 ;	ParTest/ParTest.c:59: SFRPAGE = CONFIG_PAGE;
      00084D 75 84 0F         [24] 1115 	mov	_SFRPAGE,#0x0f
                           000005  1116 	C$ParTest.c$63$1_0$86 ==.
                                   1117 ;	ParTest/ParTest.c:63: P1MDOUT |= partstPUSH_PULL;
      000850 E5 A5            [12] 1118 	mov	a,_P1MDOUT
      000852 75 A5 FF         [24] 1119 	mov	_P1MDOUT,#0xff
                           00000A  1120 	C$ParTest.c$66$1_0$86 ==.
                                   1121 ;	ParTest/ParTest.c:66: SFRPAGE = ucOriginalSFRPage;
      000855 8F 84            [24] 1122 	mov	_SFRPAGE,r7
                           00000C  1123 	C$ParTest.c$69$1_0$86 ==.
                                   1124 ;	ParTest/ParTest.c:69: P1 = partstALL_OUTPUTS_OFF;
      000857 75 90 FF         [24] 1125 	mov	_P1,#0xff
      00085A                       1126 00101$:
                           00000F  1127 	C$ParTest.c$70$1_0$86 ==.
                                   1128 ;	ParTest/ParTest.c:70: }
                           00000F  1129 	C$ParTest.c$70$1_0$86 ==.
                           00000F  1130 	XG$vParTestInitialise$0$0 ==.
      00085A 22               [24] 1131 	ret
                                   1132 ;------------------------------------------------------------
                                   1133 ;Allocation info for local variables in function 'vParTestSetLED'
                                   1134 ;------------------------------------------------------------
                                   1135 ;xValue                    Allocated to stack - _bp -3
                                   1136 ;uxLED                     Allocated to registers r7 
                                   1137 ;xError                    Allocated to registers 
                                   1138 ;------------------------------------------------------------
                           000010  1139 	G$vParTestSetLED$0$0 ==.
                           000010  1140 	C$ParTest.c$73$1_0$88 ==.
                                   1141 ;	ParTest/ParTest.c:73: void vParTestSetLED( unsigned portBASE_TYPE uxLED, signed portBASE_TYPE xValue )
                                   1142 ;	-----------------------------------------
                                   1143 ;	 function vParTestSetLED
                                   1144 ;	-----------------------------------------
      00085B                       1145 _vParTestSetLED:
      00085B C0 0D            [24] 1146 	push	_bp
      00085D 85 81 0D         [24] 1147 	mov	_bp,sp
      000860 AF 82            [24] 1148 	mov	r7,dpl
                           000017  1149 	C$ParTest.c$77$1_0$88 ==.
                                   1150 ;	ParTest/ParTest.c:77: vTaskSuspendAll();
      000862 C0 07            [24] 1151 	push	ar7
      000864 12 24 E7         [24] 1152 	lcall	_vTaskSuspendAll
      000867 D0 07            [24] 1153 	pop	ar7
                           00001E  1154 	C$ParTest.c$79$2_0$89 ==.
                                   1155 ;	ParTest/ParTest.c:79: if( xValue == pdFALSE )
      000869 E5 0D            [12] 1156 	mov	a,_bp
      00086B 24 FD            [12] 1157 	add	a,#0xfd
      00086D F8               [12] 1158 	mov	r0,a
      00086E E6               [12] 1159 	mov	a,@r0
      00086F 60 03            [24] 1160 	jz	00138$
      000871 02 08 CB         [24] 1161 	ljmp	00122$
      000874                       1162 00138$:
                           000029  1163 	C$ParTest.c$81$3_0$90 ==.
                                   1164 ;	ParTest/ParTest.c:81: switch( uxLED )
      000874 C3               [12] 1165 	clr	c
      000875 74 07            [12] 1166 	mov	a,#0x07
      000877 9F               [12] 1167 	subb	a,r7
      000878 50 03            [24] 1168 	jnc	00139$
      00087A 02 09 1F         [24] 1169 	ljmp	00123$
      00087D                       1170 00139$:
      00087D EF               [12] 1171 	mov	a,r7
      00087E 24 0A            [12] 1172 	add	a,#(00140$-3-.)
      000880 83               [24] 1173 	movc	a,@a+pc
      000881 F5 82            [12] 1174 	mov	dpl,a
      000883 EF               [12] 1175 	mov	a,r7
      000884 24 0C            [12] 1176 	add	a,#(00141$-3-.)
      000886 83               [24] 1177 	movc	a,@a+pc
      000887 F5 83            [12] 1178 	mov	dph,a
      000889 E4               [12] 1179 	clr	a
      00088A 73               [24] 1180 	jmp	@a+dptr
      00088B                       1181 00140$:
      00088B 9B                    1182 	.db	00101$
      00088C A1                    1183 	.db	00102$
      00088D A7                    1184 	.db	00103$
      00088E AD                    1185 	.db	00104$
      00088F B3                    1186 	.db	00105$
      000890 B9                    1187 	.db	00106$
      000891 BF                    1188 	.db	00107$
      000892 C5                    1189 	.db	00108$
      000893                       1190 00141$:
      000893 08                    1191 	.db	00101$>>8
      000894 08                    1192 	.db	00102$>>8
      000895 08                    1193 	.db	00103$>>8
      000896 08                    1194 	.db	00104$>>8
      000897 08                    1195 	.db	00105$>>8
      000898 08                    1196 	.db	00106$>>8
      000899 08                    1197 	.db	00107$>>8
      00089A 08                    1198 	.db	00108$>>8
                           000050  1199 	C$ParTest.c$83$4_0$91 ==.
                                   1200 ;	ParTest/ParTest.c:83: case 0	:	P1 |= partstOUTPUT_0;
      00089B                       1201 00101$:
      00089B 43 90 02         [24] 1202 	orl	_P1,#0x02
                           000053  1203 	C$ParTest.c$84$4_0$91 ==.
                                   1204 ;	ParTest/ParTest.c:84: break;
      00089E 02 09 1F         [24] 1205 	ljmp	00123$
                           000056  1206 	C$ParTest.c$85$4_0$91 ==.
                                   1207 ;	ParTest/ParTest.c:85: case 1	:	P1 |= partstOUTPUT_1;
      0008A1                       1208 00102$:
      0008A1 43 90 08         [24] 1209 	orl	_P1,#0x08
                           000059  1210 	C$ParTest.c$86$4_0$91 ==.
                                   1211 ;	ParTest/ParTest.c:86: break;
      0008A4 02 09 1F         [24] 1212 	ljmp	00123$
                           00005C  1213 	C$ParTest.c$87$4_0$91 ==.
                                   1214 ;	ParTest/ParTest.c:87: case 2	:	P1 |= partstOUTPUT_2;
      0008A7                       1215 00103$:
      0008A7 43 90 20         [24] 1216 	orl	_P1,#0x20
                           00005F  1217 	C$ParTest.c$88$4_0$91 ==.
                                   1218 ;	ParTest/ParTest.c:88: break;
      0008AA 02 09 1F         [24] 1219 	ljmp	00123$
                           000062  1220 	C$ParTest.c$89$4_0$91 ==.
                                   1221 ;	ParTest/ParTest.c:89: case 3	:	P1 |= partstOUTPUT_3;
      0008AD                       1222 00104$:
      0008AD 43 90 01         [24] 1223 	orl	_P1,#0x01
                           000065  1224 	C$ParTest.c$90$4_0$91 ==.
                                   1225 ;	ParTest/ParTest.c:90: break;
      0008B0 02 09 1F         [24] 1226 	ljmp	00123$
                           000068  1227 	C$ParTest.c$91$4_0$91 ==.
                                   1228 ;	ParTest/ParTest.c:91: case 4	:	P1 |= partstOUTPUT_4;
      0008B3                       1229 00105$:
      0008B3 43 90 04         [24] 1230 	orl	_P1,#0x04
                           00006B  1231 	C$ParTest.c$92$4_0$91 ==.
                                   1232 ;	ParTest/ParTest.c:92: break;
      0008B6 02 09 1F         [24] 1233 	ljmp	00123$
                           00006E  1234 	C$ParTest.c$93$4_0$91 ==.
                                   1235 ;	ParTest/ParTest.c:93: case 5	:	P1 |= partstOUTPUT_5;
      0008B9                       1236 00106$:
      0008B9 43 90 10         [24] 1237 	orl	_P1,#0x10
                           000071  1238 	C$ParTest.c$94$4_0$91 ==.
                                   1239 ;	ParTest/ParTest.c:94: break;
      0008BC 02 09 1F         [24] 1240 	ljmp	00123$
                           000074  1241 	C$ParTest.c$95$4_0$91 ==.
                                   1242 ;	ParTest/ParTest.c:95: case 6	:	P1 |= partstOUTPUT_6;
      0008BF                       1243 00107$:
      0008BF 43 90 40         [24] 1244 	orl	_P1,#0x40
                           000077  1245 	C$ParTest.c$96$4_0$91 ==.
                                   1246 ;	ParTest/ParTest.c:96: break;
      0008C2 02 09 1F         [24] 1247 	ljmp	00123$
                           00007A  1248 	C$ParTest.c$97$4_0$91 ==.
                                   1249 ;	ParTest/ParTest.c:97: case 7	:	P1 |= partstOUTPUT_7;
      0008C5                       1250 00108$:
      0008C5 43 90 80         [24] 1251 	orl	_P1,#0x80
                           00007D  1252 	C$ParTest.c$98$4_0$91 ==.
                                   1253 ;	ParTest/ParTest.c:98: break;
      0008C8 02 09 1F         [24] 1254 	ljmp	00123$
                           000080  1255 	C$ParTest.c$102$2_0$89 ==.
                                   1256 ;	ParTest/ParTest.c:102: }
      0008CB                       1257 00122$:
                           000080  1258 	C$ParTest.c$106$3_0$92 ==.
                                   1259 ;	ParTest/ParTest.c:106: switch( uxLED )
      0008CB C3               [12] 1260 	clr	c
      0008CC 74 07            [12] 1261 	mov	a,#0x07
      0008CE 9F               [12] 1262 	subb	a,r7
      0008CF 50 03            [24] 1263 	jnc	00142$
      0008D1 02 09 1F         [24] 1264 	ljmp	00123$
      0008D4                       1265 00142$:
      0008D4 EF               [12] 1266 	mov	a,r7
      0008D5 24 0A            [12] 1267 	add	a,#(00143$-3-.)
      0008D7 83               [24] 1268 	movc	a,@a+pc
      0008D8 F5 82            [12] 1269 	mov	dpl,a
      0008DA EF               [12] 1270 	mov	a,r7
      0008DB 24 0C            [12] 1271 	add	a,#(00144$-3-.)
      0008DD 83               [24] 1272 	movc	a,@a+pc
      0008DE F5 83            [12] 1273 	mov	dph,a
      0008E0 E4               [12] 1274 	clr	a
      0008E1 73               [24] 1275 	jmp	@a+dptr
      0008E2                       1276 00143$:
      0008E2 F2                    1277 	.db	00111$
      0008E3 F8                    1278 	.db	00112$
      0008E4 FE                    1279 	.db	00113$
      0008E5 04                    1280 	.db	00114$
      0008E6 0A                    1281 	.db	00115$
      0008E7 10                    1282 	.db	00116$
      0008E8 16                    1283 	.db	00117$
      0008E9 1C                    1284 	.db	00118$
      0008EA                       1285 00144$:
      0008EA 08                    1286 	.db	00111$>>8
      0008EB 08                    1287 	.db	00112$>>8
      0008EC 08                    1288 	.db	00113$>>8
      0008ED 09                    1289 	.db	00114$>>8
      0008EE 09                    1290 	.db	00115$>>8
      0008EF 09                    1291 	.db	00116$>>8
      0008F0 09                    1292 	.db	00117$>>8
      0008F1 09                    1293 	.db	00118$>>8
                           0000A7  1294 	C$ParTest.c$108$4_0$93 ==.
                                   1295 ;	ParTest/ParTest.c:108: case 0	:	P1 &= ~partstOUTPUT_0;
      0008F2                       1296 00111$:
      0008F2 53 90 FD         [24] 1297 	anl	_P1,#0xfd
                           0000AA  1298 	C$ParTest.c$109$4_0$93 ==.
                                   1299 ;	ParTest/ParTest.c:109: break;
      0008F5 02 09 1F         [24] 1300 	ljmp	00123$
                           0000AD  1301 	C$ParTest.c$110$4_0$93 ==.
                                   1302 ;	ParTest/ParTest.c:110: case 1	:	P1 &= ~partstOUTPUT_1;
      0008F8                       1303 00112$:
      0008F8 53 90 F7         [24] 1304 	anl	_P1,#0xf7
                           0000B0  1305 	C$ParTest.c$111$4_0$93 ==.
                                   1306 ;	ParTest/ParTest.c:111: break;
      0008FB 02 09 1F         [24] 1307 	ljmp	00123$
                           0000B3  1308 	C$ParTest.c$112$4_0$93 ==.
                                   1309 ;	ParTest/ParTest.c:112: case 2	:	P1 &= ~partstOUTPUT_2;
      0008FE                       1310 00113$:
      0008FE 53 90 DF         [24] 1311 	anl	_P1,#0xdf
                           0000B6  1312 	C$ParTest.c$113$4_0$93 ==.
                                   1313 ;	ParTest/ParTest.c:113: break;
      000901 02 09 1F         [24] 1314 	ljmp	00123$
                           0000B9  1315 	C$ParTest.c$114$4_0$93 ==.
                                   1316 ;	ParTest/ParTest.c:114: case 3	:	P1 &= ~partstOUTPUT_3;
      000904                       1317 00114$:
      000904 53 90 FE         [24] 1318 	anl	_P1,#0xfe
                           0000BC  1319 	C$ParTest.c$115$4_0$93 ==.
                                   1320 ;	ParTest/ParTest.c:115: break;
      000907 02 09 1F         [24] 1321 	ljmp	00123$
                           0000BF  1322 	C$ParTest.c$116$4_0$93 ==.
                                   1323 ;	ParTest/ParTest.c:116: case 4	:	P1 &= ~partstOUTPUT_4;
      00090A                       1324 00115$:
      00090A 53 90 FB         [24] 1325 	anl	_P1,#0xfb
                           0000C2  1326 	C$ParTest.c$117$4_0$93 ==.
                                   1327 ;	ParTest/ParTest.c:117: break;
      00090D 02 09 1F         [24] 1328 	ljmp	00123$
                           0000C5  1329 	C$ParTest.c$118$4_0$93 ==.
                                   1330 ;	ParTest/ParTest.c:118: case 5	:	P1 &= ~partstOUTPUT_5;
      000910                       1331 00116$:
      000910 53 90 EF         [24] 1332 	anl	_P1,#0xef
                           0000C8  1333 	C$ParTest.c$119$4_0$93 ==.
                                   1334 ;	ParTest/ParTest.c:119: break;
      000913 02 09 1F         [24] 1335 	ljmp	00123$
                           0000CB  1336 	C$ParTest.c$120$4_0$93 ==.
                                   1337 ;	ParTest/ParTest.c:120: case 6	:	P1 &= ~partstOUTPUT_6;
      000916                       1338 00117$:
      000916 53 90 BF         [24] 1339 	anl	_P1,#0xbf
                           0000CE  1340 	C$ParTest.c$121$4_0$93 ==.
                                   1341 ;	ParTest/ParTest.c:121: break;
      000919 02 09 1F         [24] 1342 	ljmp	00123$
                           0000D1  1343 	C$ParTest.c$122$4_0$93 ==.
                                   1344 ;	ParTest/ParTest.c:122: case 7	:	P1 &= ~partstOUTPUT_7;
      00091C                       1345 00118$:
      00091C 53 90 7F         [24] 1346 	anl	_P1,#0x7f
                           0000D4  1347 	C$ParTest.c$126$2_0$89 ==.
                                   1348 ;	ParTest/ParTest.c:126: }
      00091F                       1349 00123$:
                           0000D4  1350 	C$ParTest.c$129$1_0$88 ==.
                                   1351 ;	ParTest/ParTest.c:129: xTaskResumeAll();
      00091F 12 24 EF         [24] 1352 	lcall	_xTaskResumeAll
      000922                       1353 00124$:
                           0000D7  1354 	C$ParTest.c$130$1_0$88 ==.
                                   1355 ;	ParTest/ParTest.c:130: }
      000922 D0 0D            [24] 1356 	pop	_bp
                           0000D9  1357 	C$ParTest.c$130$1_0$88 ==.
                           0000D9  1358 	XG$vParTestSetLED$0$0 ==.
      000924 22               [24] 1359 	ret
                                   1360 ;------------------------------------------------------------
                                   1361 ;Allocation info for local variables in function 'vParTestToggleLED'
                                   1362 ;------------------------------------------------------------
                                   1363 ;uxLED                     Allocated to registers r7 
                                   1364 ;xError                    Allocated to registers r6 
                                   1365 ;------------------------------------------------------------
                           0000DA  1366 	G$vParTestToggleLED$0$0 ==.
                           0000DA  1367 	C$ParTest.c$135$1_0$95 ==.
                                   1368 ;	ParTest/ParTest.c:135: void vParTestToggleLED( unsigned portBASE_TYPE uxLED )
                                   1369 ;	-----------------------------------------
                                   1370 ;	 function vParTestToggleLED
                                   1371 ;	-----------------------------------------
      000925                       1372 _vParTestToggleLED:
      000925 AF 82            [24] 1373 	mov	r7,dpl
                           0000DC  1374 	C$ParTest.c$138$2_0$95 ==.
                                   1375 ;	ParTest/ParTest.c:138: portBASE_TYPE xError = pdFALSE;
      000927 7E 00            [12] 1376 	mov	r6,#0x00
                           0000DE  1377 	C$ParTest.c$140$1_0$95 ==.
                                   1378 ;	ParTest/ParTest.c:140: vTaskSuspendAll();
      000929 C0 07            [24] 1379 	push	ar7
      00092B C0 06            [24] 1380 	push	ar6
      00092D 12 24 E7         [24] 1381 	lcall	_vTaskSuspendAll
      000930 D0 06            [24] 1382 	pop	ar6
      000932 D0 07            [24] 1383 	pop	ar7
                           0000E9  1384 	C$ParTest.c$142$2_0$96 ==.
                                   1385 ;	ParTest/ParTest.c:142: switch( uxLED )
      000934 C3               [12] 1386 	clr	c
      000935 74 07            [12] 1387 	mov	a,#0x07
      000937 9F               [12] 1388 	subb	a,r7
      000938 50 03            [24] 1389 	jnc	00130$
      00093A 02 09 A3         [24] 1390 	ljmp	00109$
      00093D                       1391 00130$:
      00093D EF               [12] 1392 	mov	a,r7
      00093E 24 0A            [12] 1393 	add	a,#(00131$-3-.)
      000940 83               [24] 1394 	movc	a,@a+pc
      000941 F5 82            [12] 1395 	mov	dpl,a
      000943 EF               [12] 1396 	mov	a,r7
      000944 24 0C            [12] 1397 	add	a,#(00132$-3-.)
      000946 83               [24] 1398 	movc	a,@a+pc
      000947 F5 83            [12] 1399 	mov	dph,a
      000949 E4               [12] 1400 	clr	a
      00094A 73               [24] 1401 	jmp	@a+dptr
      00094B                       1402 00131$:
      00094B 5B                    1403 	.db	00101$
      00094C 64                    1404 	.db	00102$
      00094D 6D                    1405 	.db	00103$
      00094E 76                    1406 	.db	00104$
      00094F 7F                    1407 	.db	00105$
      000950 88                    1408 	.db	00106$
      000951 91                    1409 	.db	00107$
      000952 9A                    1410 	.db	00108$
      000953                       1411 00132$:
      000953 09                    1412 	.db	00101$>>8
      000954 09                    1413 	.db	00102$>>8
      000955 09                    1414 	.db	00103$>>8
      000956 09                    1415 	.db	00104$>>8
      000957 09                    1416 	.db	00105$>>8
      000958 09                    1417 	.db	00106$>>8
      000959 09                    1418 	.db	00107$>>8
      00095A 09                    1419 	.db	00108$>>8
                           000110  1420 	C$ParTest.c$144$3_0$97 ==.
                                   1421 ;	ParTest/ParTest.c:144: case 0	:	ucBit = partstOUTPUT_0;
      00095B                       1422 00101$:
      00095B 90 00 01         [24] 1423 	mov	dptr,#_ucBit
      00095E 74 02            [12] 1424 	mov	a,#0x02
      000960 F0               [24] 1425 	movx	@dptr,a
                           000116  1426 	C$ParTest.c$145$3_0$97 ==.
                                   1427 ;	ParTest/ParTest.c:145: break;
      000961 02 09 A5         [24] 1428 	ljmp	00110$
                           000119  1429 	C$ParTest.c$146$3_0$97 ==.
                                   1430 ;	ParTest/ParTest.c:146: case 1	:	ucBit = partstOUTPUT_1;
      000964                       1431 00102$:
      000964 90 00 01         [24] 1432 	mov	dptr,#_ucBit
      000967 74 08            [12] 1433 	mov	a,#0x08
      000969 F0               [24] 1434 	movx	@dptr,a
                           00011F  1435 	C$ParTest.c$147$3_0$97 ==.
                                   1436 ;	ParTest/ParTest.c:147: break;
      00096A 02 09 A5         [24] 1437 	ljmp	00110$
                           000122  1438 	C$ParTest.c$148$3_0$97 ==.
                                   1439 ;	ParTest/ParTest.c:148: case 2	:	ucBit = partstOUTPUT_2;
      00096D                       1440 00103$:
      00096D 90 00 01         [24] 1441 	mov	dptr,#_ucBit
      000970 74 20            [12] 1442 	mov	a,#0x20
      000972 F0               [24] 1443 	movx	@dptr,a
                           000128  1444 	C$ParTest.c$149$3_0$97 ==.
                                   1445 ;	ParTest/ParTest.c:149: break;
      000973 02 09 A5         [24] 1446 	ljmp	00110$
                           00012B  1447 	C$ParTest.c$150$3_0$97 ==.
                                   1448 ;	ParTest/ParTest.c:150: case 3	:	ucBit = partstOUTPUT_3;
      000976                       1449 00104$:
      000976 90 00 01         [24] 1450 	mov	dptr,#_ucBit
      000979 74 01            [12] 1451 	mov	a,#0x01
      00097B F0               [24] 1452 	movx	@dptr,a
                           000131  1453 	C$ParTest.c$151$3_0$97 ==.
                                   1454 ;	ParTest/ParTest.c:151: break;
      00097C 02 09 A5         [24] 1455 	ljmp	00110$
                           000134  1456 	C$ParTest.c$152$3_0$97 ==.
                                   1457 ;	ParTest/ParTest.c:152: case 4	:	ucBit = partstOUTPUT_4;
      00097F                       1458 00105$:
      00097F 90 00 01         [24] 1459 	mov	dptr,#_ucBit
      000982 74 04            [12] 1460 	mov	a,#0x04
      000984 F0               [24] 1461 	movx	@dptr,a
                           00013A  1462 	C$ParTest.c$153$3_0$97 ==.
                                   1463 ;	ParTest/ParTest.c:153: break;
      000985 02 09 A5         [24] 1464 	ljmp	00110$
                           00013D  1465 	C$ParTest.c$154$3_0$97 ==.
                                   1466 ;	ParTest/ParTest.c:154: case 5	:	ucBit = partstOUTPUT_5;
      000988                       1467 00106$:
      000988 90 00 01         [24] 1468 	mov	dptr,#_ucBit
      00098B 74 10            [12] 1469 	mov	a,#0x10
      00098D F0               [24] 1470 	movx	@dptr,a
                           000143  1471 	C$ParTest.c$155$3_0$97 ==.
                                   1472 ;	ParTest/ParTest.c:155: break;
      00098E 02 09 A5         [24] 1473 	ljmp	00110$
                           000146  1474 	C$ParTest.c$156$3_0$97 ==.
                                   1475 ;	ParTest/ParTest.c:156: case 6	:	ucBit = partstOUTPUT_6;
      000991                       1476 00107$:
      000991 90 00 01         [24] 1477 	mov	dptr,#_ucBit
      000994 74 40            [12] 1478 	mov	a,#0x40
      000996 F0               [24] 1479 	movx	@dptr,a
                           00014C  1480 	C$ParTest.c$157$3_0$97 ==.
                                   1481 ;	ParTest/ParTest.c:157: break;
      000997 02 09 A5         [24] 1482 	ljmp	00110$
                           00014F  1483 	C$ParTest.c$158$3_0$97 ==.
                                   1484 ;	ParTest/ParTest.c:158: case 7	:	ucBit = partstOUTPUT_7;
      00099A                       1485 00108$:
      00099A 90 00 01         [24] 1486 	mov	dptr,#_ucBit
      00099D 74 80            [12] 1487 	mov	a,#0x80
      00099F F0               [24] 1488 	movx	@dptr,a
                           000155  1489 	C$ParTest.c$159$3_0$97 ==.
                                   1490 ;	ParTest/ParTest.c:159: break;
      0009A0 02 09 A5         [24] 1491 	ljmp	00110$
                           000158  1492 	C$ParTest.c$160$3_0$97 ==.
                                   1493 ;	ParTest/ParTest.c:160: default	:	/* There are no other LED's wired in. */
      0009A3                       1494 00109$:
                           000158  1495 	C$ParTest.c$161$3_0$97 ==.
                                   1496 ;	ParTest/ParTest.c:161: xError = pdTRUE;
      0009A3 7E 01            [12] 1497 	mov	r6,#0x01
                           00015A  1498 	C$ParTest.c$163$2_0$96 ==.
                                   1499 ;	ParTest/ParTest.c:163: }
      0009A5                       1500 00110$:
                           00015A  1501 	C$ParTest.c$165$2_0$96 ==.
                                   1502 ;	ParTest/ParTest.c:165: if( xError != pdTRUE )
      0009A5 BE 01 03         [24] 1503 	cjne	r6,#0x01,00133$
      0009A8 02 09 C4         [24] 1504 	ljmp	00115$
      0009AB                       1505 00133$:
                           000160  1506 	C$ParTest.c$167$3_0$98 ==.
                                   1507 ;	ParTest/ParTest.c:167: if( P1 & ucBit )
      0009AB 90 00 01         [24] 1508 	mov	dptr,#_ucBit
      0009AE E0               [24] 1509 	movx	a,@dptr
      0009AF FF               [12] 1510 	mov	r7,a
      0009B0 EF               [12] 1511 	mov	a,r7
      0009B1 55 90            [12] 1512 	anl	a,_P1
      0009B3 70 03            [24] 1513 	jnz	00134$
      0009B5 02 09 C1         [24] 1514 	ljmp	00112$
      0009B8                       1515 00134$:
                           00016D  1516 	C$ParTest.c$169$4_0$99 ==.
                                   1517 ;	ParTest/ParTest.c:169: P1 &= ~ucBit;
      0009B8 EF               [12] 1518 	mov	a,r7
      0009B9 F4               [12] 1519 	cpl	a
      0009BA FE               [12] 1520 	mov	r6,a
      0009BB EE               [12] 1521 	mov	a,r6
      0009BC 52 90            [12] 1522 	anl	_P1,a
      0009BE 02 09 C4         [24] 1523 	ljmp	00115$
      0009C1                       1524 00112$:
                           000176  1525 	C$ParTest.c$173$4_0$100 ==.
                                   1526 ;	ParTest/ParTest.c:173: P1 |= ucBit;
      0009C1 EF               [12] 1527 	mov	a,r7
      0009C2 42 90            [12] 1528 	orl	_P1,a
      0009C4                       1529 00115$:
                           000179  1530 	C$ParTest.c$177$1_0$95 ==.
                                   1531 ;	ParTest/ParTest.c:177: xTaskResumeAll();
      0009C4 12 24 EF         [24] 1532 	lcall	_xTaskResumeAll
      0009C7                       1533 00116$:
                           00017C  1534 	C$ParTest.c$178$1_0$95 ==.
                                   1535 ;	ParTest/ParTest.c:178: }
                           00017C  1536 	C$ParTest.c$178$1_0$95 ==.
                           00017C  1537 	XG$vParTestToggleLED$0$0 ==.
      0009C7 22               [24] 1538 	ret
                                   1539 	.area CSEG    (CODE)
                                   1540 	.area CONST   (CODE)
                                   1541 	.area XINIT   (CODE)
                                   1542 	.area CABS    (ABS,CODE)
