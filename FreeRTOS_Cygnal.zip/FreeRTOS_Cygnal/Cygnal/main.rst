                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.0 #11528 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module main
                                      6 	.optsdcc -mmcs51 --model-large
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main
                                     12 	.globl _xAreSemaphoreTasksStillRunning
                                     13 	.globl _vStartSemaphoreTasks
                                     14 	.globl _xAreComTestTasksStillRunning
                                     15 	.globl _vAltStartComTestTasks
                                     16 	.globl _xArePollingQueuesStillRunning
                                     17 	.globl _vStartPolledQueueTasks
                                     18 	.globl _xAreIntegerMathsTaskStillRunning
                                     19 	.globl _vStartIntegerMathTasks
                                     20 	.globl _vStartLEDFlashTasks
                                     21 	.globl _vParTestInitialise
                                     22 	.globl _vTaskStartScheduler
                                     23 	.globl _vTaskDelay
                                     24 	.globl _xTaskCreate
                                     25 	.globl _P7_7
                                     26 	.globl _P7_6
                                     27 	.globl _P7_5
                                     28 	.globl _P7_4
                                     29 	.globl _P7_3
                                     30 	.globl _P7_2
                                     31 	.globl _P7_1
                                     32 	.globl _P7_0
                                     33 	.globl _SPIF
                                     34 	.globl _WCOL
                                     35 	.globl _MODF
                                     36 	.globl _RXOVRN
                                     37 	.globl _NSSMD1
                                     38 	.globl _NSSMD0
                                     39 	.globl _TXBMT
                                     40 	.globl _SPIEN
                                     41 	.globl _P6_7
                                     42 	.globl _P6_6
                                     43 	.globl _P6_5
                                     44 	.globl _P6_4
                                     45 	.globl _P6_3
                                     46 	.globl _P6_2
                                     47 	.globl _P6_1
                                     48 	.globl _P6_0
                                     49 	.globl _AD2EN
                                     50 	.globl _AD2TM
                                     51 	.globl _AD2INT
                                     52 	.globl _AD2BUSY
                                     53 	.globl _AD2CM2
                                     54 	.globl _AD2CM1
                                     55 	.globl _AD2CM0
                                     56 	.globl _AD2WINT
                                     57 	.globl _AD0EN
                                     58 	.globl _AD0TM
                                     59 	.globl _AD0INT
                                     60 	.globl _AD0BUSY
                                     61 	.globl _AD0CM1
                                     62 	.globl _AD0CM0
                                     63 	.globl _AD0WINT
                                     64 	.globl _AD0LJST
                                     65 	.globl _P5_7
                                     66 	.globl _P5_6
                                     67 	.globl _P5_5
                                     68 	.globl _P5_4
                                     69 	.globl _P5_3
                                     70 	.globl _P5_2
                                     71 	.globl _P5_1
                                     72 	.globl _P5_0
                                     73 	.globl _CF
                                     74 	.globl _CR
                                     75 	.globl _CCF5
                                     76 	.globl _CCF4
                                     77 	.globl _CCF3
                                     78 	.globl _CCF2
                                     79 	.globl _CCF1
                                     80 	.globl _CCF0
                                     81 	.globl _CY
                                     82 	.globl _AC
                                     83 	.globl _F0
                                     84 	.globl _RS1
                                     85 	.globl _RS0
                                     86 	.globl _OV
                                     87 	.globl _F1
                                     88 	.globl _P
                                     89 	.globl _P4_7
                                     90 	.globl _P4_6
                                     91 	.globl _P4_5
                                     92 	.globl _P4_4
                                     93 	.globl _P4_3
                                     94 	.globl _P4_2
                                     95 	.globl _P4_1
                                     96 	.globl _P4_0
                                     97 	.globl _TF4
                                     98 	.globl _EXF4
                                     99 	.globl _EXEN4
                                    100 	.globl _TR4
                                    101 	.globl _CT4
                                    102 	.globl _CPRL4
                                    103 	.globl _TF3
                                    104 	.globl _EXF3
                                    105 	.globl _EXEN3
                                    106 	.globl _TR3
                                    107 	.globl _CT3
                                    108 	.globl _CPRL3
                                    109 	.globl _TF2
                                    110 	.globl _EXF2
                                    111 	.globl _EXEN2
                                    112 	.globl _TR2
                                    113 	.globl _CT2
                                    114 	.globl _CPRL2
                                    115 	.globl _BUSY
                                    116 	.globl _ENSMB
                                    117 	.globl _STA
                                    118 	.globl _STO
                                    119 	.globl _SI
                                    120 	.globl _AA
                                    121 	.globl _SMBFTE
                                    122 	.globl _SMBTOE
                                    123 	.globl _PT2
                                    124 	.globl _PS
                                    125 	.globl _PT1
                                    126 	.globl _PX1
                                    127 	.globl _PT0
                                    128 	.globl _PX0
                                    129 	.globl _EA
                                    130 	.globl _ET2
                                    131 	.globl _ES
                                    132 	.globl _ES0
                                    133 	.globl _ET1
                                    134 	.globl _EX1
                                    135 	.globl _ET0
                                    136 	.globl _EX0
                                    137 	.globl _S1MODE
                                    138 	.globl _MCE1
                                    139 	.globl _REN1
                                    140 	.globl _TB81
                                    141 	.globl _RB81
                                    142 	.globl _TI1
                                    143 	.globl _RI1
                                    144 	.globl _SM00
                                    145 	.globl _SM10
                                    146 	.globl _SM20
                                    147 	.globl _REN
                                    148 	.globl _REN0
                                    149 	.globl _TB80
                                    150 	.globl _RB80
                                    151 	.globl _TI
                                    152 	.globl _TI0
                                    153 	.globl _RI
                                    154 	.globl _RI0
                                    155 	.globl _FLHBUSY
                                    156 	.globl _CP1EN
                                    157 	.globl _CP1OUT
                                    158 	.globl _CP1RIF
                                    159 	.globl _CP1FIF
                                    160 	.globl _CP1HYP1
                                    161 	.globl _CP1HYP0
                                    162 	.globl _CP1HYN1
                                    163 	.globl _CP1HYN0
                                    164 	.globl _CP0EN
                                    165 	.globl _CP0OUT
                                    166 	.globl _CP0RIF
                                    167 	.globl _CP0FIF
                                    168 	.globl _CP0HYP1
                                    169 	.globl _CP0HYP0
                                    170 	.globl _CP0HYN1
                                    171 	.globl _CP0HYN0
                                    172 	.globl _TF1
                                    173 	.globl _TR1
                                    174 	.globl _TF0
                                    175 	.globl _TR0
                                    176 	.globl _IE1
                                    177 	.globl _IT1
                                    178 	.globl _IE0
                                    179 	.globl _IT0
                                    180 	.globl _P0_7
                                    181 	.globl _P0_6
                                    182 	.globl _P0_5
                                    183 	.globl _P0_4
                                    184 	.globl _P0_3
                                    185 	.globl _P0_2
                                    186 	.globl _P0_1
                                    187 	.globl _P0_0
                                    188 	.globl _P7
                                    189 	.globl _P6
                                    190 	.globl _ADC2CN
                                    191 	.globl _XBR2
                                    192 	.globl _XBR1
                                    193 	.globl _XBR0
                                    194 	.globl _P5
                                    195 	.globl _P4
                                    196 	.globl _FLACL
                                    197 	.globl _P1MDIN
                                    198 	.globl _P3MDOUT
                                    199 	.globl _P2MDOUT
                                    200 	.globl _P1MDOUT
                                    201 	.globl _P0MDOUT
                                    202 	.globl _CCH0LC
                                    203 	.globl _CCH0TN
                                    204 	.globl _CCH0CN
                                    205 	.globl _P7MDOUT
                                    206 	.globl _P6MDOUT
                                    207 	.globl _P5MDOUT
                                    208 	.globl _P4MDOUT
                                    209 	.globl _CCH0MA
                                    210 	.globl _CLKSEL
                                    211 	.globl _SFRPGCN
                                    212 	.globl _PLL0FLT
                                    213 	.globl _PLL0MUL
                                    214 	.globl _PLL0DIV
                                    215 	.globl _OSCXCN
                                    216 	.globl _OSCICL
                                    217 	.globl _OSCICN
                                    218 	.globl _PLL0CN
                                    219 	.globl _FLSTAT
                                    220 	.globl _MAC0RNDH
                                    221 	.globl _MAC0RNDL
                                    222 	.globl _MAC0CF
                                    223 	.globl _MAC0AH
                                    224 	.globl _MAC0AL
                                    225 	.globl _MAC0STA
                                    226 	.globl _MAC0OVR
                                    227 	.globl _MAC0ACC3
                                    228 	.globl _MAC0ACC2
                                    229 	.globl _MAC0ACC1
                                    230 	.globl _MAC0ACC0
                                    231 	.globl _MAC0BH
                                    232 	.globl _MAC0BL
                                    233 	.globl _TMR4H
                                    234 	.globl _TMR4L
                                    235 	.globl _RCAP4H
                                    236 	.globl _RCAP4L
                                    237 	.globl _TMR4CF
                                    238 	.globl _TMR4CN
                                    239 	.globl _ADC2LT
                                    240 	.globl _ADC2GT
                                    241 	.globl _ADC2
                                    242 	.globl _ADC2CF
                                    243 	.globl _AMX2SL
                                    244 	.globl _AMX2CF
                                    245 	.globl _CPT1MD
                                    246 	.globl _CPT1CN
                                    247 	.globl _DAC1CN
                                    248 	.globl _DAC1H
                                    249 	.globl _DAC1L
                                    250 	.globl _TMR3H
                                    251 	.globl _TMR3L
                                    252 	.globl _RCAP3H
                                    253 	.globl _RCAP3L
                                    254 	.globl _TMR3CF
                                    255 	.globl _TMR3CN
                                    256 	.globl _SBUF1
                                    257 	.globl _SCON1
                                    258 	.globl _CPT0MD
                                    259 	.globl _CPT0CN
                                    260 	.globl _PCA0CPH1
                                    261 	.globl _PCA0CPL1
                                    262 	.globl _PCA0CPH0
                                    263 	.globl _PCA0CPL0
                                    264 	.globl _PCA0H
                                    265 	.globl _PCA0L
                                    266 	.globl _SPI0CN
                                    267 	.globl _RSTSRC
                                    268 	.globl _PCA0CPH4
                                    269 	.globl _PCA0CPL4
                                    270 	.globl _PCA0CPH3
                                    271 	.globl _PCA0CPL3
                                    272 	.globl _PCA0CPH2
                                    273 	.globl _PCA0CPL2
                                    274 	.globl _ADC0CN
                                    275 	.globl _PCA0CPH5
                                    276 	.globl _PCA0CPL5
                                    277 	.globl _PCA0CPM5
                                    278 	.globl _PCA0CPM4
                                    279 	.globl _PCA0CPM3
                                    280 	.globl _PCA0CPM2
                                    281 	.globl _PCA0CPM1
                                    282 	.globl _PCA0CPM0
                                    283 	.globl _PCA0MD
                                    284 	.globl _PCA0CN
                                    285 	.globl _DAC0CN
                                    286 	.globl _DAC0H
                                    287 	.globl _DAC0L
                                    288 	.globl _REF0CN
                                    289 	.globl _SMB0CR
                                    290 	.globl _TH2
                                    291 	.globl _TMR2H
                                    292 	.globl _TL2
                                    293 	.globl _TMR2L
                                    294 	.globl _RCAP2H
                                    295 	.globl _RCAP2L
                                    296 	.globl _TMR2CF
                                    297 	.globl _TMR2CN
                                    298 	.globl _ADC0LTH
                                    299 	.globl _ADC0LTL
                                    300 	.globl _ADC0GTH
                                    301 	.globl _ADC0GTL
                                    302 	.globl _SMB0ADR
                                    303 	.globl _SMB0DAT
                                    304 	.globl _SMB0STA
                                    305 	.globl _SMB0CN
                                    306 	.globl _ADC0H
                                    307 	.globl _ADC0L
                                    308 	.globl _ADC0CF
                                    309 	.globl _AMX0SL
                                    310 	.globl _AMX0CF
                                    311 	.globl _SADEN0
                                    312 	.globl _FLSCL
                                    313 	.globl _SADDR0
                                    314 	.globl _EMI0CF
                                    315 	.globl __XPAGE
                                    316 	.globl _EMI0CN
                                    317 	.globl _EMI0TC
                                    318 	.globl _SPI0CKR
                                    319 	.globl _SPI0DAT
                                    320 	.globl _SPI0CFG
                                    321 	.globl _SBUF
                                    322 	.globl _SBUF0
                                    323 	.globl _SCON
                                    324 	.globl _SCON0
                                    325 	.globl _SSTA0
                                    326 	.globl _PSCTL
                                    327 	.globl _CKCON
                                    328 	.globl _TH1
                                    329 	.globl _TH0
                                    330 	.globl _TL1
                                    331 	.globl _TL0
                                    332 	.globl _TMOD
                                    333 	.globl _TCON
                                    334 	.globl _WDTCN
                                    335 	.globl _EIP2
                                    336 	.globl _EIP1
                                    337 	.globl _B
                                    338 	.globl _EIE2
                                    339 	.globl _EIE1
                                    340 	.globl _ACC
                                    341 	.globl _PSW
                                    342 	.globl _IP
                                    343 	.globl _PSBANK
                                    344 	.globl _P3
                                    345 	.globl _IE
                                    346 	.globl _P2
                                    347 	.globl _P1
                                    348 	.globl _PCON
                                    349 	.globl _SFRLAST
                                    350 	.globl _SFRNEXT
                                    351 	.globl _SFRPAGE
                                    352 	.globl _DPH
                                    353 	.globl _DPL
                                    354 	.globl _SP
                                    355 	.globl _P0
                                    356 ;--------------------------------------------------------
                                    357 ; special function registers
                                    358 ;--------------------------------------------------------
                                    359 	.area RSEG    (ABS,DATA)
      000000                        360 	.org 0x0000
                           000080   361 G$P0$0_0$0 == 0x0080
                           000080   362 _P0	=	0x0080
                           000081   363 G$SP$0_0$0 == 0x0081
                           000081   364 _SP	=	0x0081
                           000082   365 G$DPL$0_0$0 == 0x0082
                           000082   366 _DPL	=	0x0082
                           000083   367 G$DPH$0_0$0 == 0x0083
                           000083   368 _DPH	=	0x0083
                           000084   369 G$SFRPAGE$0_0$0 == 0x0084
                           000084   370 _SFRPAGE	=	0x0084
                           000085   371 G$SFRNEXT$0_0$0 == 0x0085
                           000085   372 _SFRNEXT	=	0x0085
                           000086   373 G$SFRLAST$0_0$0 == 0x0086
                           000086   374 _SFRLAST	=	0x0086
                           000087   375 G$PCON$0_0$0 == 0x0087
                           000087   376 _PCON	=	0x0087
                           000090   377 G$P1$0_0$0 == 0x0090
                           000090   378 _P1	=	0x0090
                           0000A0   379 G$P2$0_0$0 == 0x00a0
                           0000A0   380 _P2	=	0x00a0
                           0000A8   381 G$IE$0_0$0 == 0x00a8
                           0000A8   382 _IE	=	0x00a8
                           0000B0   383 G$P3$0_0$0 == 0x00b0
                           0000B0   384 _P3	=	0x00b0
                           0000B1   385 G$PSBANK$0_0$0 == 0x00b1
                           0000B1   386 _PSBANK	=	0x00b1
                           0000B8   387 G$IP$0_0$0 == 0x00b8
                           0000B8   388 _IP	=	0x00b8
                           0000D0   389 G$PSW$0_0$0 == 0x00d0
                           0000D0   390 _PSW	=	0x00d0
                           0000E0   391 G$ACC$0_0$0 == 0x00e0
                           0000E0   392 _ACC	=	0x00e0
                           0000E6   393 G$EIE1$0_0$0 == 0x00e6
                           0000E6   394 _EIE1	=	0x00e6
                           0000E7   395 G$EIE2$0_0$0 == 0x00e7
                           0000E7   396 _EIE2	=	0x00e7
                           0000F0   397 G$B$0_0$0 == 0x00f0
                           0000F0   398 _B	=	0x00f0
                           0000F6   399 G$EIP1$0_0$0 == 0x00f6
                           0000F6   400 _EIP1	=	0x00f6
                           0000F7   401 G$EIP2$0_0$0 == 0x00f7
                           0000F7   402 _EIP2	=	0x00f7
                           0000FF   403 G$WDTCN$0_0$0 == 0x00ff
                           0000FF   404 _WDTCN	=	0x00ff
                           000088   405 G$TCON$0_0$0 == 0x0088
                           000088   406 _TCON	=	0x0088
                           000089   407 G$TMOD$0_0$0 == 0x0089
                           000089   408 _TMOD	=	0x0089
                           00008A   409 G$TL0$0_0$0 == 0x008a
                           00008A   410 _TL0	=	0x008a
                           00008B   411 G$TL1$0_0$0 == 0x008b
                           00008B   412 _TL1	=	0x008b
                           00008C   413 G$TH0$0_0$0 == 0x008c
                           00008C   414 _TH0	=	0x008c
                           00008D   415 G$TH1$0_0$0 == 0x008d
                           00008D   416 _TH1	=	0x008d
                           00008E   417 G$CKCON$0_0$0 == 0x008e
                           00008E   418 _CKCON	=	0x008e
                           00008F   419 G$PSCTL$0_0$0 == 0x008f
                           00008F   420 _PSCTL	=	0x008f
                           000091   421 G$SSTA0$0_0$0 == 0x0091
                           000091   422 _SSTA0	=	0x0091
                           000098   423 G$SCON0$0_0$0 == 0x0098
                           000098   424 _SCON0	=	0x0098
                           000098   425 G$SCON$0_0$0 == 0x0098
                           000098   426 _SCON	=	0x0098
                           000099   427 G$SBUF0$0_0$0 == 0x0099
                           000099   428 _SBUF0	=	0x0099
                           000099   429 G$SBUF$0_0$0 == 0x0099
                           000099   430 _SBUF	=	0x0099
                           00009A   431 G$SPI0CFG$0_0$0 == 0x009a
                           00009A   432 _SPI0CFG	=	0x009a
                           00009B   433 G$SPI0DAT$0_0$0 == 0x009b
                           00009B   434 _SPI0DAT	=	0x009b
                           00009D   435 G$SPI0CKR$0_0$0 == 0x009d
                           00009D   436 _SPI0CKR	=	0x009d
                           0000A1   437 G$EMI0TC$0_0$0 == 0x00a1
                           0000A1   438 _EMI0TC	=	0x00a1
                           0000A2   439 G$EMI0CN$0_0$0 == 0x00a2
                           0000A2   440 _EMI0CN	=	0x00a2
                           0000A2   441 G$_XPAGE$0_0$0 == 0x00a2
                           0000A2   442 __XPAGE	=	0x00a2
                           0000A3   443 G$EMI0CF$0_0$0 == 0x00a3
                           0000A3   444 _EMI0CF	=	0x00a3
                           0000A9   445 G$SADDR0$0_0$0 == 0x00a9
                           0000A9   446 _SADDR0	=	0x00a9
                           0000B7   447 G$FLSCL$0_0$0 == 0x00b7
                           0000B7   448 _FLSCL	=	0x00b7
                           0000B9   449 G$SADEN0$0_0$0 == 0x00b9
                           0000B9   450 _SADEN0	=	0x00b9
                           0000BA   451 G$AMX0CF$0_0$0 == 0x00ba
                           0000BA   452 _AMX0CF	=	0x00ba
                           0000BB   453 G$AMX0SL$0_0$0 == 0x00bb
                           0000BB   454 _AMX0SL	=	0x00bb
                           0000BC   455 G$ADC0CF$0_0$0 == 0x00bc
                           0000BC   456 _ADC0CF	=	0x00bc
                           0000BE   457 G$ADC0L$0_0$0 == 0x00be
                           0000BE   458 _ADC0L	=	0x00be
                           0000BF   459 G$ADC0H$0_0$0 == 0x00bf
                           0000BF   460 _ADC0H	=	0x00bf
                           0000C0   461 G$SMB0CN$0_0$0 == 0x00c0
                           0000C0   462 _SMB0CN	=	0x00c0
                           0000C1   463 G$SMB0STA$0_0$0 == 0x00c1
                           0000C1   464 _SMB0STA	=	0x00c1
                           0000C2   465 G$SMB0DAT$0_0$0 == 0x00c2
                           0000C2   466 _SMB0DAT	=	0x00c2
                           0000C3   467 G$SMB0ADR$0_0$0 == 0x00c3
                           0000C3   468 _SMB0ADR	=	0x00c3
                           0000C4   469 G$ADC0GTL$0_0$0 == 0x00c4
                           0000C4   470 _ADC0GTL	=	0x00c4
                           0000C5   471 G$ADC0GTH$0_0$0 == 0x00c5
                           0000C5   472 _ADC0GTH	=	0x00c5
                           0000C6   473 G$ADC0LTL$0_0$0 == 0x00c6
                           0000C6   474 _ADC0LTL	=	0x00c6
                           0000C7   475 G$ADC0LTH$0_0$0 == 0x00c7
                           0000C7   476 _ADC0LTH	=	0x00c7
                           0000C8   477 G$TMR2CN$0_0$0 == 0x00c8
                           0000C8   478 _TMR2CN	=	0x00c8
                           0000C9   479 G$TMR2CF$0_0$0 == 0x00c9
                           0000C9   480 _TMR2CF	=	0x00c9
                           0000CA   481 G$RCAP2L$0_0$0 == 0x00ca
                           0000CA   482 _RCAP2L	=	0x00ca
                           0000CB   483 G$RCAP2H$0_0$0 == 0x00cb
                           0000CB   484 _RCAP2H	=	0x00cb
                           0000CC   485 G$TMR2L$0_0$0 == 0x00cc
                           0000CC   486 _TMR2L	=	0x00cc
                           0000CC   487 G$TL2$0_0$0 == 0x00cc
                           0000CC   488 _TL2	=	0x00cc
                           0000CD   489 G$TMR2H$0_0$0 == 0x00cd
                           0000CD   490 _TMR2H	=	0x00cd
                           0000CD   491 G$TH2$0_0$0 == 0x00cd
                           0000CD   492 _TH2	=	0x00cd
                           0000CF   493 G$SMB0CR$0_0$0 == 0x00cf
                           0000CF   494 _SMB0CR	=	0x00cf
                           0000D1   495 G$REF0CN$0_0$0 == 0x00d1
                           0000D1   496 _REF0CN	=	0x00d1
                           0000D2   497 G$DAC0L$0_0$0 == 0x00d2
                           0000D2   498 _DAC0L	=	0x00d2
                           0000D3   499 G$DAC0H$0_0$0 == 0x00d3
                           0000D3   500 _DAC0H	=	0x00d3
                           0000D4   501 G$DAC0CN$0_0$0 == 0x00d4
                           0000D4   502 _DAC0CN	=	0x00d4
                           0000D8   503 G$PCA0CN$0_0$0 == 0x00d8
                           0000D8   504 _PCA0CN	=	0x00d8
                           0000D9   505 G$PCA0MD$0_0$0 == 0x00d9
                           0000D9   506 _PCA0MD	=	0x00d9
                           0000DA   507 G$PCA0CPM0$0_0$0 == 0x00da
                           0000DA   508 _PCA0CPM0	=	0x00da
                           0000DB   509 G$PCA0CPM1$0_0$0 == 0x00db
                           0000DB   510 _PCA0CPM1	=	0x00db
                           0000DC   511 G$PCA0CPM2$0_0$0 == 0x00dc
                           0000DC   512 _PCA0CPM2	=	0x00dc
                           0000DD   513 G$PCA0CPM3$0_0$0 == 0x00dd
                           0000DD   514 _PCA0CPM3	=	0x00dd
                           0000DE   515 G$PCA0CPM4$0_0$0 == 0x00de
                           0000DE   516 _PCA0CPM4	=	0x00de
                           0000DF   517 G$PCA0CPM5$0_0$0 == 0x00df
                           0000DF   518 _PCA0CPM5	=	0x00df
                           0000E1   519 G$PCA0CPL5$0_0$0 == 0x00e1
                           0000E1   520 _PCA0CPL5	=	0x00e1
                           0000E2   521 G$PCA0CPH5$0_0$0 == 0x00e2
                           0000E2   522 _PCA0CPH5	=	0x00e2
                           0000E8   523 G$ADC0CN$0_0$0 == 0x00e8
                           0000E8   524 _ADC0CN	=	0x00e8
                           0000E9   525 G$PCA0CPL2$0_0$0 == 0x00e9
                           0000E9   526 _PCA0CPL2	=	0x00e9
                           0000EA   527 G$PCA0CPH2$0_0$0 == 0x00ea
                           0000EA   528 _PCA0CPH2	=	0x00ea
                           0000EB   529 G$PCA0CPL3$0_0$0 == 0x00eb
                           0000EB   530 _PCA0CPL3	=	0x00eb
                           0000EC   531 G$PCA0CPH3$0_0$0 == 0x00ec
                           0000EC   532 _PCA0CPH3	=	0x00ec
                           0000ED   533 G$PCA0CPL4$0_0$0 == 0x00ed
                           0000ED   534 _PCA0CPL4	=	0x00ed
                           0000EE   535 G$PCA0CPH4$0_0$0 == 0x00ee
                           0000EE   536 _PCA0CPH4	=	0x00ee
                           0000EF   537 G$RSTSRC$0_0$0 == 0x00ef
                           0000EF   538 _RSTSRC	=	0x00ef
                           0000F8   539 G$SPI0CN$0_0$0 == 0x00f8
                           0000F8   540 _SPI0CN	=	0x00f8
                           0000F9   541 G$PCA0L$0_0$0 == 0x00f9
                           0000F9   542 _PCA0L	=	0x00f9
                           0000FA   543 G$PCA0H$0_0$0 == 0x00fa
                           0000FA   544 _PCA0H	=	0x00fa
                           0000FB   545 G$PCA0CPL0$0_0$0 == 0x00fb
                           0000FB   546 _PCA0CPL0	=	0x00fb
                           0000FC   547 G$PCA0CPH0$0_0$0 == 0x00fc
                           0000FC   548 _PCA0CPH0	=	0x00fc
                           0000FD   549 G$PCA0CPL1$0_0$0 == 0x00fd
                           0000FD   550 _PCA0CPL1	=	0x00fd
                           0000FE   551 G$PCA0CPH1$0_0$0 == 0x00fe
                           0000FE   552 _PCA0CPH1	=	0x00fe
                           000088   553 G$CPT0CN$0_0$0 == 0x0088
                           000088   554 _CPT0CN	=	0x0088
                           000089   555 G$CPT0MD$0_0$0 == 0x0089
                           000089   556 _CPT0MD	=	0x0089
                           000098   557 G$SCON1$0_0$0 == 0x0098
                           000098   558 _SCON1	=	0x0098
                           000099   559 G$SBUF1$0_0$0 == 0x0099
                           000099   560 _SBUF1	=	0x0099
                           0000C8   561 G$TMR3CN$0_0$0 == 0x00c8
                           0000C8   562 _TMR3CN	=	0x00c8
                           0000C9   563 G$TMR3CF$0_0$0 == 0x00c9
                           0000C9   564 _TMR3CF	=	0x00c9
                           0000CA   565 G$RCAP3L$0_0$0 == 0x00ca
                           0000CA   566 _RCAP3L	=	0x00ca
                           0000CB   567 G$RCAP3H$0_0$0 == 0x00cb
                           0000CB   568 _RCAP3H	=	0x00cb
                           0000CC   569 G$TMR3L$0_0$0 == 0x00cc
                           0000CC   570 _TMR3L	=	0x00cc
                           0000CD   571 G$TMR3H$0_0$0 == 0x00cd
                           0000CD   572 _TMR3H	=	0x00cd
                           0000D2   573 G$DAC1L$0_0$0 == 0x00d2
                           0000D2   574 _DAC1L	=	0x00d2
                           0000D3   575 G$DAC1H$0_0$0 == 0x00d3
                           0000D3   576 _DAC1H	=	0x00d3
                           0000D4   577 G$DAC1CN$0_0$0 == 0x00d4
                           0000D4   578 _DAC1CN	=	0x00d4
                           000088   579 G$CPT1CN$0_0$0 == 0x0088
                           000088   580 _CPT1CN	=	0x0088
                           000089   581 G$CPT1MD$0_0$0 == 0x0089
                           000089   582 _CPT1MD	=	0x0089
                           0000BA   583 G$AMX2CF$0_0$0 == 0x00ba
                           0000BA   584 _AMX2CF	=	0x00ba
                           0000BB   585 G$AMX2SL$0_0$0 == 0x00bb
                           0000BB   586 _AMX2SL	=	0x00bb
                           0000BC   587 G$ADC2CF$0_0$0 == 0x00bc
                           0000BC   588 _ADC2CF	=	0x00bc
                           0000BE   589 G$ADC2$0_0$0 == 0x00be
                           0000BE   590 _ADC2	=	0x00be
                           0000C4   591 G$ADC2GT$0_0$0 == 0x00c4
                           0000C4   592 _ADC2GT	=	0x00c4
                           0000C6   593 G$ADC2LT$0_0$0 == 0x00c6
                           0000C6   594 _ADC2LT	=	0x00c6
                           0000C8   595 G$TMR4CN$0_0$0 == 0x00c8
                           0000C8   596 _TMR4CN	=	0x00c8
                           0000C9   597 G$TMR4CF$0_0$0 == 0x00c9
                           0000C9   598 _TMR4CF	=	0x00c9
                           0000CA   599 G$RCAP4L$0_0$0 == 0x00ca
                           0000CA   600 _RCAP4L	=	0x00ca
                           0000CB   601 G$RCAP4H$0_0$0 == 0x00cb
                           0000CB   602 _RCAP4H	=	0x00cb
                           0000CC   603 G$TMR4L$0_0$0 == 0x00cc
                           0000CC   604 _TMR4L	=	0x00cc
                           0000CD   605 G$TMR4H$0_0$0 == 0x00cd
                           0000CD   606 _TMR4H	=	0x00cd
                           000091   607 G$MAC0BL$0_0$0 == 0x0091
                           000091   608 _MAC0BL	=	0x0091
                           000092   609 G$MAC0BH$0_0$0 == 0x0092
                           000092   610 _MAC0BH	=	0x0092
                           000093   611 G$MAC0ACC0$0_0$0 == 0x0093
                           000093   612 _MAC0ACC0	=	0x0093
                           000094   613 G$MAC0ACC1$0_0$0 == 0x0094
                           000094   614 _MAC0ACC1	=	0x0094
                           000095   615 G$MAC0ACC2$0_0$0 == 0x0095
                           000095   616 _MAC0ACC2	=	0x0095
                           000096   617 G$MAC0ACC3$0_0$0 == 0x0096
                           000096   618 _MAC0ACC3	=	0x0096
                           000097   619 G$MAC0OVR$0_0$0 == 0x0097
                           000097   620 _MAC0OVR	=	0x0097
                           0000C0   621 G$MAC0STA$0_0$0 == 0x00c0
                           0000C0   622 _MAC0STA	=	0x00c0
                           0000C1   623 G$MAC0AL$0_0$0 == 0x00c1
                           0000C1   624 _MAC0AL	=	0x00c1
                           0000C2   625 G$MAC0AH$0_0$0 == 0x00c2
                           0000C2   626 _MAC0AH	=	0x00c2
                           0000C3   627 G$MAC0CF$0_0$0 == 0x00c3
                           0000C3   628 _MAC0CF	=	0x00c3
                           0000CE   629 G$MAC0RNDL$0_0$0 == 0x00ce
                           0000CE   630 _MAC0RNDL	=	0x00ce
                           0000CF   631 G$MAC0RNDH$0_0$0 == 0x00cf
                           0000CF   632 _MAC0RNDH	=	0x00cf
                           000088   633 G$FLSTAT$0_0$0 == 0x0088
                           000088   634 _FLSTAT	=	0x0088
                           000089   635 G$PLL0CN$0_0$0 == 0x0089
                           000089   636 _PLL0CN	=	0x0089
                           00008A   637 G$OSCICN$0_0$0 == 0x008a
                           00008A   638 _OSCICN	=	0x008a
                           00008B   639 G$OSCICL$0_0$0 == 0x008b
                           00008B   640 _OSCICL	=	0x008b
                           00008C   641 G$OSCXCN$0_0$0 == 0x008c
                           00008C   642 _OSCXCN	=	0x008c
                           00008D   643 G$PLL0DIV$0_0$0 == 0x008d
                           00008D   644 _PLL0DIV	=	0x008d
                           00008E   645 G$PLL0MUL$0_0$0 == 0x008e
                           00008E   646 _PLL0MUL	=	0x008e
                           00008F   647 G$PLL0FLT$0_0$0 == 0x008f
                           00008F   648 _PLL0FLT	=	0x008f
                           000096   649 G$SFRPGCN$0_0$0 == 0x0096
                           000096   650 _SFRPGCN	=	0x0096
                           000097   651 G$CLKSEL$0_0$0 == 0x0097
                           000097   652 _CLKSEL	=	0x0097
                           00009A   653 G$CCH0MA$0_0$0 == 0x009a
                           00009A   654 _CCH0MA	=	0x009a
                           00009C   655 G$P4MDOUT$0_0$0 == 0x009c
                           00009C   656 _P4MDOUT	=	0x009c
                           00009D   657 G$P5MDOUT$0_0$0 == 0x009d
                           00009D   658 _P5MDOUT	=	0x009d
                           00009E   659 G$P6MDOUT$0_0$0 == 0x009e
                           00009E   660 _P6MDOUT	=	0x009e
                           00009F   661 G$P7MDOUT$0_0$0 == 0x009f
                           00009F   662 _P7MDOUT	=	0x009f
                           0000A1   663 G$CCH0CN$0_0$0 == 0x00a1
                           0000A1   664 _CCH0CN	=	0x00a1
                           0000A2   665 G$CCH0TN$0_0$0 == 0x00a2
                           0000A2   666 _CCH0TN	=	0x00a2
                           0000A3   667 G$CCH0LC$0_0$0 == 0x00a3
                           0000A3   668 _CCH0LC	=	0x00a3
                           0000A4   669 G$P0MDOUT$0_0$0 == 0x00a4
                           0000A4   670 _P0MDOUT	=	0x00a4
                           0000A5   671 G$P1MDOUT$0_0$0 == 0x00a5
                           0000A5   672 _P1MDOUT	=	0x00a5
                           0000A6   673 G$P2MDOUT$0_0$0 == 0x00a6
                           0000A6   674 _P2MDOUT	=	0x00a6
                           0000A7   675 G$P3MDOUT$0_0$0 == 0x00a7
                           0000A7   676 _P3MDOUT	=	0x00a7
                           0000AD   677 G$P1MDIN$0_0$0 == 0x00ad
                           0000AD   678 _P1MDIN	=	0x00ad
                           0000B7   679 G$FLACL$0_0$0 == 0x00b7
                           0000B7   680 _FLACL	=	0x00b7
                           0000C8   681 G$P4$0_0$0 == 0x00c8
                           0000C8   682 _P4	=	0x00c8
                           0000D8   683 G$P5$0_0$0 == 0x00d8
                           0000D8   684 _P5	=	0x00d8
                           0000E1   685 G$XBR0$0_0$0 == 0x00e1
                           0000E1   686 _XBR0	=	0x00e1
                           0000E2   687 G$XBR1$0_0$0 == 0x00e2
                           0000E2   688 _XBR1	=	0x00e2
                           0000E3   689 G$XBR2$0_0$0 == 0x00e3
                           0000E3   690 _XBR2	=	0x00e3
                           0000E8   691 G$ADC2CN$0_0$0 == 0x00e8
                           0000E8   692 _ADC2CN	=	0x00e8
                           0000E8   693 G$P6$0_0$0 == 0x00e8
                           0000E8   694 _P6	=	0x00e8
                           0000F8   695 G$P7$0_0$0 == 0x00f8
                           0000F8   696 _P7	=	0x00f8
                                    697 ;--------------------------------------------------------
                                    698 ; special function bits
                                    699 ;--------------------------------------------------------
                                    700 	.area RSEG    (ABS,DATA)
      000000                        701 	.org 0x0000
                           000080   702 G$P0_0$0_0$0 == 0x0080
                           000080   703 _P0_0	=	0x0080
                           000081   704 G$P0_1$0_0$0 == 0x0081
                           000081   705 _P0_1	=	0x0081
                           000082   706 G$P0_2$0_0$0 == 0x0082
                           000082   707 _P0_2	=	0x0082
                           000083   708 G$P0_3$0_0$0 == 0x0083
                           000083   709 _P0_3	=	0x0083
                           000084   710 G$P0_4$0_0$0 == 0x0084
                           000084   711 _P0_4	=	0x0084
                           000085   712 G$P0_5$0_0$0 == 0x0085
                           000085   713 _P0_5	=	0x0085
                           000086   714 G$P0_6$0_0$0 == 0x0086
                           000086   715 _P0_6	=	0x0086
                           000087   716 G$P0_7$0_0$0 == 0x0087
                           000087   717 _P0_7	=	0x0087
                           000088   718 G$IT0$0_0$0 == 0x0088
                           000088   719 _IT0	=	0x0088
                           000089   720 G$IE0$0_0$0 == 0x0089
                           000089   721 _IE0	=	0x0089
                           00008A   722 G$IT1$0_0$0 == 0x008a
                           00008A   723 _IT1	=	0x008a
                           00008B   724 G$IE1$0_0$0 == 0x008b
                           00008B   725 _IE1	=	0x008b
                           00008C   726 G$TR0$0_0$0 == 0x008c
                           00008C   727 _TR0	=	0x008c
                           00008D   728 G$TF0$0_0$0 == 0x008d
                           00008D   729 _TF0	=	0x008d
                           00008E   730 G$TR1$0_0$0 == 0x008e
                           00008E   731 _TR1	=	0x008e
                           00008F   732 G$TF1$0_0$0 == 0x008f
                           00008F   733 _TF1	=	0x008f
                           000088   734 G$CP0HYN0$0_0$0 == 0x0088
                           000088   735 _CP0HYN0	=	0x0088
                           000089   736 G$CP0HYN1$0_0$0 == 0x0089
                           000089   737 _CP0HYN1	=	0x0089
                           00008A   738 G$CP0HYP0$0_0$0 == 0x008a
                           00008A   739 _CP0HYP0	=	0x008a
                           00008B   740 G$CP0HYP1$0_0$0 == 0x008b
                           00008B   741 _CP0HYP1	=	0x008b
                           00008C   742 G$CP0FIF$0_0$0 == 0x008c
                           00008C   743 _CP0FIF	=	0x008c
                           00008D   744 G$CP0RIF$0_0$0 == 0x008d
                           00008D   745 _CP0RIF	=	0x008d
                           00008E   746 G$CP0OUT$0_0$0 == 0x008e
                           00008E   747 _CP0OUT	=	0x008e
                           00008F   748 G$CP0EN$0_0$0 == 0x008f
                           00008F   749 _CP0EN	=	0x008f
                           000088   750 G$CP1HYN0$0_0$0 == 0x0088
                           000088   751 _CP1HYN0	=	0x0088
                           000089   752 G$CP1HYN1$0_0$0 == 0x0089
                           000089   753 _CP1HYN1	=	0x0089
                           00008A   754 G$CP1HYP0$0_0$0 == 0x008a
                           00008A   755 _CP1HYP0	=	0x008a
                           00008B   756 G$CP1HYP1$0_0$0 == 0x008b
                           00008B   757 _CP1HYP1	=	0x008b
                           00008C   758 G$CP1FIF$0_0$0 == 0x008c
                           00008C   759 _CP1FIF	=	0x008c
                           00008D   760 G$CP1RIF$0_0$0 == 0x008d
                           00008D   761 _CP1RIF	=	0x008d
                           00008E   762 G$CP1OUT$0_0$0 == 0x008e
                           00008E   763 _CP1OUT	=	0x008e
                           00008F   764 G$CP1EN$0_0$0 == 0x008f
                           00008F   765 _CP1EN	=	0x008f
                           000088   766 G$FLHBUSY$0_0$0 == 0x0088
                           000088   767 _FLHBUSY	=	0x0088
                           000098   768 G$RI0$0_0$0 == 0x0098
                           000098   769 _RI0	=	0x0098
                           000098   770 G$RI$0_0$0 == 0x0098
                           000098   771 _RI	=	0x0098
                           000099   772 G$TI0$0_0$0 == 0x0099
                           000099   773 _TI0	=	0x0099
                           000099   774 G$TI$0_0$0 == 0x0099
                           000099   775 _TI	=	0x0099
                           00009A   776 G$RB80$0_0$0 == 0x009a
                           00009A   777 _RB80	=	0x009a
                           00009B   778 G$TB80$0_0$0 == 0x009b
                           00009B   779 _TB80	=	0x009b
                           00009C   780 G$REN0$0_0$0 == 0x009c
                           00009C   781 _REN0	=	0x009c
                           00009C   782 G$REN$0_0$0 == 0x009c
                           00009C   783 _REN	=	0x009c
                           00009D   784 G$SM20$0_0$0 == 0x009d
                           00009D   785 _SM20	=	0x009d
                           00009E   786 G$SM10$0_0$0 == 0x009e
                           00009E   787 _SM10	=	0x009e
                           00009F   788 G$SM00$0_0$0 == 0x009f
                           00009F   789 _SM00	=	0x009f
                           000098   790 G$RI1$0_0$0 == 0x0098
                           000098   791 _RI1	=	0x0098
                           000099   792 G$TI1$0_0$0 == 0x0099
                           000099   793 _TI1	=	0x0099
                           00009A   794 G$RB81$0_0$0 == 0x009a
                           00009A   795 _RB81	=	0x009a
                           00009B   796 G$TB81$0_0$0 == 0x009b
                           00009B   797 _TB81	=	0x009b
                           00009C   798 G$REN1$0_0$0 == 0x009c
                           00009C   799 _REN1	=	0x009c
                           00009D   800 G$MCE1$0_0$0 == 0x009d
                           00009D   801 _MCE1	=	0x009d
                           00009F   802 G$S1MODE$0_0$0 == 0x009f
                           00009F   803 _S1MODE	=	0x009f
                           0000A8   804 G$EX0$0_0$0 == 0x00a8
                           0000A8   805 _EX0	=	0x00a8
                           0000A9   806 G$ET0$0_0$0 == 0x00a9
                           0000A9   807 _ET0	=	0x00a9
                           0000AA   808 G$EX1$0_0$0 == 0x00aa
                           0000AA   809 _EX1	=	0x00aa
                           0000AB   810 G$ET1$0_0$0 == 0x00ab
                           0000AB   811 _ET1	=	0x00ab
                           0000AC   812 G$ES0$0_0$0 == 0x00ac
                           0000AC   813 _ES0	=	0x00ac
                           0000AC   814 G$ES$0_0$0 == 0x00ac
                           0000AC   815 _ES	=	0x00ac
                           0000AD   816 G$ET2$0_0$0 == 0x00ad
                           0000AD   817 _ET2	=	0x00ad
                           0000AF   818 G$EA$0_0$0 == 0x00af
                           0000AF   819 _EA	=	0x00af
                           0000B8   820 G$PX0$0_0$0 == 0x00b8
                           0000B8   821 _PX0	=	0x00b8
                           0000B9   822 G$PT0$0_0$0 == 0x00b9
                           0000B9   823 _PT0	=	0x00b9
                           0000BA   824 G$PX1$0_0$0 == 0x00ba
                           0000BA   825 _PX1	=	0x00ba
                           0000BB   826 G$PT1$0_0$0 == 0x00bb
                           0000BB   827 _PT1	=	0x00bb
                           0000BC   828 G$PS$0_0$0 == 0x00bc
                           0000BC   829 _PS	=	0x00bc
                           0000BD   830 G$PT2$0_0$0 == 0x00bd
                           0000BD   831 _PT2	=	0x00bd
                           0000C0   832 G$SMBTOE$0_0$0 == 0x00c0
                           0000C0   833 _SMBTOE	=	0x00c0
                           0000C1   834 G$SMBFTE$0_0$0 == 0x00c1
                           0000C1   835 _SMBFTE	=	0x00c1
                           0000C2   836 G$AA$0_0$0 == 0x00c2
                           0000C2   837 _AA	=	0x00c2
                           0000C3   838 G$SI$0_0$0 == 0x00c3
                           0000C3   839 _SI	=	0x00c3
                           0000C4   840 G$STO$0_0$0 == 0x00c4
                           0000C4   841 _STO	=	0x00c4
                           0000C5   842 G$STA$0_0$0 == 0x00c5
                           0000C5   843 _STA	=	0x00c5
                           0000C6   844 G$ENSMB$0_0$0 == 0x00c6
                           0000C6   845 _ENSMB	=	0x00c6
                           0000C7   846 G$BUSY$0_0$0 == 0x00c7
                           0000C7   847 _BUSY	=	0x00c7
                           0000C8   848 G$CPRL2$0_0$0 == 0x00c8
                           0000C8   849 _CPRL2	=	0x00c8
                           0000C9   850 G$CT2$0_0$0 == 0x00c9
                           0000C9   851 _CT2	=	0x00c9
                           0000CA   852 G$TR2$0_0$0 == 0x00ca
                           0000CA   853 _TR2	=	0x00ca
                           0000CB   854 G$EXEN2$0_0$0 == 0x00cb
                           0000CB   855 _EXEN2	=	0x00cb
                           0000CE   856 G$EXF2$0_0$0 == 0x00ce
                           0000CE   857 _EXF2	=	0x00ce
                           0000CF   858 G$TF2$0_0$0 == 0x00cf
                           0000CF   859 _TF2	=	0x00cf
                           0000C8   860 G$CPRL3$0_0$0 == 0x00c8
                           0000C8   861 _CPRL3	=	0x00c8
                           0000C9   862 G$CT3$0_0$0 == 0x00c9
                           0000C9   863 _CT3	=	0x00c9
                           0000CA   864 G$TR3$0_0$0 == 0x00ca
                           0000CA   865 _TR3	=	0x00ca
                           0000CB   866 G$EXEN3$0_0$0 == 0x00cb
                           0000CB   867 _EXEN3	=	0x00cb
                           0000CE   868 G$EXF3$0_0$0 == 0x00ce
                           0000CE   869 _EXF3	=	0x00ce
                           0000CF   870 G$TF3$0_0$0 == 0x00cf
                           0000CF   871 _TF3	=	0x00cf
                           0000C8   872 G$CPRL4$0_0$0 == 0x00c8
                           0000C8   873 _CPRL4	=	0x00c8
                           0000C9   874 G$CT4$0_0$0 == 0x00c9
                           0000C9   875 _CT4	=	0x00c9
                           0000CA   876 G$TR4$0_0$0 == 0x00ca
                           0000CA   877 _TR4	=	0x00ca
                           0000CB   878 G$EXEN4$0_0$0 == 0x00cb
                           0000CB   879 _EXEN4	=	0x00cb
                           0000CE   880 G$EXF4$0_0$0 == 0x00ce
                           0000CE   881 _EXF4	=	0x00ce
                           0000CF   882 G$TF4$0_0$0 == 0x00cf
                           0000CF   883 _TF4	=	0x00cf
                           0000C8   884 G$P4_0$0_0$0 == 0x00c8
                           0000C8   885 _P4_0	=	0x00c8
                           0000C9   886 G$P4_1$0_0$0 == 0x00c9
                           0000C9   887 _P4_1	=	0x00c9
                           0000CA   888 G$P4_2$0_0$0 == 0x00ca
                           0000CA   889 _P4_2	=	0x00ca
                           0000CB   890 G$P4_3$0_0$0 == 0x00cb
                           0000CB   891 _P4_3	=	0x00cb
                           0000CC   892 G$P4_4$0_0$0 == 0x00cc
                           0000CC   893 _P4_4	=	0x00cc
                           0000CD   894 G$P4_5$0_0$0 == 0x00cd
                           0000CD   895 _P4_5	=	0x00cd
                           0000CE   896 G$P4_6$0_0$0 == 0x00ce
                           0000CE   897 _P4_6	=	0x00ce
                           0000CF   898 G$P4_7$0_0$0 == 0x00cf
                           0000CF   899 _P4_7	=	0x00cf
                           0000D0   900 G$P$0_0$0 == 0x00d0
                           0000D0   901 _P	=	0x00d0
                           0000D1   902 G$F1$0_0$0 == 0x00d1
                           0000D1   903 _F1	=	0x00d1
                           0000D2   904 G$OV$0_0$0 == 0x00d2
                           0000D2   905 _OV	=	0x00d2
                           0000D3   906 G$RS0$0_0$0 == 0x00d3
                           0000D3   907 _RS0	=	0x00d3
                           0000D4   908 G$RS1$0_0$0 == 0x00d4
                           0000D4   909 _RS1	=	0x00d4
                           0000D5   910 G$F0$0_0$0 == 0x00d5
                           0000D5   911 _F0	=	0x00d5
                           0000D6   912 G$AC$0_0$0 == 0x00d6
                           0000D6   913 _AC	=	0x00d6
                           0000D7   914 G$CY$0_0$0 == 0x00d7
                           0000D7   915 _CY	=	0x00d7
                           0000D8   916 G$CCF0$0_0$0 == 0x00d8
                           0000D8   917 _CCF0	=	0x00d8
                           0000D9   918 G$CCF1$0_0$0 == 0x00d9
                           0000D9   919 _CCF1	=	0x00d9
                           0000DA   920 G$CCF2$0_0$0 == 0x00da
                           0000DA   921 _CCF2	=	0x00da
                           0000DB   922 G$CCF3$0_0$0 == 0x00db
                           0000DB   923 _CCF3	=	0x00db
                           0000DC   924 G$CCF4$0_0$0 == 0x00dc
                           0000DC   925 _CCF4	=	0x00dc
                           0000DD   926 G$CCF5$0_0$0 == 0x00dd
                           0000DD   927 _CCF5	=	0x00dd
                           0000DE   928 G$CR$0_0$0 == 0x00de
                           0000DE   929 _CR	=	0x00de
                           0000DF   930 G$CF$0_0$0 == 0x00df
                           0000DF   931 _CF	=	0x00df
                           0000D8   932 G$P5_0$0_0$0 == 0x00d8
                           0000D8   933 _P5_0	=	0x00d8
                           0000D9   934 G$P5_1$0_0$0 == 0x00d9
                           0000D9   935 _P5_1	=	0x00d9
                           0000DA   936 G$P5_2$0_0$0 == 0x00da
                           0000DA   937 _P5_2	=	0x00da
                           0000DB   938 G$P5_3$0_0$0 == 0x00db
                           0000DB   939 _P5_3	=	0x00db
                           0000DC   940 G$P5_4$0_0$0 == 0x00dc
                           0000DC   941 _P5_4	=	0x00dc
                           0000DD   942 G$P5_5$0_0$0 == 0x00dd
                           0000DD   943 _P5_5	=	0x00dd
                           0000DE   944 G$P5_6$0_0$0 == 0x00de
                           0000DE   945 _P5_6	=	0x00de
                           0000DF   946 G$P5_7$0_0$0 == 0x00df
                           0000DF   947 _P5_7	=	0x00df
                           0000E8   948 G$AD0LJST$0_0$0 == 0x00e8
                           0000E8   949 _AD0LJST	=	0x00e8
                           0000E9   950 G$AD0WINT$0_0$0 == 0x00e9
                           0000E9   951 _AD0WINT	=	0x00e9
                           0000EA   952 G$AD0CM0$0_0$0 == 0x00ea
                           0000EA   953 _AD0CM0	=	0x00ea
                           0000EB   954 G$AD0CM1$0_0$0 == 0x00eb
                           0000EB   955 _AD0CM1	=	0x00eb
                           0000EC   956 G$AD0BUSY$0_0$0 == 0x00ec
                           0000EC   957 _AD0BUSY	=	0x00ec
                           0000ED   958 G$AD0INT$0_0$0 == 0x00ed
                           0000ED   959 _AD0INT	=	0x00ed
                           0000EE   960 G$AD0TM$0_0$0 == 0x00ee
                           0000EE   961 _AD0TM	=	0x00ee
                           0000EF   962 G$AD0EN$0_0$0 == 0x00ef
                           0000EF   963 _AD0EN	=	0x00ef
                           0000E8   964 G$AD2WINT$0_0$0 == 0x00e8
                           0000E8   965 _AD2WINT	=	0x00e8
                           0000E9   966 G$AD2CM0$0_0$0 == 0x00e9
                           0000E9   967 _AD2CM0	=	0x00e9
                           0000EA   968 G$AD2CM1$0_0$0 == 0x00ea
                           0000EA   969 _AD2CM1	=	0x00ea
                           0000EB   970 G$AD2CM2$0_0$0 == 0x00eb
                           0000EB   971 _AD2CM2	=	0x00eb
                           0000EC   972 G$AD2BUSY$0_0$0 == 0x00ec
                           0000EC   973 _AD2BUSY	=	0x00ec
                           0000ED   974 G$AD2INT$0_0$0 == 0x00ed
                           0000ED   975 _AD2INT	=	0x00ed
                           0000EE   976 G$AD2TM$0_0$0 == 0x00ee
                           0000EE   977 _AD2TM	=	0x00ee
                           0000EF   978 G$AD2EN$0_0$0 == 0x00ef
                           0000EF   979 _AD2EN	=	0x00ef
                           0000E8   980 G$P6_0$0_0$0 == 0x00e8
                           0000E8   981 _P6_0	=	0x00e8
                           0000E9   982 G$P6_1$0_0$0 == 0x00e9
                           0000E9   983 _P6_1	=	0x00e9
                           0000EA   984 G$P6_2$0_0$0 == 0x00ea
                           0000EA   985 _P6_2	=	0x00ea
                           0000EB   986 G$P6_3$0_0$0 == 0x00eb
                           0000EB   987 _P6_3	=	0x00eb
                           0000EC   988 G$P6_4$0_0$0 == 0x00ec
                           0000EC   989 _P6_4	=	0x00ec
                           0000ED   990 G$P6_5$0_0$0 == 0x00ed
                           0000ED   991 _P6_5	=	0x00ed
                           0000EE   992 G$P6_6$0_0$0 == 0x00ee
                           0000EE   993 _P6_6	=	0x00ee
                           0000EF   994 G$P6_7$0_0$0 == 0x00ef
                           0000EF   995 _P6_7	=	0x00ef
                           0000F8   996 G$SPIEN$0_0$0 == 0x00f8
                           0000F8   997 _SPIEN	=	0x00f8
                           0000F9   998 G$TXBMT$0_0$0 == 0x00f9
                           0000F9   999 _TXBMT	=	0x00f9
                           0000FA  1000 G$NSSMD0$0_0$0 == 0x00fa
                           0000FA  1001 _NSSMD0	=	0x00fa
                           0000FB  1002 G$NSSMD1$0_0$0 == 0x00fb
                           0000FB  1003 _NSSMD1	=	0x00fb
                           0000FC  1004 G$RXOVRN$0_0$0 == 0x00fc
                           0000FC  1005 _RXOVRN	=	0x00fc
                           0000FD  1006 G$MODF$0_0$0 == 0x00fd
                           0000FD  1007 _MODF	=	0x00fd
                           0000FE  1008 G$WCOL$0_0$0 == 0x00fe
                           0000FE  1009 _WCOL	=	0x00fe
                           0000FF  1010 G$SPIF$0_0$0 == 0x00ff
                           0000FF  1011 _SPIF	=	0x00ff
                           0000F8  1012 G$P7_0$0_0$0 == 0x00f8
                           0000F8  1013 _P7_0	=	0x00f8
                           0000F9  1014 G$P7_1$0_0$0 == 0x00f9
                           0000F9  1015 _P7_1	=	0x00f9
                           0000FA  1016 G$P7_2$0_0$0 == 0x00fa
                           0000FA  1017 _P7_2	=	0x00fa
                           0000FB  1018 G$P7_3$0_0$0 == 0x00fb
                           0000FB  1019 _P7_3	=	0x00fb
                           0000FC  1020 G$P7_4$0_0$0 == 0x00fc
                           0000FC  1021 _P7_4	=	0x00fc
                           0000FD  1022 G$P7_5$0_0$0 == 0x00fd
                           0000FD  1023 _P7_5	=	0x00fd
                           0000FE  1024 G$P7_6$0_0$0 == 0x00fe
                           0000FE  1025 _P7_6	=	0x00fe
                           0000FF  1026 G$P7_7$0_0$0 == 0x00ff
                           0000FF  1027 _P7_7	=	0x00ff
                                   1028 ;--------------------------------------------------------
                                   1029 ; overlayable register banks
                                   1030 ;--------------------------------------------------------
                                   1031 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                       1032 	.ds 8
                                   1033 ;--------------------------------------------------------
                                   1034 ; internal ram data
                                   1035 ;--------------------------------------------------------
                                   1036 	.area DSEG    (DATA)
                                   1037 ;--------------------------------------------------------
                                   1038 ; overlayable items in internal ram 
                                   1039 ;--------------------------------------------------------
                                   1040 ;--------------------------------------------------------
                                   1041 ; Stack segment in internal ram 
                                   1042 ;--------------------------------------------------------
                                   1043 	.area	SSEG
      000021                       1044 __start__stack:
      000021                       1045 	.ds	1
                                   1046 
                                   1047 ;--------------------------------------------------------
                                   1048 ; indirectly addressable internal ram data
                                   1049 ;--------------------------------------------------------
                                   1050 	.area ISEG    (DATA)
                                   1051 ;--------------------------------------------------------
                                   1052 ; absolute internal ram data
                                   1053 ;--------------------------------------------------------
                                   1054 	.area IABS    (ABS,DATA)
                                   1055 	.area IABS    (ABS,DATA)
                                   1056 ;--------------------------------------------------------
                                   1057 ; bit data
                                   1058 ;--------------------------------------------------------
                                   1059 	.area BSEG    (BIT)
                                   1060 ;--------------------------------------------------------
                                   1061 ; paged external ram data
                                   1062 ;--------------------------------------------------------
                                   1063 	.area PSEG    (PAG,XDATA)
                                   1064 ;--------------------------------------------------------
                                   1065 ; external ram data
                                   1066 ;--------------------------------------------------------
                                   1067 	.area XSEG    (XDATA)
                                   1068 ;--------------------------------------------------------
                                   1069 ; absolute external ram data
                                   1070 ;--------------------------------------------------------
                                   1071 	.area XABS    (ABS,XDATA)
                                   1072 ;--------------------------------------------------------
                                   1073 ; external initialized ram data
                                   1074 ;--------------------------------------------------------
                                   1075 	.area XISEG   (XDATA)
                           000000  1076 Fmain$xLatchedError$0_0$0==.
      001873                       1077 _xLatchedError:
      001873                       1078 	.ds 1
                                   1079 	.area HOME    (CODE)
                                   1080 	.area GSINIT0 (CODE)
                                   1081 	.area GSINIT1 (CODE)
                                   1082 	.area GSINIT2 (CODE)
                                   1083 	.area GSINIT3 (CODE)
                                   1084 	.area GSINIT4 (CODE)
                                   1085 	.area GSINIT5 (CODE)
                                   1086 	.area GSINIT  (CODE)
                                   1087 	.area GSFINAL (CODE)
                                   1088 	.area CSEG    (CODE)
                                   1089 ;--------------------------------------------------------
                                   1090 ; interrupt vector 
                                   1091 ;--------------------------------------------------------
                                   1092 	.area HOME    (CODE)
      000000                       1093 __interrupt_vect:
      000000 02 00 5F         [24] 1094 	ljmp	__sdcc_gsinit_startup
      000003 32               [24] 1095 	reti
      000004                       1096 	.ds	7
      00000B 32               [24] 1097 	reti
      00000C                       1098 	.ds	7
      000013 32               [24] 1099 	reti
      000014                       1100 	.ds	7
      00001B 32               [24] 1101 	reti
      00001C                       1102 	.ds	7
      000023 02 0B 03         [24] 1103 	ljmp	_vSerialISR
      000026                       1104 	.ds	5
      00002B 02 69 87         [24] 1105 	ljmp	_vTimer2ISR
                                   1106 ;--------------------------------------------------------
                                   1107 ; global & static initialisations
                                   1108 ;--------------------------------------------------------
                                   1109 	.area HOME    (CODE)
                                   1110 	.area GSINIT  (CODE)
                                   1111 	.area GSFINAL (CODE)
                                   1112 	.area GSINIT  (CODE)
                                   1113 	.globl __sdcc_gsinit_startup
                                   1114 	.globl __sdcc_program_startup
                                   1115 	.globl __start__stack
                                   1116 	.globl __mcs51_genXINIT
                                   1117 	.globl __mcs51_genXRAMCLEAR
                                   1118 	.globl __mcs51_genRAMCLEAR
                                   1119 	.area GSFINAL (CODE)
      0000DC 02 00 2E         [24] 1120 	ljmp	__sdcc_program_startup
                                   1121 ;--------------------------------------------------------
                                   1122 ; Home
                                   1123 ;--------------------------------------------------------
                                   1124 	.area HOME    (CODE)
                                   1125 	.area HOME    (CODE)
      00002E                       1126 __sdcc_program_startup:
      00002E 02 00 DF         [24] 1127 	ljmp	_main
                                   1128 ;	return from main will return to caller
                                   1129 ;--------------------------------------------------------
                                   1130 ; code
                                   1131 ;--------------------------------------------------------
                                   1132 	.area CSEG    (CODE)
                                   1133 ;------------------------------------------------------------
                                   1134 ;Allocation info for local variables in function 'main'
                                   1135 ;------------------------------------------------------------
                           000000  1136 	G$main$0$0 ==.
                           000000  1137 	C$main.c$187$0_0$130 ==.
                                   1138 ;	main.c:187: void main( void )
                                   1139 ;	-----------------------------------------
                                   1140 ;	 function main
                                   1141 ;	-----------------------------------------
      0000DF                       1142 _main:
                           000007  1143 	ar7 = 0x07
                           000006  1144 	ar6 = 0x06
                           000005  1145 	ar5 = 0x05
                           000004  1146 	ar4 = 0x04
                           000003  1147 	ar3 = 0x03
                           000002  1148 	ar2 = 0x02
                           000001  1149 	ar1 = 0x01
                           000000  1150 	ar0 = 0x00
                           000000  1151 	C$main.c$191$1_0$130 ==.
                                   1152 ;	main.c:191: prvSetupHardware();
      0000DF 12 01 F7         [24] 1153 	lcall	_prvSetupHardware
                           000003  1154 	C$main.c$195$1_0$130 ==.
                                   1155 ;	main.c:195: vParTestInitialise();
      0000E2 12 08 4B         [24] 1156 	lcall	_vParTestInitialise
                           000006  1157 	C$main.c$198$1_0$130 ==.
                                   1158 ;	main.c:198: vStartLEDFlashTasks( mainLED_TASK_PRIORITY );
      0000E5 75 82 01         [24] 1159 	mov	dpl,#0x01
      0000E8 12 0D 03         [24] 1160 	lcall	_vStartLEDFlashTasks
                           00000C  1161 	C$main.c$199$1_0$130 ==.
                                   1162 ;	main.c:199: vStartPolledQueueTasks( mainQUEUE_POLL_PRIORITY );
      0000EB 75 82 02         [24] 1163 	mov	dpl,#0x02
      0000EE 12 11 20         [24] 1164 	lcall	_vStartPolledQueueTasks
                           000012  1165 	C$main.c$200$1_0$130 ==.
                                   1166 ;	main.c:200: vStartIntegerMathTasks( mainINTEGER_PRIORITY );
      0000F1 75 82 00         [24] 1167 	mov	dpl,#0x00
      0000F4 12 0F 5B         [24] 1168 	lcall	_vStartIntegerMathTasks
                           000018  1169 	C$main.c$201$1_0$130 ==.
                                   1170 ;	main.c:201: vAltStartComTestTasks( mainCOM_TEST_PRIORITY, mainCOM_TEST_BAUD_RATE, mainCOM_TEST_LED );
      0000F7 74 C8            [12] 1171 	mov	a,#0xc8
      0000F9 C0 E0            [24] 1172 	push	acc
      0000FB 74 00            [12] 1173 	mov	a,#0x00
      0000FD C0 E0            [24] 1174 	push	acc
      0000FF 74 C2            [12] 1175 	mov	a,#0xc2
      000101 C0 E0            [24] 1176 	push	acc
      000103 74 01            [12] 1177 	mov	a,#0x01
      000105 C0 E0            [24] 1178 	push	acc
      000107 74 00            [12] 1179 	mov	a,#0x00
      000109 C0 E0            [24] 1180 	push	acc
      00010B 75 82 02         [24] 1181 	mov	dpl,#0x02
      00010E 12 13 E9         [24] 1182 	lcall	_vAltStartComTestTasks
      000111 E5 81            [12] 1183 	mov	a,sp
      000113 24 FB            [12] 1184 	add	a,#0xfb
      000115 F5 81            [12] 1185 	mov	sp,a
                           000038  1186 	C$main.c$202$1_0$130 ==.
                                   1187 ;	main.c:202: vStartSemaphoreTasks( mainSEM_TEST_PRIORITY );
      000117 75 82 02         [24] 1188 	mov	dpl,#0x02
      00011A 12 16 6C         [24] 1189 	lcall	_vStartSemaphoreTasks
                           00003E  1190 	C$main.c$208$2_0$131 ==.
                                   1191 ;	main.c:208: xTaskCreate( vRegisterCheck, "RegChck", configMINIMAL_STACK_SIZE, mainDUMMY_POINTER, tskIDLE_PRIORITY, ( TaskHandle_t * ) NULL );
      00011D 74 00            [12] 1192 	mov	a,#0x00
      00011F C0 E0            [24] 1193 	push	acc
      000121 C0 E0            [24] 1194 	push	acc
      000123 C0 E0            [24] 1195 	push	acc
      000125 C0 E0            [24] 1196 	push	acc
      000127 74 CD            [12] 1197 	mov	a,#0xcd
      000129 C0 E0            [24] 1198 	push	acc
      00012B 74 AB            [12] 1199 	mov	a,#0xab
      00012D C0 E0            [24] 1200 	push	acc
      00012F 74 00            [12] 1201 	mov	a,#0x00
      000131 C0 E0            [24] 1202 	push	acc
      000133 74 BA            [12] 1203 	mov	a,#0xba
      000135 C0 E0            [24] 1204 	push	acc
      000137 74 00            [12] 1205 	mov	a,#0x00
      000139 C0 E0            [24] 1206 	push	acc
      00013B 74 48            [12] 1207 	mov	a,#___str_0
      00013D C0 E0            [24] 1208 	push	acc
      00013F 74 73            [12] 1209 	mov	a,#(___str_0 >> 8)
      000141 C0 E0            [24] 1210 	push	acc
      000143 74 80            [12] 1211 	mov	a,#0x80
      000145 C0 E0            [24] 1212 	push	acc
      000147 75 82 BC         [24] 1213 	mov	dpl,#_vRegisterCheck
      00014A 75 83 06         [24] 1214 	mov	dph,#(_vRegisterCheck >> 8)
      00014D 12 1D 58         [24] 1215 	lcall	_xTaskCreate
      000150 E5 81            [12] 1216 	mov	a,sp
      000152 24 F4            [12] 1217 	add	a,#0xf4
      000154 F5 81            [12] 1218 	mov	sp,a
                           000077  1219 	C$main.c$209$2_0$131 ==.
                                   1220 ;	main.c:209: xTaskCreate( vFLOPCheck1, "FLOP", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, ( TaskHandle_t * ) NULL );
      000156 74 00            [12] 1221 	mov	a,#0x00
      000158 C0 E0            [24] 1222 	push	acc
      00015A C0 E0            [24] 1223 	push	acc
      00015C C0 E0            [24] 1224 	push	acc
      00015E C0 E0            [24] 1225 	push	acc
      000160 C0 E0            [24] 1226 	push	acc
      000162 C0 E0            [24] 1227 	push	acc
      000164 C0 E0            [24] 1228 	push	acc
      000166 74 BA            [12] 1229 	mov	a,#0xba
      000168 C0 E0            [24] 1230 	push	acc
      00016A 74 00            [12] 1231 	mov	a,#0x00
      00016C C0 E0            [24] 1232 	push	acc
      00016E 74 50            [12] 1233 	mov	a,#___str_1
      000170 C0 E0            [24] 1234 	push	acc
      000172 74 73            [12] 1235 	mov	a,#(___str_1 >> 8)
      000174 C0 E0            [24] 1236 	push	acc
      000176 74 80            [12] 1237 	mov	a,#0x80
      000178 C0 E0            [24] 1238 	push	acc
      00017A 75 82 7E         [24] 1239 	mov	dpl,#_vFLOPCheck1
      00017D 75 83 03         [24] 1240 	mov	dph,#(_vFLOPCheck1 >> 8)
      000180 12 1D 58         [24] 1241 	lcall	_xTaskCreate
      000183 E5 81            [12] 1242 	mov	a,sp
      000185 24 F4            [12] 1243 	add	a,#0xf4
      000187 F5 81            [12] 1244 	mov	sp,a
                           0000AA  1245 	C$main.c$210$2_0$131 ==.
                                   1246 ;	main.c:210: xTaskCreate( vFLOPCheck2, "FLOP", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, ( TaskHandle_t * ) NULL );
      000189 74 00            [12] 1247 	mov	a,#0x00
      00018B C0 E0            [24] 1248 	push	acc
      00018D C0 E0            [24] 1249 	push	acc
      00018F C0 E0            [24] 1250 	push	acc
      000191 C0 E0            [24] 1251 	push	acc
      000193 C0 E0            [24] 1252 	push	acc
      000195 C0 E0            [24] 1253 	push	acc
      000197 C0 E0            [24] 1254 	push	acc
      000199 74 BA            [12] 1255 	mov	a,#0xba
      00019B C0 E0            [24] 1256 	push	acc
      00019D 74 00            [12] 1257 	mov	a,#0x00
      00019F C0 E0            [24] 1258 	push	acc
      0001A1 74 50            [12] 1259 	mov	a,#___str_1
      0001A3 C0 E0            [24] 1260 	push	acc
      0001A5 74 73            [12] 1261 	mov	a,#(___str_1 >> 8)
      0001A7 C0 E0            [24] 1262 	push	acc
      0001A9 74 80            [12] 1263 	mov	a,#0x80
      0001AB C0 E0            [24] 1264 	push	acc
      0001AD 75 82 1A         [24] 1265 	mov	dpl,#_vFLOPCheck2
      0001B0 75 83 05         [24] 1266 	mov	dph,#(_vFLOPCheck2 >> 8)
      0001B3 12 1D 58         [24] 1267 	lcall	_xTaskCreate
      0001B6 E5 81            [12] 1268 	mov	a,sp
      0001B8 24 F4            [12] 1269 	add	a,#0xf4
      0001BA F5 81            [12] 1270 	mov	sp,a
                           0000DD  1271 	C$main.c$214$1_0$130 ==.
                                   1272 ;	main.c:214: xTaskCreate( vErrorChecks, "Check", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, ( TaskHandle_t * ) NULL );
      0001BC 74 00            [12] 1273 	mov	a,#0x00
      0001BE C0 E0            [24] 1274 	push	acc
      0001C0 C0 E0            [24] 1275 	push	acc
      0001C2 C0 E0            [24] 1276 	push	acc
      0001C4 74 03            [12] 1277 	mov	a,#0x03
      0001C6 C0 E0            [24] 1278 	push	acc
      0001C8 74 00            [12] 1279 	mov	a,#0x00
      0001CA C0 E0            [24] 1280 	push	acc
      0001CC C0 E0            [24] 1281 	push	acc
      0001CE C0 E0            [24] 1282 	push	acc
      0001D0 74 BA            [12] 1283 	mov	a,#0xba
      0001D2 C0 E0            [24] 1284 	push	acc
      0001D4 74 00            [12] 1285 	mov	a,#0x00
      0001D6 C0 E0            [24] 1286 	push	acc
      0001D8 74 55            [12] 1287 	mov	a,#___str_2
      0001DA C0 E0            [24] 1288 	push	acc
      0001DC 74 73            [12] 1289 	mov	a,#(___str_2 >> 8)
      0001DE C0 E0            [24] 1290 	push	acc
      0001E0 74 80            [12] 1291 	mov	a,#0x80
      0001E2 C0 E0            [24] 1292 	push	acc
      0001E4 75 82 F9         [24] 1293 	mov	dpl,#_vErrorChecks
      0001E7 75 83 02         [24] 1294 	mov	dph,#(_vErrorChecks >> 8)
      0001EA 12 1D 58         [24] 1295 	lcall	_xTaskCreate
      0001ED E5 81            [12] 1296 	mov	a,sp
      0001EF 24 F4            [12] 1297 	add	a,#0xf4
      0001F1 F5 81            [12] 1298 	mov	sp,a
                           000114  1299 	C$main.c$217$1_0$130 ==.
                                   1300 ;	main.c:217: vTaskStartScheduler();
      0001F3 12 24 79         [24] 1301 	lcall	_vTaskStartScheduler
      0001F6                       1302 00101$:
                           000117  1303 	C$main.c$221$1_0$130 ==.
                                   1304 ;	main.c:221: }
                           000117  1305 	C$main.c$221$1_0$130 ==.
                           000117  1306 	XG$main$0$0 ==.
      0001F6 22               [24] 1307 	ret
                                   1308 ;------------------------------------------------------------
                                   1309 ;Allocation info for local variables in function 'prvSetupHardware'
                                   1310 ;------------------------------------------------------------
                                   1311 ;ucOriginalSFRPage         Allocated to registers r7 
                                   1312 ;------------------------------------------------------------
                           000118  1313 	Fmain$prvSetupHardware$0$0 ==.
                           000118  1314 	C$main.c$229$1_0$133 ==.
                                   1315 ;	main.c:229: static void prvSetupHardware( void )
                                   1316 ;	-----------------------------------------
                                   1317 ;	 function prvSetupHardware
                                   1318 ;	-----------------------------------------
      0001F7                       1319 _prvSetupHardware:
                           000118  1320 	C$main.c$235$1_0$133 ==.
                                   1321 ;	main.c:235: ucOriginalSFRPage = SFRPAGE;
      0001F7 AF 84            [24] 1322 	mov	r7,_SFRPAGE
                           00011A  1323 	C$main.c$238$1_0$133 ==.
                                   1324 ;	main.c:238: SFRPAGE = CONFIG_PAGE;
      0001F9 75 84 0F         [24] 1325 	mov	_SFRPAGE,#0x0f
                           00011D  1326 	C$main.c$242$1_0$133 ==.
                                   1327 ;	main.c:242: SFRPGCN = mainAUTO_SFR_OFF;
      0001FC 75 96 00         [24] 1328 	mov	_SFRPGCN,#0x00
                           000120  1329 	C$main.c$245$1_0$133 ==.
                                   1330 ;	main.c:245: WDTCN = mainDISABLE_BYTE_1;
      0001FF 75 FF DE         [24] 1331 	mov	_WDTCN,#0xde
                           000123  1332 	C$main.c$246$1_0$133 ==.
                                   1333 ;	main.c:246: WDTCN = mainDISABLE_BYTE_2;
      000202 75 FF AD         [24] 1334 	mov	_WDTCN,#0xad
                           000126  1335 	C$main.c$250$1_0$133 ==.
                                   1336 ;	main.c:250: P2MDOUT |= my_mainPORT_2_BIT_0;
      000205 43 A6 01         [24] 1337 	orl	_P2MDOUT,#0x01
                           000129  1338 	C$main.c$254$1_0$133 ==.
                                   1339 ;	main.c:254: XBR0 |= mainENABLE_COMS;
      000208 43 E1 04         [24] 1340 	orl	_XBR0,#0x04
                           00012C  1341 	C$main.c$255$1_0$133 ==.
                                   1342 ;	main.c:255: P0MDOUT |= mainCOMS_LINES_TO_PUSH_PULL;
      00020B 43 A4 03         [24] 1343 	orl	_P0MDOUT,#0x03
                           00012F  1344 	C$main.c$258$1_0$133 ==.
                                   1345 ;	main.c:258: XBR2 = mainENABLE_CROSS_BAR;
      00020E 75 E3 40         [24] 1346 	mov	_XBR2,#0x40
                           000132  1347 	C$main.c$261$1_0$133 ==.
                                   1348 ;	main.c:261: prvSetupSystemClock();
      000211 C0 07            [24] 1349 	push	ar7
      000213 12 02 1B         [24] 1350 	lcall	_prvSetupSystemClock
      000216 D0 07            [24] 1351 	pop	ar7
                           000139  1352 	C$main.c$264$1_0$133 ==.
                                   1353 ;	main.c:264: SFRPAGE = ucOriginalSFRPage;
      000218 8F 84            [24] 1354 	mov	_SFRPAGE,r7
      00021A                       1355 00101$:
                           00013B  1356 	C$main.c$265$1_0$133 ==.
                                   1357 ;	main.c:265: }
                           00013B  1358 	C$main.c$265$1_0$133 ==.
                           00013B  1359 	XFmain$prvSetupHardware$0$0 ==.
      00021A 22               [24] 1360 	ret
                                   1361 ;------------------------------------------------------------
                                   1362 ;Allocation info for local variables in function 'prvSetupSystemClock'
                                   1363 ;------------------------------------------------------------
                                   1364 ;usWait                    Allocated to stack - _bp +1
                                   1365 ;usWaitTime                Allocated to registers 
                                   1366 ;ucOriginalSFRPage         Allocated to registers r7 
                                   1367 ;------------------------------------------------------------
                           00013C  1368 	Fmain$prvSetupSystemClock$0$0 ==.
                           00013C  1369 	C$main.c$268$1_0$135 ==.
                                   1370 ;	main.c:268: static void prvSetupSystemClock( void )
                                   1371 ;	-----------------------------------------
                                   1372 ;	 function prvSetupSystemClock
                                   1373 ;	-----------------------------------------
      00021B                       1374 _prvSetupSystemClock:
      00021B C0 0D            [24] 1375 	push	_bp
      00021D 85 81 0D         [24] 1376 	mov	_bp,sp
      000220 05 81            [12] 1377 	inc	sp
      000222 05 81            [12] 1378 	inc	sp
                           000145  1379 	C$main.c$275$1_0$135 ==.
                                   1380 ;	main.c:275: ucOriginalSFRPage = SFRPAGE;
      000224 AF 84            [24] 1381 	mov	r7,_SFRPAGE
                           000147  1382 	C$main.c$276$1_0$135 ==.
                                   1383 ;	main.c:276: SFRPAGE = CONFIG_PAGE;
      000226 75 84 0F         [24] 1384 	mov	_SFRPAGE,#0x0f
                           00014A  1385 	C$main.c$279$1_0$135 ==.
                                   1386 ;	main.c:279: OSCICN = mainSELECT_INTERNAL_OSC | mainDIVIDE_CLOCK_BY_1;
      000229 75 8A 83         [24] 1387 	mov	_OSCICN,#0x83
                           00014D  1388 	C$main.c$282$2_0$136 ==.
                                   1389 ;	main.c:282: for( usWait = 0; usWait < usWaitTime; usWait++ );
      00022C A8 0D            [24] 1390 	mov	r0,_bp
      00022E 08               [12] 1391 	inc	r0
      00022F 74 00            [12] 1392 	mov	a,#0x00
      000231 F6               [12] 1393 	mov	@r0,a
      000232 08               [12] 1394 	inc	r0
      000233 F6               [12] 1395 	mov	@r0,a
      000234                       1396 00107$:
      000234 A8 0D            [24] 1397 	mov	r0,_bp
      000236 08               [12] 1398 	inc	r0
      000237 C3               [12] 1399 	clr	c
      000238 E6               [12] 1400 	mov	a,@r0
      000239 94 FF            [12] 1401 	subb	a,#0xff
      00023B 08               [12] 1402 	inc	r0
      00023C E6               [12] 1403 	mov	a,@r0
      00023D 94 02            [12] 1404 	subb	a,#0x02
      00023F 40 03            [24] 1405 	jc	00145$
      000241 02 02 5B         [24] 1406 	ljmp	00101$
      000244                       1407 00145$:
      000244 A8 0D            [24] 1408 	mov	r0,_bp
      000246 08               [12] 1409 	inc	r0
      000247 86 05            [24] 1410 	mov	ar5,@r0
      000249 08               [12] 1411 	inc	r0
      00024A 86 06            [24] 1412 	mov	ar6,@r0
      00024C A8 0D            [24] 1413 	mov	r0,_bp
      00024E 08               [12] 1414 	inc	r0
      00024F 74 01            [12] 1415 	mov	a,#0x01
      000251 2D               [12] 1416 	add	a,r5
      000252 F6               [12] 1417 	mov	@r0,a
      000253 74 00            [12] 1418 	mov	a,#0x00
      000255 3E               [12] 1419 	addc	a,r6
      000256 08               [12] 1420 	inc	r0
      000257 F6               [12] 1421 	mov	@r0,a
      000258 02 02 34         [24] 1422 	ljmp	00107$
      00025B                       1423 00101$:
                           00017C  1424 	C$main.c$285$1_0$135 ==.
                                   1425 ;	main.c:285: PLL0CN &= ~mainPLL_USES_INTERNAL_OSC;
      00025B 53 89 FB         [24] 1426 	anl	_PLL0CN,#0xfb
                           00017F  1427 	C$main.c$288$1_0$135 ==.
                                   1428 ;	main.c:288: SFRPAGE = LEGACY_PAGE;
      00025E 75 84 00         [24] 1429 	mov	_SFRPAGE,#0x00
                           000182  1430 	C$main.c$289$1_0$135 ==.
                                   1431 ;	main.c:289: FLSCL |= mainFLASH_READ_TIMING;
      000261 43 B7 30         [24] 1432 	orl	_FLSCL,#0x30
                           000185  1433 	C$main.c$292$1_0$135 ==.
                                   1434 ;	main.c:292: SFRPAGE = CONFIG_PAGE;
      000264 75 84 0F         [24] 1435 	mov	_SFRPAGE,#0x0f
                           000188  1436 	C$main.c$293$1_0$135 ==.
                                   1437 ;	main.c:293: PLL0CN |= mainPLL_POWER_ON;
      000267 43 89 01         [24] 1438 	orl	_PLL0CN,#0x01
                           00018B  1439 	C$main.c$296$1_0$135 ==.
                                   1440 ;	main.c:296: PLL0DIV = mainPLL_NO_PREDIVIDE;
      00026A 75 8D 01         [24] 1441 	mov	_PLL0DIV,#0x01
                           00018E  1442 	C$main.c$299$1_0$135 ==.
                                   1443 ;	main.c:299: PLL0FLT = mainPLL_FILTER;
      00026D 75 8F 01         [24] 1444 	mov	_PLL0FLT,#0x01
                           000191  1445 	C$main.c$300$1_0$135 ==.
                                   1446 ;	main.c:300: PLL0MUL = mainPLL_MULTIPLICATION;
      000270 75 8E 04         [24] 1447 	mov	_PLL0MUL,#0x04
                           000194  1448 	C$main.c$303$2_0$137 ==.
                                   1449 ;	main.c:303: for( usWait = 0; usWait < usWaitTime; usWait++ );
      000273 A8 0D            [24] 1450 	mov	r0,_bp
      000275 08               [12] 1451 	inc	r0
      000276 74 00            [12] 1452 	mov	a,#0x00
      000278 F6               [12] 1453 	mov	@r0,a
      000279 08               [12] 1454 	inc	r0
      00027A F6               [12] 1455 	mov	@r0,a
      00027B                       1456 00110$:
      00027B A8 0D            [24] 1457 	mov	r0,_bp
      00027D 08               [12] 1458 	inc	r0
      00027E C3               [12] 1459 	clr	c
      00027F E6               [12] 1460 	mov	a,@r0
      000280 94 FF            [12] 1461 	subb	a,#0xff
      000282 08               [12] 1462 	inc	r0
      000283 E6               [12] 1463 	mov	a,@r0
      000284 94 02            [12] 1464 	subb	a,#0x02
      000286 40 03            [24] 1465 	jc	00146$
      000288 02 02 A2         [24] 1466 	ljmp	00102$
      00028B                       1467 00146$:
      00028B A8 0D            [24] 1468 	mov	r0,_bp
      00028D 08               [12] 1469 	inc	r0
      00028E 86 05            [24] 1470 	mov	ar5,@r0
      000290 08               [12] 1471 	inc	r0
      000291 86 06            [24] 1472 	mov	ar6,@r0
      000293 A8 0D            [24] 1473 	mov	r0,_bp
      000295 08               [12] 1474 	inc	r0
      000296 74 01            [12] 1475 	mov	a,#0x01
      000298 2D               [12] 1476 	add	a,r5
      000299 F6               [12] 1477 	mov	@r0,a
      00029A 74 00            [12] 1478 	mov	a,#0x00
      00029C 3E               [12] 1479 	addc	a,r6
      00029D 08               [12] 1480 	inc	r0
      00029E F6               [12] 1481 	mov	@r0,a
      00029F 02 02 7B         [24] 1482 	ljmp	00110$
      0002A2                       1483 00102$:
                           0001C3  1484 	C$main.c$306$1_0$135 ==.
                                   1485 ;	main.c:306: PLL0CN |= mainENABLE_PLL;
      0002A2 43 89 02         [24] 1486 	orl	_PLL0CN,#0x02
                           0001C6  1487 	C$main.c$307$2_0$138 ==.
                                   1488 ;	main.c:307: for( usWait = 0; usWait < usWaitTime; usWait++ )
      0002A5 A8 0D            [24] 1489 	mov	r0,_bp
      0002A7 08               [12] 1490 	inc	r0
      0002A8 74 00            [12] 1491 	mov	a,#0x00
      0002AA F6               [12] 1492 	mov	@r0,a
      0002AB 08               [12] 1493 	inc	r0
      0002AC F6               [12] 1494 	mov	@r0,a
      0002AD                       1495 00113$:
      0002AD A8 0D            [24] 1496 	mov	r0,_bp
      0002AF 08               [12] 1497 	inc	r0
      0002B0 C3               [12] 1498 	clr	c
      0002B1 E6               [12] 1499 	mov	a,@r0
      0002B2 94 FF            [12] 1500 	subb	a,#0xff
      0002B4 08               [12] 1501 	inc	r0
      0002B5 E6               [12] 1502 	mov	a,@r0
      0002B6 94 02            [12] 1503 	subb	a,#0x02
      0002B8 40 03            [24] 1504 	jc	00147$
      0002BA 02 02 DC         [24] 1505 	ljmp	00105$
      0002BD                       1506 00147$:
                           0001DE  1507 	C$main.c$309$3_0$139 ==.
                                   1508 ;	main.c:309: if( PLL0CN & mainPLL_LOCKED )
      0002BD E5 89            [12] 1509 	mov	a,_PLL0CN
      0002BF 30 E4 03         [24] 1510 	jnb	acc.4,00148$
      0002C2 02 02 DC         [24] 1511 	ljmp	00105$
      0002C5                       1512 00148$:
                           0001E6  1513 	C$main.c$307$2_0$138 ==.
                                   1514 ;	main.c:307: for( usWait = 0; usWait < usWaitTime; usWait++ )
      0002C5 A8 0D            [24] 1515 	mov	r0,_bp
      0002C7 08               [12] 1516 	inc	r0
      0002C8 86 05            [24] 1517 	mov	ar5,@r0
      0002CA 08               [12] 1518 	inc	r0
      0002CB 86 06            [24] 1519 	mov	ar6,@r0
      0002CD A8 0D            [24] 1520 	mov	r0,_bp
      0002CF 08               [12] 1521 	inc	r0
      0002D0 74 01            [12] 1522 	mov	a,#0x01
      0002D2 2D               [12] 1523 	add	a,r5
      0002D3 F6               [12] 1524 	mov	@r0,a
      0002D4 74 00            [12] 1525 	mov	a,#0x00
      0002D6 3E               [12] 1526 	addc	a,r6
      0002D7 08               [12] 1527 	inc	r0
      0002D8 F6               [12] 1528 	mov	@r0,a
      0002D9 02 02 AD         [24] 1529 	ljmp	00113$
      0002DC                       1530 00105$:
                           0001FD  1531 	C$main.c$316$1_0$135 ==.
                                   1532 ;	main.c:316: CLKSEL |= mainSELECT_PLL_AS_SOURCE;
      0002DC 43 97 02         [24] 1533 	orl	_CLKSEL,#0x02
                           000200  1534 	C$main.c$319$1_0$135 ==.
                                   1535 ;	main.c:319: SFRPAGE = ucOriginalSFRPage;
      0002DF 8F 84            [24] 1536 	mov	_SFRPAGE,r7
      0002E1                       1537 00115$:
                           000202  1538 	C$main.c$320$1_0$135 ==.
                                   1539 ;	main.c:320: }
      0002E1 85 0D 81         [24] 1540 	mov	sp,_bp
      0002E4 D0 0D            [24] 1541 	pop	_bp
                           000207  1542 	C$main.c$320$1_0$135 ==.
                           000207  1543 	XFmain$prvSetupSystemClock$0$0 ==.
      0002E6 22               [24] 1544 	ret
                                   1545 ;------------------------------------------------------------
                                   1546 ;Allocation info for local variables in function 'prvToggleOnBoardLED'
                                   1547 ;------------------------------------------------------------
                           000208  1548 	Fmain$prvToggleOnBoardLED$0$0 ==.
                           000208  1549 	C$main.c$323$1_0$142 ==.
                                   1550 ;	main.c:323: static void prvToggleOnBoardLED( void )
                                   1551 ;	-----------------------------------------
                                   1552 ;	 function prvToggleOnBoardLED
                                   1553 ;	-----------------------------------------
      0002E7                       1554 _prvToggleOnBoardLED:
                           000208  1555 	C$main.c$336$1_0$142 ==.
                                   1556 ;	main.c:336: if( P2 & my_ucLED_BIT )
      0002E7 E5 A0            [12] 1557 	mov	a,_P2
      0002E9 20 E0 03         [24] 1558 	jb	acc.0,00110$
      0002EC 02 02 F5         [24] 1559 	ljmp	00102$
      0002EF                       1560 00110$:
                           000210  1561 	C$main.c$338$2_0$143 ==.
                                   1562 ;	main.c:338: P2 &= ~my_ucLED_BIT;
      0002EF 53 A0 FE         [24] 1563 	anl	_P2,#0xfe
      0002F2 02 02 F8         [24] 1564 	ljmp	00104$
      0002F5                       1565 00102$:
                           000216  1566 	C$main.c$342$2_0$144 ==.
                                   1567 ;	main.c:342: P2 |= my_ucLED_BIT;
      0002F5 43 A0 01         [24] 1568 	orl	_P2,#0x01
      0002F8                       1569 00104$:
                           000219  1570 	C$main.c$344$1_0$142 ==.
                                   1571 ;	main.c:344: }
                           000219  1572 	C$main.c$344$1_0$142 ==.
                           000219  1573 	XFmain$prvToggleOnBoardLED$0$0 ==.
      0002F8 22               [24] 1574 	ret
                                   1575 ;------------------------------------------------------------
                                   1576 ;Allocation info for local variables in function 'vErrorChecks'
                                   1577 ;------------------------------------------------------------
                                   1578 ;pvParameters              Allocated to registers 
                                   1579 ;xErrorHasOccurred         Allocated to registers r7 
                                   1580 ;------------------------------------------------------------
                           00021A  1581 	Fmain$vErrorChecks$0$0 ==.
                           00021A  1582 	C$main.c$350$1_0$146 ==.
                                   1583 ;	main.c:350: static void vErrorChecks( void *pvParameters )
                                   1584 ;	-----------------------------------------
                                   1585 ;	 function vErrorChecks
                                   1586 ;	-----------------------------------------
      0002F9                       1587 _vErrorChecks:
                           00021A  1588 	C$main.c$352$2_0$146 ==.
                                   1589 ;	main.c:352: portBASE_TYPE xErrorHasOccurred = pdFALSE;
      0002F9 7F 00            [12] 1590 	mov	r7,#0x00
                           00021C  1591 	C$main.c$355$2_0$147 ==.
                                   1592 ;	main.c:355: ( void ) pvParameters;
      0002FB                       1593 00115$:
                           00021C  1594 	C$main.c$362$3_0$148 ==.
                                   1595 ;	main.c:362: if( xLatchedError == pdFALSE )
      0002FB 90 18 73         [24] 1596 	mov	dptr,#_xLatchedError
      0002FE E0               [24] 1597 	movx	a,@dptr
      0002FF 60 03            [24] 1598 	jz	00147$
      000301 02 03 14         [24] 1599 	ljmp	00102$
      000304                       1600 00147$:
                           000225  1601 	C$main.c$366$4_0$149 ==.
                                   1602 ;	main.c:366: vTaskDelay( mainNO_ERROR_FLASH_PERIOD );
      000304 75 82 88         [24] 1603 	mov	dpl,#0x88
      000307 75 83 13         [24] 1604 	mov	dph,#0x13
      00030A C0 07            [24] 1605 	push	ar7
      00030C 12 24 43         [24] 1606 	lcall	_vTaskDelay
      00030F D0 07            [24] 1607 	pop	ar7
      000311 02 03 21         [24] 1608 	ljmp	00103$
      000314                       1609 00102$:
                           000235  1610 	C$main.c$373$4_0$150 ==.
                                   1611 ;	main.c:373: vTaskDelay( mainERROR_FLASH_PERIOD );
      000314 75 82 FA         [24] 1612 	mov	dpl,#0xfa
      000317 75 83 00         [24] 1613 	mov	dph,#0x00
      00031A C0 07            [24] 1614 	push	ar7
      00031C 12 24 43         [24] 1615 	lcall	_vTaskDelay
      00031F D0 07            [24] 1616 	pop	ar7
      000321                       1617 00103$:
                           000242  1618 	C$main.c$380$3_0$148 ==.
                                   1619 ;	main.c:380: if( xAreIntegerMathsTaskStillRunning() != pdTRUE )
      000321 C0 07            [24] 1620 	push	ar7
      000323 12 10 DF         [24] 1621 	lcall	_xAreIntegerMathsTaskStillRunning
      000326 AE 82            [24] 1622 	mov	r6,dpl
      000328 D0 07            [24] 1623 	pop	ar7
      00032A BE 01 03         [24] 1624 	cjne	r6,#0x01,00148$
      00032D 02 03 32         [24] 1625 	ljmp	00105$
      000330                       1626 00148$:
                           000251  1627 	C$main.c$382$4_0$151 ==.
                                   1628 ;	main.c:382: xErrorHasOccurred = pdTRUE;
      000330 7F 01            [12] 1629 	mov	r7,#0x01
      000332                       1630 00105$:
                           000253  1631 	C$main.c$385$3_0$148 ==.
                                   1632 ;	main.c:385: if( xArePollingQueuesStillRunning() != pdTRUE )
      000332 C0 07            [24] 1633 	push	ar7
      000334 12 13 C3         [24] 1634 	lcall	_xArePollingQueuesStillRunning
      000337 AE 82            [24] 1635 	mov	r6,dpl
      000339 D0 07            [24] 1636 	pop	ar7
      00033B BE 01 03         [24] 1637 	cjne	r6,#0x01,00149$
      00033E 02 03 43         [24] 1638 	ljmp	00107$
      000341                       1639 00149$:
                           000262  1640 	C$main.c$387$4_0$152 ==.
                                   1641 ;	main.c:387: xErrorHasOccurred = pdTRUE;
      000341 7F 01            [12] 1642 	mov	r7,#0x01
      000343                       1643 00107$:
                           000264  1644 	C$main.c$390$3_0$148 ==.
                                   1645 ;	main.c:390: if( xAreComTestTasksStillRunning() != pdTRUE )
      000343 C0 07            [24] 1646 	push	ar7
      000345 12 16 53         [24] 1647 	lcall	_xAreComTestTasksStillRunning
      000348 AE 82            [24] 1648 	mov	r6,dpl
      00034A D0 07            [24] 1649 	pop	ar7
      00034C BE 01 03         [24] 1650 	cjne	r6,#0x01,00150$
      00034F 02 03 54         [24] 1651 	ljmp	00109$
      000352                       1652 00150$:
                           000273  1653 	C$main.c$392$4_0$153 ==.
                                   1654 ;	main.c:392: xErrorHasOccurred = pdTRUE;
      000352 7F 01            [12] 1655 	mov	r7,#0x01
      000354                       1656 00109$:
                           000275  1657 	C$main.c$395$3_0$148 ==.
                                   1658 ;	main.c:395: if( xAreSemaphoreTasksStillRunning() != pdTRUE )
      000354 C0 07            [24] 1659 	push	ar7
      000356 12 1C EB         [24] 1660 	lcall	_xAreSemaphoreTasksStillRunning
      000359 AE 82            [24] 1661 	mov	r6,dpl
      00035B D0 07            [24] 1662 	pop	ar7
      00035D BE 01 03         [24] 1663 	cjne	r6,#0x01,00151$
      000360 02 03 65         [24] 1664 	ljmp	00111$
      000363                       1665 00151$:
                           000284  1666 	C$main.c$397$4_0$154 ==.
                                   1667 ;	main.c:397: xErrorHasOccurred = pdTRUE;
      000363 7F 01            [12] 1668 	mov	r7,#0x01
      000365                       1669 00111$:
                           000286  1670 	C$main.c$402$3_0$148 ==.
                                   1671 ;	main.c:402: if( xErrorHasOccurred == pdTRUE )
      000365 BF 01 02         [24] 1672 	cjne	r7,#0x01,00152$
      000368 80 03            [24] 1673 	sjmp	00153$
      00036A                       1674 00152$:
      00036A 02 03 73         [24] 1675 	ljmp	00113$
      00036D                       1676 00153$:
                           00028E  1677 	C$main.c$404$4_0$155 ==.
                                   1678 ;	main.c:404: xLatchedError = pdTRUE;
      00036D 90 18 73         [24] 1679 	mov	dptr,#_xLatchedError
      000370 74 01            [12] 1680 	mov	a,#0x01
      000372 F0               [24] 1681 	movx	@dptr,a
      000373                       1682 00113$:
                           000294  1683 	C$main.c$410$3_0$148 ==.
                                   1684 ;	main.c:410: prvToggleOnBoardLED();
      000373 C0 07            [24] 1685 	push	ar7
      000375 12 02 E7         [24] 1686 	lcall	_prvToggleOnBoardLED
      000378 D0 07            [24] 1687 	pop	ar7
      00037A 02 02 FB         [24] 1688 	ljmp	00115$
      00037D                       1689 00117$:
                           00029E  1690 	C$main.c$412$2_0$146 ==.
                                   1691 ;	main.c:412: }
                           00029E  1692 	C$main.c$412$2_0$146 ==.
                           00029E  1693 	XFmain$vErrorChecks$0$0 ==.
      00037D 22               [24] 1694 	ret
                                   1695 ;------------------------------------------------------------
                                   1696 ;Allocation info for local variables in function 'vFLOPCheck1'
                                   1697 ;------------------------------------------------------------
                                   1698 ;pvParameters              Allocated to registers 
                                   1699 ;fVal1                     Allocated to stack - _bp +9
                                   1700 ;fVal2                     Allocated to stack - _bp +5
                                   1701 ;fResult                   Allocated to stack - _bp +1
                                   1702 ;------------------------------------------------------------
                           00029F  1703 	Fmain$vFLOPCheck1$0$0 ==.
                           00029F  1704 	C$main.c$419$2_0$157 ==.
                                   1705 ;	main.c:419: static void vFLOPCheck1( void *pvParameters )
                                   1706 ;	-----------------------------------------
                                   1707 ;	 function vFLOPCheck1
                                   1708 ;	-----------------------------------------
      00037E                       1709 _vFLOPCheck1:
      00037E C0 0D            [24] 1710 	push	_bp
      000380 85 81 0D         [24] 1711 	mov	_bp,sp
      000383 E5 81            [12] 1712 	mov	a,sp
      000385 24 0C            [12] 1713 	add	a,#0x0c
      000387 F5 81            [12] 1714 	mov	sp,a
                           0002AA  1715 	C$main.c$423$2_0$158 ==.
                                   1716 ;	main.c:423: ( void ) pvParameters;
      000389                       1717 00108$:
                           0002AA  1718 	C$main.c$427$3_0$159 ==.
                                   1719 ;	main.c:427: fVal1 = ( portFLOAT ) -1234.5678;
      000389 E5 0D            [12] 1720 	mov	a,_bp
      00038B 24 09            [12] 1721 	add	a,#0x09
      00038D F8               [12] 1722 	mov	r0,a
      00038E 76 2B            [12] 1723 	mov	@r0,#0x2b
      000390 08               [12] 1724 	inc	r0
      000391 76 52            [12] 1725 	mov	@r0,#0x52
      000393 08               [12] 1726 	inc	r0
      000394 76 9A            [12] 1727 	mov	@r0,#0x9a
      000396 08               [12] 1728 	inc	r0
      000397 76 C4            [12] 1729 	mov	@r0,#0xc4
                           0002BA  1730 	C$main.c$428$3_0$159 ==.
                                   1731 ;	main.c:428: fVal2 = ( portFLOAT ) 2345.6789;
      000399 E5 0D            [12] 1732 	mov	a,_bp
      00039B 24 05            [12] 1733 	add	a,#0x05
      00039D F8               [12] 1734 	mov	r0,a
      00039E 76 DD            [12] 1735 	mov	@r0,#0xdd
      0003A0 08               [12] 1736 	inc	r0
      0003A1 76 9A            [12] 1737 	mov	@r0,#0x9a
      0003A3 08               [12] 1738 	inc	r0
      0003A4 76 12            [12] 1739 	mov	@r0,#0x12
      0003A6 08               [12] 1740 	inc	r0
      0003A7 76 45            [12] 1741 	mov	@r0,#0x45
                           0002CA  1742 	C$main.c$430$2_0$157 ==.
                                   1743 ;	main.c:430: fResult = fVal1 + fVal2;
      0003A9 E5 0D            [12] 1744 	mov	a,_bp
      0003AB 24 05            [12] 1745 	add	a,#0x05
      0003AD F8               [12] 1746 	mov	r0,a
      0003AE E6               [12] 1747 	mov	a,@r0
      0003AF C0 E0            [24] 1748 	push	acc
      0003B1 08               [12] 1749 	inc	r0
      0003B2 E6               [12] 1750 	mov	a,@r0
      0003B3 C0 E0            [24] 1751 	push	acc
      0003B5 08               [12] 1752 	inc	r0
      0003B6 E6               [12] 1753 	mov	a,@r0
      0003B7 C0 E0            [24] 1754 	push	acc
      0003B9 08               [12] 1755 	inc	r0
      0003BA E6               [12] 1756 	mov	a,@r0
      0003BB C0 E0            [24] 1757 	push	acc
      0003BD E5 0D            [12] 1758 	mov	a,_bp
      0003BF 24 09            [12] 1759 	add	a,#0x09
      0003C1 F8               [12] 1760 	mov	r0,a
      0003C2 86 82            [24] 1761 	mov	dpl,@r0
      0003C4 08               [12] 1762 	inc	r0
      0003C5 86 83            [24] 1763 	mov	dph,@r0
      0003C7 08               [12] 1764 	inc	r0
      0003C8 86 F0            [24] 1765 	mov	b,@r0
      0003CA 08               [12] 1766 	inc	r0
      0003CB E6               [12] 1767 	mov	a,@r0
      0003CC 12 6B DB         [24] 1768 	lcall	___fsadd
      0003CF AC 82            [24] 1769 	mov	r4,dpl
      0003D1 AD 83            [24] 1770 	mov	r5,dph
      0003D3 AE F0            [24] 1771 	mov	r6,b
      0003D5 FF               [12] 1772 	mov	r7,a
      0003D6 E5 81            [12] 1773 	mov	a,sp
      0003D8 24 FC            [12] 1774 	add	a,#0xfc
      0003DA F5 81            [12] 1775 	mov	sp,a
      0003DC A8 0D            [24] 1776 	mov	r0,_bp
      0003DE 08               [12] 1777 	inc	r0
      0003DF A6 04            [24] 1778 	mov	@r0,ar4
      0003E1 08               [12] 1779 	inc	r0
      0003E2 A6 05            [24] 1780 	mov	@r0,ar5
      0003E4 08               [12] 1781 	inc	r0
      0003E5 A6 06            [24] 1782 	mov	@r0,ar6
      0003E7 08               [12] 1783 	inc	r0
      0003E8 A6 07            [24] 1784 	mov	@r0,ar7
                           00030B  1785 	C$main.c$431$2_0$157 ==.
                                   1786 ;	main.c:431: if( ( fResult > ( portFLOAT )  1111.15 ) || ( fResult < ( portFLOAT ) 1111.05 ) )
      0003EA A8 0D            [24] 1787 	mov	r0,_bp
      0003EC 08               [12] 1788 	inc	r0
      0003ED E6               [12] 1789 	mov	a,@r0
      0003EE C0 E0            [24] 1790 	push	acc
      0003F0 08               [12] 1791 	inc	r0
      0003F1 E6               [12] 1792 	mov	a,@r0
      0003F2 C0 E0            [24] 1793 	push	acc
      0003F4 08               [12] 1794 	inc	r0
      0003F5 E6               [12] 1795 	mov	a,@r0
      0003F6 C0 E0            [24] 1796 	push	acc
      0003F8 08               [12] 1797 	inc	r0
      0003F9 E6               [12] 1798 	mov	a,@r0
      0003FA C0 E0            [24] 1799 	push	acc
      0003FC 75 82 CD         [24] 1800 	mov	dpl,#0xcd
      0003FF 75 83 E4         [24] 1801 	mov	dph,#0xe4
      000402 75 F0 8A         [24] 1802 	mov	b,#0x8a
      000405 74 44            [12] 1803 	mov	a,#0x44
      000407 12 6B 0D         [24] 1804 	lcall	___fslt
      00040A AF 82            [24] 1805 	mov	r7,dpl
      00040C E5 81            [12] 1806 	mov	a,sp
      00040E 24 FC            [12] 1807 	add	a,#0xfc
      000410 F5 81            [12] 1808 	mov	sp,a
      000412 EF               [12] 1809 	mov	a,r7
      000413 60 03            [24] 1810 	jz	00124$
      000415 02 04 46         [24] 1811 	ljmp	00101$
      000418                       1812 00124$:
      000418 74 9A            [12] 1813 	mov	a,#0x9a
      00041A C0 E0            [24] 1814 	push	acc
      00041C 74 E1            [12] 1815 	mov	a,#0xe1
      00041E C0 E0            [24] 1816 	push	acc
      000420 74 8A            [12] 1817 	mov	a,#0x8a
      000422 C0 E0            [24] 1818 	push	acc
      000424 74 44            [12] 1819 	mov	a,#0x44
      000426 C0 E0            [24] 1820 	push	acc
      000428 A8 0D            [24] 1821 	mov	r0,_bp
      00042A 08               [12] 1822 	inc	r0
      00042B 86 82            [24] 1823 	mov	dpl,@r0
      00042D 08               [12] 1824 	inc	r0
      00042E 86 83            [24] 1825 	mov	dph,@r0
      000430 08               [12] 1826 	inc	r0
      000431 86 F0            [24] 1827 	mov	b,@r0
      000433 08               [12] 1828 	inc	r0
      000434 E6               [12] 1829 	mov	a,@r0
      000435 12 6B 0D         [24] 1830 	lcall	___fslt
      000438 AF 82            [24] 1831 	mov	r7,dpl
      00043A E5 81            [12] 1832 	mov	a,sp
      00043C 24 FC            [12] 1833 	add	a,#0xfc
      00043E F5 81            [12] 1834 	mov	sp,a
      000440 EF               [12] 1835 	mov	a,r7
      000441 70 03            [24] 1836 	jnz	00125$
      000443 02 04 5D         [24] 1837 	ljmp	00102$
      000446                       1838 00125$:
      000446                       1839 00101$:
                           000367  1840 	C$main.c$433$5_0$161 ==.
                                   1841 ;	main.c:433: mainLATCH_ERROR();
      000446 C0 E0            [24] 1842 	push ACC 
      000448 C0 A8            [24] 1843 	push IE 
                                   1844 ;	assignBit
      00044A C2 AF            [12] 1845 	clr	_EA
      00044C 90 18 73         [24] 1846 	mov	dptr,#_xLatchedError
      00044F 74 01            [12] 1847 	mov	a,#0x01
      000451 F0               [24] 1848 	movx	@dptr,a
      000452 D0 E0            [24] 1849 	pop ACC 
      000454 53 E0 80         [24] 1850 	anl	_ACC,#0x80
      000457 E5 E0            [12] 1851 	mov	a,_ACC
      000459 42 A8            [12] 1852 	orl	_IE,a
      00045B D0 E0            [24] 1853 	pop ACC 
      00045D                       1854 00102$:
                           00037E  1855 	C$main.c$436$2_0$157 ==.
                                   1856 ;	main.c:436: fResult = fVal1 / fVal2;
      00045D E5 0D            [12] 1857 	mov	a,_bp
      00045F 24 05            [12] 1858 	add	a,#0x05
      000461 F8               [12] 1859 	mov	r0,a
      000462 E6               [12] 1860 	mov	a,@r0
      000463 C0 E0            [24] 1861 	push	acc
      000465 08               [12] 1862 	inc	r0
      000466 E6               [12] 1863 	mov	a,@r0
      000467 C0 E0            [24] 1864 	push	acc
      000469 08               [12] 1865 	inc	r0
      00046A E6               [12] 1866 	mov	a,@r0
      00046B C0 E0            [24] 1867 	push	acc
      00046D 08               [12] 1868 	inc	r0
      00046E E6               [12] 1869 	mov	a,@r0
      00046F C0 E0            [24] 1870 	push	acc
      000471 E5 0D            [12] 1871 	mov	a,_bp
      000473 24 09            [12] 1872 	add	a,#0x09
      000475 F8               [12] 1873 	mov	r0,a
      000476 86 82            [24] 1874 	mov	dpl,@r0
      000478 08               [12] 1875 	inc	r0
      000479 86 83            [24] 1876 	mov	dph,@r0
      00047B 08               [12] 1877 	inc	r0
      00047C 86 F0            [24] 1878 	mov	b,@r0
      00047E 08               [12] 1879 	inc	r0
      00047F E6               [12] 1880 	mov	a,@r0
      000480 12 6F 6D         [24] 1881 	lcall	___fsdiv
      000483 AC 82            [24] 1882 	mov	r4,dpl
      000485 AD 83            [24] 1883 	mov	r5,dph
      000487 AE F0            [24] 1884 	mov	r6,b
      000489 FF               [12] 1885 	mov	r7,a
      00048A E5 81            [12] 1886 	mov	a,sp
      00048C 24 FC            [12] 1887 	add	a,#0xfc
      00048E F5 81            [12] 1888 	mov	sp,a
      000490 A8 0D            [24] 1889 	mov	r0,_bp
      000492 08               [12] 1890 	inc	r0
      000493 A6 04            [24] 1891 	mov	@r0,ar4
      000495 08               [12] 1892 	inc	r0
      000496 A6 05            [24] 1893 	mov	@r0,ar5
      000498 08               [12] 1894 	inc	r0
      000499 A6 06            [24] 1895 	mov	@r0,ar6
      00049B 08               [12] 1896 	inc	r0
      00049C A6 07            [24] 1897 	mov	@r0,ar7
                           0003BF  1898 	C$main.c$437$2_0$157 ==.
                                   1899 ;	main.c:437: if( ( fResult > ( portFLOAT ) -0.51 ) || ( fResult < ( portFLOAT ) -0.53 ) )
      00049E A8 0D            [24] 1900 	mov	r0,_bp
      0004A0 08               [12] 1901 	inc	r0
      0004A1 E6               [12] 1902 	mov	a,@r0
      0004A2 C0 E0            [24] 1903 	push	acc
      0004A4 08               [12] 1904 	inc	r0
      0004A5 E6               [12] 1905 	mov	a,@r0
      0004A6 C0 E0            [24] 1906 	push	acc
      0004A8 08               [12] 1907 	inc	r0
      0004A9 E6               [12] 1908 	mov	a,@r0
      0004AA C0 E0            [24] 1909 	push	acc
      0004AC 08               [12] 1910 	inc	r0
      0004AD E6               [12] 1911 	mov	a,@r0
      0004AE C0 E0            [24] 1912 	push	acc
      0004B0 75 82 5C         [24] 1913 	mov	dpl,#0x5c
      0004B3 75 83 8F         [24] 1914 	mov	dph,#0x8f
      0004B6 75 F0 02         [24] 1915 	mov	b,#0x02
      0004B9 74 BF            [12] 1916 	mov	a,#0xbf
      0004BB 12 6B 0D         [24] 1917 	lcall	___fslt
      0004BE AF 82            [24] 1918 	mov	r7,dpl
      0004C0 E5 81            [12] 1919 	mov	a,sp
      0004C2 24 FC            [12] 1920 	add	a,#0xfc
      0004C4 F5 81            [12] 1921 	mov	sp,a
      0004C6 EF               [12] 1922 	mov	a,r7
      0004C7 60 03            [24] 1923 	jz	00126$
      0004C9 02 04 FA         [24] 1924 	ljmp	00104$
      0004CC                       1925 00126$:
      0004CC 74 14            [12] 1926 	mov	a,#0x14
      0004CE C0 E0            [24] 1927 	push	acc
      0004D0 74 AE            [12] 1928 	mov	a,#0xae
      0004D2 C0 E0            [24] 1929 	push	acc
      0004D4 74 07            [12] 1930 	mov	a,#0x07
      0004D6 C0 E0            [24] 1931 	push	acc
      0004D8 74 BF            [12] 1932 	mov	a,#0xbf
      0004DA C0 E0            [24] 1933 	push	acc
      0004DC A8 0D            [24] 1934 	mov	r0,_bp
      0004DE 08               [12] 1935 	inc	r0
      0004DF 86 82            [24] 1936 	mov	dpl,@r0
      0004E1 08               [12] 1937 	inc	r0
      0004E2 86 83            [24] 1938 	mov	dph,@r0
      0004E4 08               [12] 1939 	inc	r0
      0004E5 86 F0            [24] 1940 	mov	b,@r0
      0004E7 08               [12] 1941 	inc	r0
      0004E8 E6               [12] 1942 	mov	a,@r0
      0004E9 12 6B 0D         [24] 1943 	lcall	___fslt
      0004EC AF 82            [24] 1944 	mov	r7,dpl
      0004EE E5 81            [12] 1945 	mov	a,sp
      0004F0 24 FC            [12] 1946 	add	a,#0xfc
      0004F2 F5 81            [12] 1947 	mov	sp,a
      0004F4 EF               [12] 1948 	mov	a,r7
      0004F5 70 03            [24] 1949 	jnz	00127$
      0004F7 02 03 89         [24] 1950 	ljmp	00108$
      0004FA                       1951 00127$:
      0004FA                       1952 00104$:
                           00041B  1953 	C$main.c$439$5_0$163 ==.
                                   1954 ;	main.c:439: mainLATCH_ERROR();
      0004FA C0 E0            [24] 1955 	push ACC 
      0004FC C0 A8            [24] 1956 	push IE 
                                   1957 ;	assignBit
      0004FE C2 AF            [12] 1958 	clr	_EA
      000500 90 18 73         [24] 1959 	mov	dptr,#_xLatchedError
      000503 74 01            [12] 1960 	mov	a,#0x01
      000505 F0               [24] 1961 	movx	@dptr,a
      000506 D0 E0            [24] 1962 	pop ACC 
      000508 53 E0 80         [24] 1963 	anl	_ACC,#0x80
      00050B E5 E0            [12] 1964 	mov	a,_ACC
      00050D 42 A8            [12] 1965 	orl	_IE,a
      00050F D0 E0            [24] 1966 	pop ACC 
      000511 02 03 89         [24] 1967 	ljmp	00108$
      000514                       1968 00110$:
                           000435  1969 	C$main.c$442$2_0$157 ==.
                                   1970 ;	main.c:442: }
      000514 85 0D 81         [24] 1971 	mov	sp,_bp
      000517 D0 0D            [24] 1972 	pop	_bp
                           00043A  1973 	C$main.c$442$2_0$157 ==.
                           00043A  1974 	XFmain$vFLOPCheck1$0$0 ==.
      000519 22               [24] 1975 	ret
                                   1976 ;------------------------------------------------------------
                                   1977 ;Allocation info for local variables in function 'vFLOPCheck2'
                                   1978 ;------------------------------------------------------------
                                   1979 ;pvParameters              Allocated to registers 
                                   1980 ;fVal1                     Allocated to stack - _bp +5
                                   1981 ;fVal2                     Allocated to stack - _bp +9
                                   1982 ;fResult                   Allocated to stack - _bp +1
                                   1983 ;------------------------------------------------------------
                           00043B  1984 	Fmain$vFLOPCheck2$0$0 ==.
                           00043B  1985 	C$main.c$448$2_0$165 ==.
                                   1986 ;	main.c:448: static void vFLOPCheck2( void *pvParameters )
                                   1987 ;	-----------------------------------------
                                   1988 ;	 function vFLOPCheck2
                                   1989 ;	-----------------------------------------
      00051A                       1990 _vFLOPCheck2:
      00051A C0 0D            [24] 1991 	push	_bp
      00051C 85 81 0D         [24] 1992 	mov	_bp,sp
      00051F E5 81            [12] 1993 	mov	a,sp
      000521 24 0C            [12] 1994 	add	a,#0x0c
      000523 F5 81            [12] 1995 	mov	sp,a
                           000446  1996 	C$main.c$452$2_0$166 ==.
                                   1997 ;	main.c:452: ( void ) pvParameters;
      000525                       1998 00108$:
                           000446  1999 	C$main.c$456$3_0$167 ==.
                                   2000 ;	main.c:456: fVal1 = ( portFLOAT ) -12340.5678;
      000525 E5 0D            [12] 2001 	mov	a,_bp
      000527 24 05            [12] 2002 	add	a,#0x05
      000529 F8               [12] 2003 	mov	r0,a
      00052A 76 45            [12] 2004 	mov	@r0,#0x45
      00052C 08               [12] 2005 	inc	r0
      00052D 76 D2            [12] 2006 	mov	@r0,#0xd2
      00052F 08               [12] 2007 	inc	r0
      000530 76 40            [12] 2008 	mov	@r0,#0x40
      000532 08               [12] 2009 	inc	r0
      000533 76 C6            [12] 2010 	mov	@r0,#0xc6
                           000456  2011 	C$main.c$457$3_0$167 ==.
                                   2012 ;	main.c:457: fVal2 = ( portFLOAT ) 23450.6789;
      000535 E5 0D            [12] 2013 	mov	a,_bp
      000537 24 09            [12] 2014 	add	a,#0x09
      000539 F8               [12] 2015 	mov	r0,a
      00053A 76 5C            [12] 2016 	mov	@r0,#0x5c
      00053C 08               [12] 2017 	inc	r0
      00053D 76 35            [12] 2018 	mov	@r0,#0x35
      00053F 08               [12] 2019 	inc	r0
      000540 76 B7            [12] 2020 	mov	@r0,#0xb7
      000542 08               [12] 2021 	inc	r0
      000543 76 46            [12] 2022 	mov	@r0,#0x46
                           000466  2023 	C$main.c$459$2_0$165 ==.
                                   2024 ;	main.c:459: fResult = fVal1 + fVal2;
      000545 E5 0D            [12] 2025 	mov	a,_bp
      000547 24 09            [12] 2026 	add	a,#0x09
      000549 F8               [12] 2027 	mov	r0,a
      00054A E6               [12] 2028 	mov	a,@r0
      00054B C0 E0            [24] 2029 	push	acc
      00054D 08               [12] 2030 	inc	r0
      00054E E6               [12] 2031 	mov	a,@r0
      00054F C0 E0            [24] 2032 	push	acc
      000551 08               [12] 2033 	inc	r0
      000552 E6               [12] 2034 	mov	a,@r0
      000553 C0 E0            [24] 2035 	push	acc
      000555 08               [12] 2036 	inc	r0
      000556 E6               [12] 2037 	mov	a,@r0
      000557 C0 E0            [24] 2038 	push	acc
      000559 E5 0D            [12] 2039 	mov	a,_bp
      00055B 24 05            [12] 2040 	add	a,#0x05
      00055D F8               [12] 2041 	mov	r0,a
      00055E 86 82            [24] 2042 	mov	dpl,@r0
      000560 08               [12] 2043 	inc	r0
      000561 86 83            [24] 2044 	mov	dph,@r0
      000563 08               [12] 2045 	inc	r0
      000564 86 F0            [24] 2046 	mov	b,@r0
      000566 08               [12] 2047 	inc	r0
      000567 E6               [12] 2048 	mov	a,@r0
      000568 12 6B DB         [24] 2049 	lcall	___fsadd
      00056B AC 82            [24] 2050 	mov	r4,dpl
      00056D AD 83            [24] 2051 	mov	r5,dph
      00056F AE F0            [24] 2052 	mov	r6,b
      000571 FF               [12] 2053 	mov	r7,a
      000572 E5 81            [12] 2054 	mov	a,sp
      000574 24 FC            [12] 2055 	add	a,#0xfc
      000576 F5 81            [12] 2056 	mov	sp,a
      000578 A8 0D            [24] 2057 	mov	r0,_bp
      00057A 08               [12] 2058 	inc	r0
      00057B A6 04            [24] 2059 	mov	@r0,ar4
      00057D 08               [12] 2060 	inc	r0
      00057E A6 05            [24] 2061 	mov	@r0,ar5
      000580 08               [12] 2062 	inc	r0
      000581 A6 06            [24] 2063 	mov	@r0,ar6
      000583 08               [12] 2064 	inc	r0
      000584 A6 07            [24] 2065 	mov	@r0,ar7
                           0004A7  2066 	C$main.c$460$2_0$165 ==.
                                   2067 ;	main.c:460: if( ( fResult > ( portFLOAT ) 11110.15 ) || ( fResult < ( portFLOAT ) 11110.05 ) )
      000586 A8 0D            [24] 2068 	mov	r0,_bp
      000588 08               [12] 2069 	inc	r0
      000589 E6               [12] 2070 	mov	a,@r0
      00058A C0 E0            [24] 2071 	push	acc
      00058C 08               [12] 2072 	inc	r0
      00058D E6               [12] 2073 	mov	a,@r0
      00058E C0 E0            [24] 2074 	push	acc
      000590 08               [12] 2075 	inc	r0
      000591 E6               [12] 2076 	mov	a,@r0
      000592 C0 E0            [24] 2077 	push	acc
      000594 08               [12] 2078 	inc	r0
      000595 E6               [12] 2079 	mov	a,@r0
      000596 C0 E0            [24] 2080 	push	acc
      000598 75 82 9A         [24] 2081 	mov	dpl,#0x9a
      00059B 75 83 98         [24] 2082 	mov	dph,#0x98
      00059E 75 F0 2D         [24] 2083 	mov	b,#0x2d
      0005A1 74 46            [12] 2084 	mov	a,#0x46
      0005A3 12 6B 0D         [24] 2085 	lcall	___fslt
      0005A6 AF 82            [24] 2086 	mov	r7,dpl
      0005A8 E5 81            [12] 2087 	mov	a,sp
      0005AA 24 FC            [12] 2088 	add	a,#0xfc
      0005AC F5 81            [12] 2089 	mov	sp,a
      0005AE EF               [12] 2090 	mov	a,r7
      0005AF 60 03            [24] 2091 	jz	00124$
      0005B1 02 05 E2         [24] 2092 	ljmp	00101$
      0005B4                       2093 00124$:
      0005B4 74 33            [12] 2094 	mov	a,#0x33
      0005B6 C0 E0            [24] 2095 	push	acc
      0005B8 74 98            [12] 2096 	mov	a,#0x98
      0005BA C0 E0            [24] 2097 	push	acc
      0005BC 74 2D            [12] 2098 	mov	a,#0x2d
      0005BE C0 E0            [24] 2099 	push	acc
      0005C0 74 46            [12] 2100 	mov	a,#0x46
      0005C2 C0 E0            [24] 2101 	push	acc
      0005C4 A8 0D            [24] 2102 	mov	r0,_bp
      0005C6 08               [12] 2103 	inc	r0
      0005C7 86 82            [24] 2104 	mov	dpl,@r0
      0005C9 08               [12] 2105 	inc	r0
      0005CA 86 83            [24] 2106 	mov	dph,@r0
      0005CC 08               [12] 2107 	inc	r0
      0005CD 86 F0            [24] 2108 	mov	b,@r0
      0005CF 08               [12] 2109 	inc	r0
      0005D0 E6               [12] 2110 	mov	a,@r0
      0005D1 12 6B 0D         [24] 2111 	lcall	___fslt
      0005D4 AF 82            [24] 2112 	mov	r7,dpl
      0005D6 E5 81            [12] 2113 	mov	a,sp
      0005D8 24 FC            [12] 2114 	add	a,#0xfc
      0005DA F5 81            [12] 2115 	mov	sp,a
      0005DC EF               [12] 2116 	mov	a,r7
      0005DD 70 03            [24] 2117 	jnz	00125$
      0005DF 02 05 F9         [24] 2118 	ljmp	00102$
      0005E2                       2119 00125$:
      0005E2                       2120 00101$:
                           000503  2121 	C$main.c$462$5_0$169 ==.
                                   2122 ;	main.c:462: mainLATCH_ERROR();
      0005E2 C0 E0            [24] 2123 	push ACC 
      0005E4 C0 A8            [24] 2124 	push IE 
                                   2125 ;	assignBit
      0005E6 C2 AF            [12] 2126 	clr	_EA
      0005E8 90 18 73         [24] 2127 	mov	dptr,#_xLatchedError
      0005EB 74 01            [12] 2128 	mov	a,#0x01
      0005ED F0               [24] 2129 	movx	@dptr,a
      0005EE D0 E0            [24] 2130 	pop ACC 
      0005F0 53 E0 80         [24] 2131 	anl	_ACC,#0x80
      0005F3 E5 E0            [12] 2132 	mov	a,_ACC
      0005F5 42 A8            [12] 2133 	orl	_IE,a
      0005F7 D0 E0            [24] 2134 	pop ACC 
      0005F9                       2135 00102$:
                           00051A  2136 	C$main.c$465$3_0$167 ==.
                                   2137 ;	main.c:465: fResult = fVal1 / -fVal2;
      0005F9 E5 0D            [12] 2138 	mov	a,_bp
      0005FB 24 09            [12] 2139 	add	a,#0x09
      0005FD F8               [12] 2140 	mov	r0,a
      0005FE 86 04            [24] 2141 	mov	ar4,@r0
      000600 08               [12] 2142 	inc	r0
      000601 86 05            [24] 2143 	mov	ar5,@r0
      000603 08               [12] 2144 	inc	r0
      000604 86 06            [24] 2145 	mov	ar6,@r0
      000606 08               [12] 2146 	inc	r0
      000607 E6               [12] 2147 	mov	a,@r0
      000608 B2 E7            [12] 2148 	cpl	acc.7
      00060A FF               [12] 2149 	mov	r7,a
      00060B C0 04            [24] 2150 	push	ar4
      00060D C0 05            [24] 2151 	push	ar5
      00060F C0 06            [24] 2152 	push	ar6
      000611 C0 07            [24] 2153 	push	ar7
      000613 E5 0D            [12] 2154 	mov	a,_bp
      000615 24 05            [12] 2155 	add	a,#0x05
      000617 F8               [12] 2156 	mov	r0,a
      000618 86 82            [24] 2157 	mov	dpl,@r0
      00061A 08               [12] 2158 	inc	r0
      00061B 86 83            [24] 2159 	mov	dph,@r0
      00061D 08               [12] 2160 	inc	r0
      00061E 86 F0            [24] 2161 	mov	b,@r0
      000620 08               [12] 2162 	inc	r0
      000621 E6               [12] 2163 	mov	a,@r0
      000622 12 6F 6D         [24] 2164 	lcall	___fsdiv
      000625 AC 82            [24] 2165 	mov	r4,dpl
      000627 AD 83            [24] 2166 	mov	r5,dph
      000629 AE F0            [24] 2167 	mov	r6,b
      00062B FF               [12] 2168 	mov	r7,a
      00062C E5 81            [12] 2169 	mov	a,sp
      00062E 24 FC            [12] 2170 	add	a,#0xfc
      000630 F5 81            [12] 2171 	mov	sp,a
      000632 A8 0D            [24] 2172 	mov	r0,_bp
      000634 08               [12] 2173 	inc	r0
      000635 A6 04            [24] 2174 	mov	@r0,ar4
      000637 08               [12] 2175 	inc	r0
      000638 A6 05            [24] 2176 	mov	@r0,ar5
      00063A 08               [12] 2177 	inc	r0
      00063B A6 06            [24] 2178 	mov	@r0,ar6
      00063D 08               [12] 2179 	inc	r0
      00063E A6 07            [24] 2180 	mov	@r0,ar7
                           000561  2181 	C$main.c$466$2_0$165 ==.
                                   2182 ;	main.c:466: if( ( fResult > ( portFLOAT ) 0.53 ) || ( fResult < ( portFLOAT ) 0.51 ) )
      000640 A8 0D            [24] 2183 	mov	r0,_bp
      000642 08               [12] 2184 	inc	r0
      000643 E6               [12] 2185 	mov	a,@r0
      000644 C0 E0            [24] 2186 	push	acc
      000646 08               [12] 2187 	inc	r0
      000647 E6               [12] 2188 	mov	a,@r0
      000648 C0 E0            [24] 2189 	push	acc
      00064A 08               [12] 2190 	inc	r0
      00064B E6               [12] 2191 	mov	a,@r0
      00064C C0 E0            [24] 2192 	push	acc
      00064E 08               [12] 2193 	inc	r0
      00064F E6               [12] 2194 	mov	a,@r0
      000650 C0 E0            [24] 2195 	push	acc
      000652 75 82 14         [24] 2196 	mov	dpl,#0x14
      000655 75 83 AE         [24] 2197 	mov	dph,#0xae
      000658 75 F0 07         [24] 2198 	mov	b,#0x07
      00065B 74 3F            [12] 2199 	mov	a,#0x3f
      00065D 12 6B 0D         [24] 2200 	lcall	___fslt
      000660 AF 82            [24] 2201 	mov	r7,dpl
      000662 E5 81            [12] 2202 	mov	a,sp
      000664 24 FC            [12] 2203 	add	a,#0xfc
      000666 F5 81            [12] 2204 	mov	sp,a
      000668 EF               [12] 2205 	mov	a,r7
      000669 60 03            [24] 2206 	jz	00126$
      00066B 02 06 9C         [24] 2207 	ljmp	00104$
      00066E                       2208 00126$:
      00066E 74 5C            [12] 2209 	mov	a,#0x5c
      000670 C0 E0            [24] 2210 	push	acc
      000672 74 8F            [12] 2211 	mov	a,#0x8f
      000674 C0 E0            [24] 2212 	push	acc
      000676 74 02            [12] 2213 	mov	a,#0x02
      000678 C0 E0            [24] 2214 	push	acc
      00067A 74 3F            [12] 2215 	mov	a,#0x3f
      00067C C0 E0            [24] 2216 	push	acc
      00067E A8 0D            [24] 2217 	mov	r0,_bp
      000680 08               [12] 2218 	inc	r0
      000681 86 82            [24] 2219 	mov	dpl,@r0
      000683 08               [12] 2220 	inc	r0
      000684 86 83            [24] 2221 	mov	dph,@r0
      000686 08               [12] 2222 	inc	r0
      000687 86 F0            [24] 2223 	mov	b,@r0
      000689 08               [12] 2224 	inc	r0
      00068A E6               [12] 2225 	mov	a,@r0
      00068B 12 6B 0D         [24] 2226 	lcall	___fslt
      00068E AF 82            [24] 2227 	mov	r7,dpl
      000690 E5 81            [12] 2228 	mov	a,sp
      000692 24 FC            [12] 2229 	add	a,#0xfc
      000694 F5 81            [12] 2230 	mov	sp,a
      000696 EF               [12] 2231 	mov	a,r7
      000697 70 03            [24] 2232 	jnz	00127$
      000699 02 05 25         [24] 2233 	ljmp	00108$
      00069C                       2234 00127$:
      00069C                       2235 00104$:
                           0005BD  2236 	C$main.c$468$5_0$171 ==.
                                   2237 ;	main.c:468: mainLATCH_ERROR();
      00069C C0 E0            [24] 2238 	push ACC 
      00069E C0 A8            [24] 2239 	push IE 
                                   2240 ;	assignBit
      0006A0 C2 AF            [12] 2241 	clr	_EA
      0006A2 90 18 73         [24] 2242 	mov	dptr,#_xLatchedError
      0006A5 74 01            [12] 2243 	mov	a,#0x01
      0006A7 F0               [24] 2244 	movx	@dptr,a
      0006A8 D0 E0            [24] 2245 	pop ACC 
      0006AA 53 E0 80         [24] 2246 	anl	_ACC,#0x80
      0006AD E5 E0            [12] 2247 	mov	a,_ACC
      0006AF 42 A8            [12] 2248 	orl	_IE,a
      0006B1 D0 E0            [24] 2249 	pop ACC 
      0006B3 02 05 25         [24] 2250 	ljmp	00108$
      0006B6                       2251 00110$:
                           0005D7  2252 	C$main.c$471$2_0$165 ==.
                                   2253 ;	main.c:471: }
      0006B6 85 0D 81         [24] 2254 	mov	sp,_bp
      0006B9 D0 0D            [24] 2255 	pop	_bp
                           0005DC  2256 	C$main.c$471$2_0$165 ==.
                           0005DC  2257 	XFmain$vFLOPCheck2$0$0 ==.
      0006BB 22               [24] 2258 	ret
                                   2259 ;------------------------------------------------------------
                                   2260 ;Allocation info for local variables in function 'vRegisterCheck'
                                   2261 ;------------------------------------------------------------
                                   2262 ;pvParameters              Allocated to registers 
                                   2263 ;------------------------------------------------------------
                           0005DD  2264 	Fmain$vRegisterCheck$0$0 ==.
                           0005DD  2265 	C$main.c$477$2_0$173 ==.
                                   2266 ;	main.c:477: static void vRegisterCheck( void *pvParameters )
                                   2267 ;	-----------------------------------------
                                   2268 ;	 function vRegisterCheck
                                   2269 ;	-----------------------------------------
      0006BC                       2270 _vRegisterCheck:
                           0005DD  2271 	C$main.c$479$2_0$174 ==.
                                   2272 ;	main.c:479: ( void ) pvParameters;
      0006BC                       2273 00126$:
                           0005DD  2274 	C$main.c$483$3_0$175 ==.
                                   2275 ;	main.c:483: if( SP != configSTACK_START )
      0006BC 74 0E            [12] 2276 	mov	a,#0x0e
      0006BE B5 81 03         [24] 2277 	cjne	a,_SP,00182$
      0006C1 02 06 DB         [24] 2278 	ljmp	00102$
      0006C4                       2279 00182$:
                           0005E5  2280 	C$main.c$485$5_0$177 ==.
                                   2281 ;	main.c:485: mainLATCH_ERROR();
      0006C4 C0 E0            [24] 2282 	push ACC 
      0006C6 C0 A8            [24] 2283 	push IE 
                                   2284 ;	assignBit
      0006C8 C2 AF            [12] 2285 	clr	_EA
      0006CA 90 18 73         [24] 2286 	mov	dptr,#_xLatchedError
      0006CD 74 01            [12] 2287 	mov	a,#0x01
      0006CF F0               [24] 2288 	movx	@dptr,a
      0006D0 D0 E0            [24] 2289 	pop ACC 
      0006D2 53 E0 80         [24] 2290 	anl	_ACC,#0x80
      0006D5 E5 E0            [12] 2291 	mov	a,_ACC
      0006D7 42 A8            [12] 2292 	orl	_IE,a
      0006D9 D0 E0            [24] 2293 	pop ACC 
      0006DB                       2294 00102$:
                           0005FC  2295 	C$main.c$490$3_0$175 ==.
                                   2296 ;	main.c:490: __endasm;
      0006DB 85 00 E0         [24] 2297 	MOV	ACC, ar0
                           0005FF  2298 	C$main.c$492$3_0$175 ==.
                                   2299 ;	main.c:492: if( ACC != 0 )
      0006DE E5 E0            [12] 2300 	mov	a,_ACC
      0006E0 70 03            [24] 2301 	jnz	00183$
      0006E2 02 06 FC         [24] 2302 	ljmp	00104$
      0006E5                       2303 00183$:
                           000606  2304 	C$main.c$494$5_0$179 ==.
                                   2305 ;	main.c:494: mainLATCH_ERROR();
      0006E5 C0 E0            [24] 2306 	push ACC 
      0006E7 C0 A8            [24] 2307 	push IE 
                                   2308 ;	assignBit
      0006E9 C2 AF            [12] 2309 	clr	_EA
      0006EB 90 18 73         [24] 2310 	mov	dptr,#_xLatchedError
      0006EE 74 01            [12] 2311 	mov	a,#0x01
      0006F0 F0               [24] 2312 	movx	@dptr,a
      0006F1 D0 E0            [24] 2313 	pop ACC 
      0006F3 53 E0 80         [24] 2314 	anl	_ACC,#0x80
      0006F6 E5 E0            [12] 2315 	mov	a,_ACC
      0006F8 42 A8            [12] 2316 	orl	_IE,a
      0006FA D0 E0            [24] 2317 	pop ACC 
      0006FC                       2318 00104$:
                           00061D  2319 	C$main.c$499$3_0$175 ==.
                                   2320 ;	main.c:499: __endasm;
      0006FC 85 01 E0         [24] 2321 	MOV	ACC, ar1
                           000620  2322 	C$main.c$501$3_0$175 ==.
                                   2323 ;	main.c:501: if( ACC != 1 )
      0006FF 74 01            [12] 2324 	mov	a,#0x01
      000701 B5 E0 03         [24] 2325 	cjne	a,_ACC,00184$
      000704 02 07 1E         [24] 2326 	ljmp	00106$
      000707                       2327 00184$:
                           000628  2328 	C$main.c$503$5_0$181 ==.
                                   2329 ;	main.c:503: mainLATCH_ERROR();
      000707 C0 E0            [24] 2330 	push ACC 
      000709 C0 A8            [24] 2331 	push IE 
                                   2332 ;	assignBit
      00070B C2 AF            [12] 2333 	clr	_EA
      00070D 90 18 73         [24] 2334 	mov	dptr,#_xLatchedError
      000710 74 01            [12] 2335 	mov	a,#0x01
      000712 F0               [24] 2336 	movx	@dptr,a
      000713 D0 E0            [24] 2337 	pop ACC 
      000715 53 E0 80         [24] 2338 	anl	_ACC,#0x80
      000718 E5 E0            [12] 2339 	mov	a,_ACC
      00071A 42 A8            [12] 2340 	orl	_IE,a
      00071C D0 E0            [24] 2341 	pop ACC 
      00071E                       2342 00106$:
                           00063F  2343 	C$main.c$507$3_0$175 ==.
                                   2344 ;	main.c:507: __endasm;
      00071E 85 02 E0         [24] 2345 	MOV	ACC, ar2
                           000642  2346 	C$main.c$509$3_0$175 ==.
                                   2347 ;	main.c:509: if( ACC != 2 )
      000721 74 02            [12] 2348 	mov	a,#0x02
      000723 B5 E0 03         [24] 2349 	cjne	a,_ACC,00185$
      000726 02 07 40         [24] 2350 	ljmp	00108$
      000729                       2351 00185$:
                           00064A  2352 	C$main.c$511$5_0$183 ==.
                                   2353 ;	main.c:511: mainLATCH_ERROR();
      000729 C0 E0            [24] 2354 	push ACC 
      00072B C0 A8            [24] 2355 	push IE 
                                   2356 ;	assignBit
      00072D C2 AF            [12] 2357 	clr	_EA
      00072F 90 18 73         [24] 2358 	mov	dptr,#_xLatchedError
      000732 74 01            [12] 2359 	mov	a,#0x01
      000734 F0               [24] 2360 	movx	@dptr,a
      000735 D0 E0            [24] 2361 	pop ACC 
      000737 53 E0 80         [24] 2362 	anl	_ACC,#0x80
      00073A E5 E0            [12] 2363 	mov	a,_ACC
      00073C 42 A8            [12] 2364 	orl	_IE,a
      00073E D0 E0            [24] 2365 	pop ACC 
      000740                       2366 00108$:
                           000661  2367 	C$main.c$515$3_0$175 ==.
                                   2368 ;	main.c:515: __endasm;
      000740 85 03 E0         [24] 2369 	MOV	ACC, ar3
                           000664  2370 	C$main.c$517$3_0$175 ==.
                                   2371 ;	main.c:517: if( ACC != 3 )
      000743 74 03            [12] 2372 	mov	a,#0x03
      000745 B5 E0 03         [24] 2373 	cjne	a,_ACC,00186$
      000748 02 07 62         [24] 2374 	ljmp	00110$
      00074B                       2375 00186$:
                           00066C  2376 	C$main.c$519$5_0$185 ==.
                                   2377 ;	main.c:519: mainLATCH_ERROR();
      00074B C0 E0            [24] 2378 	push ACC 
      00074D C0 A8            [24] 2379 	push IE 
                                   2380 ;	assignBit
      00074F C2 AF            [12] 2381 	clr	_EA
      000751 90 18 73         [24] 2382 	mov	dptr,#_xLatchedError
      000754 74 01            [12] 2383 	mov	a,#0x01
      000756 F0               [24] 2384 	movx	@dptr,a
      000757 D0 E0            [24] 2385 	pop ACC 
      000759 53 E0 80         [24] 2386 	anl	_ACC,#0x80
      00075C E5 E0            [12] 2387 	mov	a,_ACC
      00075E 42 A8            [12] 2388 	orl	_IE,a
      000760 D0 E0            [24] 2389 	pop ACC 
      000762                       2390 00110$:
                           000683  2391 	C$main.c$523$3_0$175 ==.
                                   2392 ;	main.c:523: __endasm;
      000762 85 04 E0         [24] 2393 	MOV	ACC, ar4
                           000686  2394 	C$main.c$525$3_0$175 ==.
                                   2395 ;	main.c:525: if( ACC != 4 )
      000765 74 04            [12] 2396 	mov	a,#0x04
      000767 B5 E0 03         [24] 2397 	cjne	a,_ACC,00187$
      00076A 02 07 84         [24] 2398 	ljmp	00112$
      00076D                       2399 00187$:
                           00068E  2400 	C$main.c$527$5_0$187 ==.
                                   2401 ;	main.c:527: mainLATCH_ERROR();
      00076D C0 E0            [24] 2402 	push ACC 
      00076F C0 A8            [24] 2403 	push IE 
                                   2404 ;	assignBit
      000771 C2 AF            [12] 2405 	clr	_EA
      000773 90 18 73         [24] 2406 	mov	dptr,#_xLatchedError
      000776 74 01            [12] 2407 	mov	a,#0x01
      000778 F0               [24] 2408 	movx	@dptr,a
      000779 D0 E0            [24] 2409 	pop ACC 
      00077B 53 E0 80         [24] 2410 	anl	_ACC,#0x80
      00077E E5 E0            [12] 2411 	mov	a,_ACC
      000780 42 A8            [12] 2412 	orl	_IE,a
      000782 D0 E0            [24] 2413 	pop ACC 
      000784                       2414 00112$:
                           0006A5  2415 	C$main.c$531$3_0$175 ==.
                                   2416 ;	main.c:531: __endasm;
      000784 85 05 E0         [24] 2417 	MOV	ACC, ar5
                           0006A8  2418 	C$main.c$533$3_0$175 ==.
                                   2419 ;	main.c:533: if( ACC != 5 )
      000787 74 05            [12] 2420 	mov	a,#0x05
      000789 B5 E0 03         [24] 2421 	cjne	a,_ACC,00188$
      00078C 02 07 A6         [24] 2422 	ljmp	00114$
      00078F                       2423 00188$:
                           0006B0  2424 	C$main.c$535$5_0$189 ==.
                                   2425 ;	main.c:535: mainLATCH_ERROR();
      00078F C0 E0            [24] 2426 	push ACC 
      000791 C0 A8            [24] 2427 	push IE 
                                   2428 ;	assignBit
      000793 C2 AF            [12] 2429 	clr	_EA
      000795 90 18 73         [24] 2430 	mov	dptr,#_xLatchedError
      000798 74 01            [12] 2431 	mov	a,#0x01
      00079A F0               [24] 2432 	movx	@dptr,a
      00079B D0 E0            [24] 2433 	pop ACC 
      00079D 53 E0 80         [24] 2434 	anl	_ACC,#0x80
      0007A0 E5 E0            [12] 2435 	mov	a,_ACC
      0007A2 42 A8            [12] 2436 	orl	_IE,a
      0007A4 D0 E0            [24] 2437 	pop ACC 
      0007A6                       2438 00114$:
                           0006C7  2439 	C$main.c$539$3_0$175 ==.
                                   2440 ;	main.c:539: __endasm;
      0007A6 85 06 E0         [24] 2441 	MOV	ACC, ar6
                           0006CA  2442 	C$main.c$541$3_0$175 ==.
                                   2443 ;	main.c:541: if( ACC != 6 )
      0007A9 74 06            [12] 2444 	mov	a,#0x06
      0007AB B5 E0 03         [24] 2445 	cjne	a,_ACC,00189$
      0007AE 02 07 C8         [24] 2446 	ljmp	00116$
      0007B1                       2447 00189$:
                           0006D2  2448 	C$main.c$543$5_0$191 ==.
                                   2449 ;	main.c:543: mainLATCH_ERROR();
      0007B1 C0 E0            [24] 2450 	push ACC 
      0007B3 C0 A8            [24] 2451 	push IE 
                                   2452 ;	assignBit
      0007B5 C2 AF            [12] 2453 	clr	_EA
      0007B7 90 18 73         [24] 2454 	mov	dptr,#_xLatchedError
      0007BA 74 01            [12] 2455 	mov	a,#0x01
      0007BC F0               [24] 2456 	movx	@dptr,a
      0007BD D0 E0            [24] 2457 	pop ACC 
      0007BF 53 E0 80         [24] 2458 	anl	_ACC,#0x80
      0007C2 E5 E0            [12] 2459 	mov	a,_ACC
      0007C4 42 A8            [12] 2460 	orl	_IE,a
      0007C6 D0 E0            [24] 2461 	pop ACC 
      0007C8                       2462 00116$:
                           0006E9  2463 	C$main.c$547$3_0$175 ==.
                                   2464 ;	main.c:547: __endasm;
      0007C8 85 07 E0         [24] 2465 	MOV	ACC, ar7
                           0006EC  2466 	C$main.c$549$3_0$175 ==.
                                   2467 ;	main.c:549: if( ACC != 7 )
      0007CB 74 07            [12] 2468 	mov	a,#0x07
      0007CD B5 E0 03         [24] 2469 	cjne	a,_ACC,00190$
      0007D0 02 07 EA         [24] 2470 	ljmp	00118$
      0007D3                       2471 00190$:
                           0006F4  2472 	C$main.c$551$5_0$193 ==.
                                   2473 ;	main.c:551: mainLATCH_ERROR();
      0007D3 C0 E0            [24] 2474 	push ACC 
      0007D5 C0 A8            [24] 2475 	push IE 
                                   2476 ;	assignBit
      0007D7 C2 AF            [12] 2477 	clr	_EA
      0007D9 90 18 73         [24] 2478 	mov	dptr,#_xLatchedError
      0007DC 74 01            [12] 2479 	mov	a,#0x01
      0007DE F0               [24] 2480 	movx	@dptr,a
      0007DF D0 E0            [24] 2481 	pop ACC 
      0007E1 53 E0 80         [24] 2482 	anl	_ACC,#0x80
      0007E4 E5 E0            [12] 2483 	mov	a,_ACC
      0007E6 42 A8            [12] 2484 	orl	_IE,a
      0007E8 D0 E0            [24] 2485 	pop ACC 
      0007EA                       2486 00118$:
                           00070B  2487 	C$main.c$554$3_0$175 ==.
                                   2488 ;	main.c:554: if( DPL != 0xcd )
      0007EA 74 CD            [12] 2489 	mov	a,#0xcd
      0007EC B5 82 03         [24] 2490 	cjne	a,_DPL,00191$
      0007EF 02 08 09         [24] 2491 	ljmp	00120$
      0007F2                       2492 00191$:
                           000713  2493 	C$main.c$556$5_0$195 ==.
                                   2494 ;	main.c:556: mainLATCH_ERROR();
      0007F2 C0 E0            [24] 2495 	push ACC 
      0007F4 C0 A8            [24] 2496 	push IE 
                                   2497 ;	assignBit
      0007F6 C2 AF            [12] 2498 	clr	_EA
      0007F8 90 18 73         [24] 2499 	mov	dptr,#_xLatchedError
      0007FB 74 01            [12] 2500 	mov	a,#0x01
      0007FD F0               [24] 2501 	movx	@dptr,a
      0007FE D0 E0            [24] 2502 	pop ACC 
      000800 53 E0 80         [24] 2503 	anl	_ACC,#0x80
      000803 E5 E0            [12] 2504 	mov	a,_ACC
      000805 42 A8            [12] 2505 	orl	_IE,a
      000807 D0 E0            [24] 2506 	pop ACC 
      000809                       2507 00120$:
                           00072A  2508 	C$main.c$559$3_0$175 ==.
                                   2509 ;	main.c:559: if( DPH != 0xab )
      000809 74 AB            [12] 2510 	mov	a,#0xab
      00080B B5 83 03         [24] 2511 	cjne	a,_DPH,00192$
      00080E 02 08 28         [24] 2512 	ljmp	00122$
      000811                       2513 00192$:
                           000732  2514 	C$main.c$561$5_0$197 ==.
                                   2515 ;	main.c:561: mainLATCH_ERROR();
      000811 C0 E0            [24] 2516 	push ACC 
      000813 C0 A8            [24] 2517 	push IE 
                                   2518 ;	assignBit
      000815 C2 AF            [12] 2519 	clr	_EA
      000817 90 18 73         [24] 2520 	mov	dptr,#_xLatchedError
      00081A 74 01            [12] 2521 	mov	a,#0x01
      00081C F0               [24] 2522 	movx	@dptr,a
      00081D D0 E0            [24] 2523 	pop ACC 
      00081F 53 E0 80         [24] 2524 	anl	_ACC,#0x80
      000822 E5 E0            [12] 2525 	mov	a,_ACC
      000824 42 A8            [12] 2526 	orl	_IE,a
      000826 D0 E0            [24] 2527 	pop ACC 
      000828                       2528 00122$:
                           000749  2529 	C$main.c$564$3_0$175 ==.
                                   2530 ;	main.c:564: if( B != 0x01 )
      000828 74 01            [12] 2531 	mov	a,#0x01
      00082A B5 F0 03         [24] 2532 	cjne	a,_B,00193$
      00082D 02 06 BC         [24] 2533 	ljmp	00126$
      000830                       2534 00193$:
                           000751  2535 	C$main.c$566$5_0$199 ==.
                                   2536 ;	main.c:566: mainLATCH_ERROR();
      000830 C0 E0            [24] 2537 	push ACC 
      000832 C0 A8            [24] 2538 	push IE 
                                   2539 ;	assignBit
      000834 C2 AF            [12] 2540 	clr	_EA
      000836 90 18 73         [24] 2541 	mov	dptr,#_xLatchedError
      000839 74 01            [12] 2542 	mov	a,#0x01
      00083B F0               [24] 2543 	movx	@dptr,a
      00083C D0 E0            [24] 2544 	pop ACC 
      00083E 53 E0 80         [24] 2545 	anl	_ACC,#0x80
      000841 E5 E0            [12] 2546 	mov	a,_ACC
      000843 42 A8            [12] 2547 	orl	_IE,a
      000845 D0 E0            [24] 2548 	pop ACC 
      000847 02 06 BC         [24] 2549 	ljmp	00126$
      00084A                       2550 00128$:
                           00076B  2551 	C$main.c$569$2_0$173 ==.
                                   2552 ;	main.c:569: }
                           00076B  2553 	C$main.c$569$2_0$173 ==.
                           00076B  2554 	XFmain$vRegisterCheck$0$0 ==.
      00084A 22               [24] 2555 	ret
                                   2556 	.area CSEG    (CODE)
                                   2557 	.area CONST   (CODE)
                           000000  2558 Fmain$__str_0$0_0$0 == .
                                   2559 	.area CONST   (CODE)
      007348                       2560 ___str_0:
      007348 52 65 67 43 68 63 6B  2561 	.ascii "RegChck"
      00734F 00                    2562 	.db 0x00
                                   2563 	.area CSEG    (CODE)
                           00076C  2564 Fmain$__str_1$0_0$0 == .
                                   2565 	.area CONST   (CODE)
      007350                       2566 ___str_1:
      007350 46 4C 4F 50           2567 	.ascii "FLOP"
      007354 00                    2568 	.db 0x00
                                   2569 	.area CSEG    (CODE)
                           00076C  2570 Fmain$__str_2$0_0$0 == .
                                   2571 	.area CONST   (CODE)
      007355                       2572 ___str_2:
      007355 43 68 65 63 6B        2573 	.ascii "Check"
      00735A 00                    2574 	.db 0x00
                                   2575 	.area CSEG    (CODE)
                                   2576 	.area XINIT   (CODE)
                           000000  2577 Fmain$__xinit_xLatchedError$0_0$0 == .
      007424                       2578 __xinit__xLatchedError:
      007424 00                    2579 	.db #0x00	; 0
                                   2580 	.area CABS    (ABS,CODE)
